# HyperOS Privacy Tuner

Android-App, die Schritt für Schritt durch empfohlene Einstellungen für Datenschutz, Sicherheit, Netzwerk, Werbung und Geschwindigkeit führt – mit Direktsprung in die richtigen Menüs und automatischer Erkennung vieler Werte. Für Xiaomi/Redmi/POCO (HyperOS), Samsung (One UI) und andere Android-Geräte. Deutsch und Englisch, Glas-Design im Dark Mode.

*An Android app that guides you step by step through recommended privacy, security, network, ad and performance settings – for Xiaomi (HyperOS), Samsung (One UI) and other Android devices. German and English.*

## Was die App kann

Die App ist **ohne PC und ohne Sonderrechte voll nutzbar**: APK installieren, öffnen, loslegen. Neben der App werden keine Skripte oder weiteren Dateien benötigt.

- **Sanfter Einstieg:** Beim ersten Start erklärt eine kurze Einführung in drei Schritten, was die App macht. Danach zeigt sie nur **„Das Wichtigste“** (rund zehn Punkte). Die Karte **„Nächster Schritt“** führt Punkt für Punkt durch – mit „Jetzt einstellen“, „Erledigt“ und „Später“. Alle weiteren Punkte gibt es auf Wunsch unter **„Alle Punkte“**.
- **Automatik lite:** In der Einführung (überspringbar) stellt die App ohne PC und ohne Passwort den Bildschirm-Timeout ein – Android fragt dafür einmal nach der Erlaubnis „Systemeinstellungen ändern“. Alles Weitere führt der Assistent „Nächster Schritt“.
- **Automatischer Durchlauf (Reiter „Erweitert“):** Setzt nach Bestätigung per Fingerabdruck, Gesicht oder PIN alle Systemwerte auf einmal und zeigt ein Ergebnis; „Alles rückgängig machen“ nimmt die Änderungen wieder zurück. Voraussetzung ist die einmalige Freischaltung – direkt am Handy mit Shizuku oder per PC – die Bestätigung selbst gibt der App keine Rechte, sie verhindert nur, dass jemand anderes den Durchlauf startet.
- **Herstellererkennung:** Die App erkennt Xiaomi, Samsung und andere Hersteller und passt Menüpfade, Empfehlungen und den Schriftzug an (HYPER⚡OS, ONE⚡UI, ANDROID⚡16 …). Antippen des Schriftzugs wechselt die Oberfläche von Hand.
- **Fünf Kategorien:** Datenschutz, Sicherheit, Netzwerk, Werbung, Geschwindigkeit – mit Filtern und Fortschritt je Kategorie.
- **Automatische Erkennung:** Bildschirmsperre, Sicherheitsupdate, Bildschirm-Timeout, USB-Debugging, WLAN-/Bluetooth-Suche, Privates DNS, Sperrbildschirm-Inhalte, Zwischenablage-Hinweis, Animationen und freier Speicher werden selbst abgehakt, sobald man aus den Einstellungen zurückkommt.
- **Bedienung:** Deutsch/Englisch (folgt der Systemsprache), sechs Farbdesigns, aufklappbare Karten, dezentes haptisches Feedback.

### Herstellerspezifisch

| | Xiaomi (HyperOS) | Samsung (One UI) | Andere |
|---|---|---|---|
| Werbung | msa, Werbedienste, Empfehlungen in Xiaomi-Apps | Anpassungsdienst, Werbe-Blockierung (One UI 8.5), Push Service, Galaxy Store, Wallet, Samsung Free | Google-Werbung, Werbe-Benachrichtigungen |
| Sicherheit | Kontrollzentrum im Sperrzustand, App-Sperre | Automatische Sperre, Samsung-Konto, „Netzwerk und Sicherheit sperren“, Sicherer Ordner | Privater Bereich |
| Tempo | Startbildschirm-Animationen, Autostart, Speichererweiterung | Standby für ungenutzte Apps, RAM Plus, Leistungsprofil | – |

### DNS-Anbieter

Alle drei Voreinstellungen sind kostenlos und ohne Konto nutzbar: AdGuard DNS (`dns.adguard-dns.com`), Mullvad (`adblock.dns.mullvad.net`) und Quad9 (`dns.quad9.net`, nur Schadsoftware). Ein eigener Hostname lässt sich eintragen.

## APK bauen

**Mit GitHub:** Neue `HyperOSTuner.zip` unter demselben Namen ins Repository hochladen – der Build startet automatisch, die APK liegt danach unter *Actions › Artifacts*. Alternativ den entpackten Projektordner inklusive `.github` hochladen.

**Mit Android Studio:** *File › Open*, dann *Build › Build APK(s)*.

Alle Builds werden mit `app/debug.keystore` signiert, damit Updates über die vorhandene Version installiert werden können. Haken und Einstellungen bleiben dabei erhalten.

## Installieren

APK aufs Handy kopieren und antippen; einmalig „Unbekannte Apps installieren“ erlauben. Bei Samsung muss dafür die „Automatische Sperre“ kurz aus sein – die Checkliste erinnert daran, sie danach wieder einzuschalten.

## Optional: Freischaltung ohne PC – mit Shizuku

Im Reiter **„Erweitert“** führt die App in vier Schritten durch: Shizuku installieren (empfohlen: Fork von thedjchi, das Play-Store-Original wird ab Android 16 QPR1 nicht mehr gut unterstützt), über „Kabelloses Debugging“ starten, Zugriff erlauben, „Jetzt freischalten“. Die App erteilt sich darüber dieselben Rechte wie per PC und kann gefundene Werbe- und Tracking-Pakete direkt entfernen und wiederherstellen.

**Die Freischaltung bleibt erhalten, auch wenn Shizuku danach wieder deinstalliert wird.** Das ist empfehlenswert, weil manche Banking-Apps nicht funktionieren, solange Shizuku installiert ist. Die App hat keine Internet-Berechtigung und kann nichts nach außen senden.

## Optional: Freischaltung per PC

Alternative zu Shizuku, nur nötig für den automatischen Durchlauf. Die Anleitung steht in der App unter **„Erweitert“** – passend zum Hersteller, mit Befehlen zum Kopieren. Benötigt werden nur die [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools):

```
adb devices
adb shell pm grant de.hyperos.tuner android.permission.WRITE_SECURE_SETTINGS
adb shell appops set de.hyperos.tuner WRITE_SETTINGS allow
```

Dort zeigt die App außerdem, welche bekannten Werbe- und Tracking-Pakete auf dem Gerät installiert sind, und liefert die passenden Entfernen- und Wiederherstellen-Befehle (`pm uninstall -k --user 0` bzw. `cmd package install-existing`). Ohne PC geht beides über Shizuku (z. B. mit aShell bzw. Canta).

## Wichtig zu wissen

- Menünamen unterscheiden sich je nach Version leicht. Der Sprung-Knopf führt so nah wie möglich an die Stelle, der Weg steht immer dabei.
- Bei anderen Herstellern (OnePlus, Oppo, Motorola …) orientieren sich die Pfade an Standard-Android.
- **Privates DNS** kann in Netzen, die Port 853 sperren, das Internet blockieren und umgeht einen eigenen DNS-Filter im Heimnetz (z. B. Pi-hole).
- **Nie entfernen:** Systemoberfläche, Startbildschirm, Sicherheits- und Paketinstallations-Apps (z. B. `com.miui.securitycenter`, `com.miui.home`).

## Technik

Kotlin, Jetpack Compose, Material 3 mit eigenem Glas-Design, optional Shizuku-API 13.1.5 (`ShizukuBridge.kt`). minSdk 29, targetSdk 35. Texte: `L10n.kt` (Oberfläche), `ManualSteps.kt` (Checkliste je Hersteller), Herstellererkennung: `Platform.kt`, Farbdesigns: `Palettes.kt`. App-ID `de.hyperos.tuner` bleibt für Updates unverändert.

## Quellen (Stand Oktober 2026)

smartzone.de, Notebookcheck (Werbung in HyperOS); techbone.de (HyperOS- und One-UI-Pfade); netzwelt.de (One UI 8.5 „Blockieren von Apps mit übermäßig viel Werbung“, Automatische Sperre); Samsung Community, SamMobile, Android Authority (Automatische Sperre); Android Central, ctrl.blog (Samsung-Werbung, Anpassungsdienst); github.com/ovsky/hyperos-debloater, github.com/BloodBlinker/hyperos-debloat (Debloat-Listen); adguard-dns.io, mullvad.net (DNS-Hostnamen).
