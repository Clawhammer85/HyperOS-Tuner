# HyperOS Privacy Tuner

Android-App für Xiaomi, Redmi und POCO mit HyperOS: eine Checkliste mit empfohlenen Einstellungen für Datenschutz, Sicherheit, Netzwerk, Werbung und Geschwindigkeit – mit Direktsprung in die richtigen Menüs und automatischer Erkennung vieler Werte. Deutsch und Englisch, Glas-Design im Dark Mode.

*An Android app for Xiaomi, Redmi and POCO devices running HyperOS: a checklist of recommended privacy, security, network, ad and performance settings, with shortcuts to the right menus and automatic detection of many values. German and English.*

## Was die App kann

Die App ist **ohne PC und ohne Sonderrechte voll nutzbar**: installieren, öffnen, Checkliste abarbeiten.

| Kategorie | Punkte | davon automatisch erkannt |
|---|---|---|
| Datenschutz | 7 | Sperrbildschirm-Inhalte, Zwischenablage-Hinweis |
| Sicherheit | 11 | Bildschirmsperre, Sicherheitsupdate, Bildschirm-Timeout, USB-Debugging |
| Netzwerk | 4 | WLAN-/Bluetooth-Suche, Privates DNS |
| Werbung | 14 | – (nicht installierte Xiaomi-Apps werden übersprungen) |
| Geschwindigkeit | 6 | Animationen, freier Speicher |

- **Erkennung:** Kommst du aus den Einstellungen zurück, prüft die App die Werte neu und hakt erledigte Punkte selbst ab. Ist ein Wert für Apps verborgen, hakst du ihn von Hand ab.
- **Fortschritt:** Ring und Filter je Kategorie. Optionale Punkte (z. B. Leistungsmodus, Privates DNS) zählen nicht mit.
- **Sprache:** Folgt der Systemsprache, umstellbar über das Kürzel oben rechts. Ab Android 13 auch in den Systemeinstellungen pro App.
- **Farbdesigns:** Lagune, Polarlicht, Amethyst, Glut, Ozean und Graphit – umschaltbar über den Farbkreis oben rechts.
- **Bedienung:** Karten zum Aufklappen, Filter je Kategorie, kurzes haptisches Feedback (folgt der Systemeinstellung „Haptisches Feedback“).

Mit der **optionalen Freischaltung per PC** kommen „Automatisch setzen“- und „Zurücksetzen“-Knöpfe für Animationen, WLAN-/Bluetooth-Suche, Sperrbildschirm, Zwischenablage-Hinweis und Privates DNS dazu. Außerdem lassen sich per Skript Werbe- und Tracking-Dienste entfernen.

### DNS-Anbieter

Alle drei Voreinstellungen sind kostenlos und ohne Konto nutzbar:

- **AdGuard DNS** – `dns.adguard-dns.com` – blockt Werbung und Tracker
- **Mullvad** – `adblock.dns.mullvad.net` – blockt Werbung und Tracker
- **Quad9** – `dns.quad9.net` – gemeinnützig, blockt nur Schadsoftware

Ein eigener Hostname lässt sich ebenfalls eintragen.

## 1. APK bauen

### Mit GitHub (ohne Android Studio)

1. Ein **privates** Repository auf GitHub anlegen.
2. **Am PC:** Zip entpacken und den Inhalt des Ordners `HyperOSTuner` inklusive `.github` hochladen.
   **Am Handy:** `HyperOSTuner.zip` unverändert hochladen und `.github/workflows/apk.yml` von Hand anlegen (Inhalt siehe gleichnamige Datei im Projekt).
3. Der Build startet automatisch (Reiter *Actions*, ca. 5 Minuten). Danach unter *Artifacts* „HyperOSTuner“ herunterladen und entpacken.

**Update:** Neue `HyperOSTuner.zip` unter demselben Namen hochladen – sie ersetzt die alte, der Build startet von selbst. Die neue Version lässt sich direkt über die alte installieren; Haken und Einstellungen bleiben erhalten.

### Mit Android Studio

*File › Open*, diesen Ordner wählen, dann *Build › Build APK(s)*. Die APK liegt unter `app\build\outputs\apk\debug\app-debug.apk`.

Alle Builds werden mit `app/debug.keystore` signiert, damit Updates ohne Deinstallieren funktionieren.

## 2. Installieren

APK aufs Handy kopieren und antippen. HyperOS fragt einmalig, ob der Dateimanager oder Browser „unbekannte Apps installieren“ darf. Danach ist die App sofort nutzbar. Tipp: Die Erlaubnis danach wieder entziehen – das ist auch ein Punkt der Checkliste.

Hinweis: Google führt eine Entwickler-Verifizierung für Apps außerhalb des Play Stores ein (seit 30.09.2026 in Brasilien, Indonesien, Singapur und Thailand, weltweit ab 2027). Installationen per ADB, also über `hyperos-setup.bat`, sind davon ausgenommen.

## 3. Optional: Freischaltung per PC

1. *Einstellungen › Über das Telefon*: siebenmal auf **OS-Version** tippen.
2. *Einstellungen › Weitere Einstellungen › Entwickleroptionen*: **USB-Debugging**, **USB-Debugging (Sicherheitseinstellungen)** (braucht ein Xiaomi-Konto) und optional **Über USB installieren** einschalten.
3. Die [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools) als Ordner `platform-tools` neben `hyperos-setup.bat` entpacken, Handy anschließen, Skript starten:
   - **[1]** App installieren und freischalten (prüft das Ergebnis per `dumpsys`)
   - **[2]** Werbe- und Telemetrie-Dienste entfernen (`pm uninstall -k --user 0`)
   - **[3]** optionale Xiaomi-Apps einzeln abfragen
   - **[4]** alles wiederherstellen (`cmd package install-existing`)

Von Hand: `adb shell pm grant de.hyperos.tuner android.permission.WRITE_SECURE_SETTINGS`

Danach USB-Debugging wieder ausschalten – die Freischaltung bleibt. Die Entwickleroptionen selbst eingeschaltet lassen, sonst setzt Android die Animationswerte zurück.

**Ohne PC:** Über *Kabelloses Debugging* Shizuku einrichten und den Befehl ohne `adb shell` in einem Shizuku-Terminal (z. B. aShell) ausführen. Zum Entfernen von Apps eignet sich Canta.

## Wichtig zu wissen

- Menünamen unterscheiden sich je nach HyperOS-Version leicht. Der Sprung-Knopf führt so nah wie möglich an die Stelle, der Pfad steht immer dabei.
- Große HyperOS-Updates können einzelne Werte zurücksetzen – die Checkliste zeigt sie dann wieder als offen.
- **Privates DNS** kann in Netzen, die Port 853 sperren, das Internet blockieren und umgeht einen eigenen DNS-Filter im Heimnetz (z. B. Pi-hole).
- **Nie entfernen:** `com.miui.securitycenter`, `com.miui.home`, `com.android.thememanager`, `com.miui.global.packageinstaller` – das kann zu Bootloops führen. Das Skript fasst sie nicht an.

## Technik

Kotlin, Jetpack Compose, Material 3 mit eigenem Glas-Design (nur Dark Mode, sechs Farbdesigns in `Palettes.kt`). minSdk 29, targetSdk 35. Texte in `L10n.kt` (Oberfläche) und `ManualSteps.kt` (Checkliste) – für eine weitere Sprache dort ein Feld ergänzen. Die App-ID `de.hyperos.tuner` bleibt unverändert, damit Updates über ältere Versionen installiert werden können.

## Quellen (Stand Oktober 2026)

smartzone.de und Notebookcheck (Werbung in HyperOS), techbone.de (Datenschutz-, SIM- und Sperrbildschirm-Pfade für HyperOS 2), github.com/ovsky/hyperos-debloater und github.com/BloodBlinker/hyperos-debloat (Debloat-Listen), Shizuku-Wiki, adguard-dns.io und mullvad.net (DNS-Hostnamen), Android Authority (Entwickler-Verifizierung).
