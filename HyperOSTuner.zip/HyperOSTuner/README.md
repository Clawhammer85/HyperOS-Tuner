# HyperOS Tuner

Android-App, die auf Xiaomi-, Redmi- und POCO-Geräten mit HyperOS empfohlene Datenschutz- und Geschwindigkeitseinstellungen setzt – und für alles, was eine App nicht setzen darf, eine abhakbare Checkliste mit Direktsprung an die richtige Stelle bietet.

## Was die App kann

Die App ist **ohne PC und ohne Sonderrechte voll nutzbar**: Installieren, öffnen, Checkliste abarbeiten.

| | Ohne Freischaltung | Mit Freischaltung (optional, PC) |
|---|---|---|
| **Checkliste** mit 25 recherchierten Punkten, Pfad, Erklärung und Sprung-Knopf | ✓ | ✓ |
| **Automatische Erkennung** bei Animationen, WLAN-/Bluetooth-Suche, Sperrbildschirm, Privatem DNS: Haken setzt sich selbst, sobald du aus den Einstellungen zurückkommst | ✓ | ✓ |
| Nicht installierte Xiaomi-Apps werden übersprungen, Speichererweiterungs-Tipp passend zum RAM | ✓ | ✓ |
| Privates DNS: Anbieter wählen, Hostnamen kopieren und in den Einstellungen einfügen | ✓ | ✓ |
| Diese Systemwerte **per Knopf setzen und zurücksetzen** | – | ✓ |
| Werbe- und Tracking-Dienste entfernen (`hyperos-setup.bat`) | – | ✓ |

Erkennen kann die App nur Werte, die Android für normale Apps lesbar hält. Ist ein Wert verborgen, wird der Punkt zum normalen Haken-Punkt.

### DNS-Anbieter

Alle drei Voreinstellungen sind kostenlos und ohne Konto nutzbar:

- **AdGuard DNS** – `dns.adguard-dns.com` – blockt Werbung und Tracker
- **Mullvad** – `adblock.dns.mullvad.net` – blockt Werbung und Tracker
- **Quad9** – `dns.quad9.net` – gemeinnützig, blockt nur Schadsoftware

Ein eigener Hostname lässt sich ebenfalls eintragen.

## 1. APK bauen

1. Android Studio installieren (aktuelle Version).
2. *File › Open* und diesen Ordner wählen. Gradle lädt beim ersten Öffnen alles Nötige; bietet Android Studio ein Update von Gradle/AGP an, kannst du es annehmen.
3. *Build › Build App Bundle(s) / APK(s) › Build APK(s)*.
   Die APK liegt danach unter `app\build\outputs\apk\debug\app-debug.apk` – das Skript findet sie dort automatisch.

### Ohne Android Studio: GitHub baut die APK

1. Ein **privates** Repository auf GitHub anlegen und den Inhalt dieses Ordners hochladen (inklusive `.github`).
2. Nach jedem Hochladen baut GitHub die APK automatisch (Reiter *Actions*, Dauer ca. 5 Minuten). Manuell: *Actions › APK bauen › Run workflow*.
3. Im fertigen Lauf unter *Artifacts* „HyperOSTuner“ herunterladen und entpacken – darin liegt `HyperOSTuner.apk`.

Alle Builds werden mit `app/debug.keystore` signiert. Dadurch lässt sich eine neuere Version einfach drüberinstallieren, Freischaltung und Sicherungen bleiben erhalten. Für eine öffentliche Verteilung wäre ein eigener Release-Schlüssel nötig.

## 2. Optional: Freischaltung – Handy vorbereiten

1. *Einstellungen › Über das Telefon*: siebenmal auf **OS-Version** tippen.
2. *Einstellungen › Weitere Einstellungen › Entwickleroptionen*:
   - **USB-Debugging** ein
   - **USB-Debugging (Sicherheitseinstellungen)** ein – braucht ein angemeldetes Xiaomi-Konto. Ohne diesen Schalter lehnt HyperOS `pm grant` mit einer SecurityException ab.
   - **Über USB installieren** ein (nur nötig, wenn das Skript die App installieren soll)
3. Handy per USB anschließen, „USB-Debugging zulassen?“ bestätigen.

## 3. Optional: Skript ausführen

Die [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools) herunterladen und den Ordner `platform-tools` neben `hyperos-setup.bat` entpacken (oder ADB im PATH haben). Dann `hyperos-setup.bat` doppelklicken:

- **[1]** installiert die App bei Bedarf, erteilt `WRITE_SECURE_SETTINGS` und prüft per `dumpsys`, ob es geklappt hat.
- **[2]** entfernt Werbe- und Telemetrie-Dienste (`pm uninstall -k --user 0`).
- **[3]** fragt optionale Xiaomi-Apps (Musik, Video, Browser, GetApps, Joyose …) einzeln ab.
- **[4]** stellt alles wieder her (`cmd package install-existing`). Entfernte Pakete werden in `entfernte-apps.txt` protokolliert.

Entfernt wird nur für den eigenen Benutzer, die Pakete bleiben im System. Ein Werksreset stellt ebenfalls alles wieder her. `pm disable-user` wird bewusst nicht verwendet, weil neuere HyperOS-Versionen das für System-Apps blockieren.

Von Hand reicht für die Freischaltung:

```
adb shell pm grant de.hyperos.tuner android.permission.WRITE_SECURE_SETTINGS
```

## APK ohne Skript installieren

APK aufs Handy kopieren und antippen. HyperOS fragt einmalig, ob der Dateimanager oder Browser „unbekannte Apps installieren“ darf, und lässt die Sicherheits-App die Datei prüfen. Danach ist die App sofort nutzbar.

Hinweis: Google führt eine Entwickler-Verifizierung für Apps außerhalb des Play Stores ein (seit 30.09.2026 in Brasilien, Indonesien, Singapur und Thailand, weltweit ab 2027). Unregistrierte Apps brauchen dann den neuen „erweiterten Ablauf“ mit Wartezeit – Installationen per ADB, also über `hyperos-setup.bat`, sind davon ausgenommen.

## Ohne PC

Über *Kabelloses Debugging* lässt sich Shizuku direkt am Handy starten. Den Befehl oben ohne `adb shell` in einem Shizuku-Terminal (z. B. aShell) ausführen; die Schalter aus Schritt 2 braucht es trotzdem. Zum Entfernen von Apps ohne PC eignet sich Canta (ebenfalls Shizuku).

## Wichtig zu wissen

- **Entwickleroptionen eingeschaltet lassen.** Beim Abschalten setzt Android die Animationswerte zurück. Der Scan der Xiaomi-Sicherheits-App schaltet sie manchmal selbst ab – dann wieder einschalten und in der App erneut anwenden.
- **Große Updates** können einzelne Werte und Werbeschalter zurücksetzen. Der Status in der App zeigt dann wieder „Offen“.
- **Privates DNS** ist absichtlich nicht in „Alle anwenden“ enthalten: In Netzen, die Port 853 sperren (manche Firmen-/Hotel-WLANs), gibt es damit kein Internet, bis man zurücksetzt. Ein eigener DNS-Filter im Heimnetz (z. B. Pi-hole) wird damit umgangen.
- **Sperrbildschirm-Inhalte:** HyperOS hat eigene Sperrbildschirm-Einstellungen. Ob der gesetzte Android-Standardwert greift, kurz mit einer Testnachricht prüfen.
- **Nie entfernen:** `com.miui.securitycenter`, `com.miui.home`, `com.android.thememanager`, `com.miui.global.packageinstaller` – das kann zu Bootloops führen. Das Skript fasst sie nicht an.

## Technik

- Kotlin, Jetpack Compose, Material 3 mit Material-You-Farben, keine weiteren Abhängigkeiten
- minSdk 29, targetSdk 35
- Geschrieben werden nur `Settings.Global` / `Settings.Secure`. Originalwerte liegen in den SharedPreferences `backup`; „Zurücksetzen“ stellt ausschließlich wieder her, was die App selbst geändert hat.

## Quellen der Empfehlungen (Stand Oktober 2026)

- smartzone.de – „Werbung bei Xiaomi, Redmi und Poco mit HyperOS deaktivieren“ (HyperOS 3, aktualisiert Juli 2026)
- notebookcheck.com – „Werbung bei Xiaomi-Smartphones ausschalten“
- techbone.de – Xiaomi-Datenschutzeinstellungen und Diagnosedaten (HyperOS 1/2)
- github.com/ovsky/hyperos-debloater – Phasen-Einteilung, Hinweis zu `pm disable-user` und „USB-Debugging (Sicherheitseinstellungen)“
- github.com/BloodBlinker/hyperos-debloat – Joyose als Spiele-Leistungsprofil
- Shizuku-Wiki (thedjchi) – Sicherheits-App schaltet Entwickleroptionen ab
