package de.hyperos.tuner

import android.app.Activity
import android.app.ActivityManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings

object Launcher {

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /**
     * Probiert die Ziele der Reihe nach und fällt zuletzt auf die Einstellungen zurück.
     * Gibt nur false zurück, wenn gar nichts geöffnet werden konnte.
     */
    fun open(ctx: Context, jumps: List<Jump>): Boolean {
        for (jump in jumps) {
            val intent = toIntent(ctx, jump) ?: continue
            if (start(ctx, intent)) return true
        }
        return start(ctx, Intent(Settings.ACTION_SETTINGS))
    }

    /** Öffnet die Systemseite „Systemeinstellungen ändern“ direkt für diese App. */
    fun openWriteSettings(ctx: Context): Boolean =
        start(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))) ||
            start(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS))

    /** App-Infoseite, z. B. um Shizuku nach der Freischaltung zu deinstallieren. */
    fun openAppDetails(ctx: Context, pkg: String): Boolean =
        start(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

    private fun start(ctx: Context, intent: Intent): Boolean {
        if (ctx !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }
    }

    private fun toIntent(ctx: Context, jump: Jump): Intent? = when (jump) {
        is Jump.Action -> Intent(jump.action)
        is Jump.App -> ctx.packageManager.getLaunchIntentForPackage(jump.pkg)
        is Jump.AppNotifications -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, jump.pkg)
        is Jump.Url -> Intent(Intent.ACTION_VIEW, Uri.parse(jump.uri))
        Jump.Home -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    }
}

object Device {
    /** Nennwert des Arbeitsspeichers in GB (z. B. 8), 0 wenn unbekannt. */
    fun ramGb(ctx: Context): Int {
        val am = ctx.getSystemService(ActivityManager::class.java) ?: return 0
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val gib = info.totalMem / (1024.0 * 1024.0 * 1024.0)
        return intArrayOf(2, 3, 4, 6, 8, 12, 16, 24, 32).firstOrNull { it >= gib } ?: gib.toInt()
    }
}
