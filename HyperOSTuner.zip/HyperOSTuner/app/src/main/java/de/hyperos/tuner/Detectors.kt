package de.hyperos.tuner

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.roundToInt

/** Woran die App erkennt, ob ein Punkt erledigt ist. Alles hier funktioniert ohne Sonderrechte. */
sealed interface Detector {
    data class Values(val tweak: AutoTweak) : Detector
    data object PrivateDns : Detector
    data object ScreenLock : Detector
    data object SecurityPatch : Detector
    data object UsbDebuggingOff : Detector
    data object ScreenTimeout : Detector
    data object FreeStorage : Detector
}

data class Detection(val status: TweakStatus, val info: T? = null)

object Detectors {

    fun evaluate(ctx: Context, repo: SettingsRepo, detector: Detector): Detection = try {
        when (detector) {
            is Detector.Values -> Detection(repo.status(detector.tweak))
            Detector.PrivateDns -> privateDns(repo)
            Detector.ScreenLock -> screenLock(ctx)
            Detector.SecurityPatch -> securityPatch()
            Detector.UsbDebuggingOff -> usbDebugging(ctx)
            Detector.ScreenTimeout -> screenTimeout(ctx)
            Detector.FreeStorage -> freeStorage()
        }
    } catch (e: Exception) {
        Detection(TweakStatus.UNKNOWN)
    }

    private fun privateDns(repo: SettingsRepo): Detection {
        val state = repo.privateDnsState()
        val info = state.host?.let { T("Aktiv: $it", "Active: $it") }
        return Detection(state.status, info)
    }

    private fun screenLock(ctx: Context): Detection {
        val km = ctx.getSystemService(KeyguardManager::class.java) ?: return Detection(TweakStatus.UNKNOWN)
        return Detection(if (km.isDeviceSecure) TweakStatus.ACTIVE else TweakStatus.INACTIVE)
    }

    private fun securityPatch(): Detection {
        val date = runCatching { LocalDate.parse(Build.VERSION.SECURITY_PATCH) }.getOrNull()
            ?: return Detection(TweakStatus.UNKNOWN)
        val ageDays = ChronoUnit.DAYS.between(date, LocalDate.now())
        val de = date.format(DateTimeFormatter.ofPattern("d. MMMM yyyy", Locale.GERMAN))
        val en = date.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH))
        return Detection(
            if (ageDays <= 92) TweakStatus.ACTIVE else TweakStatus.INACTIVE,
            T("Patch-Stand: $de", "Patch level: $en"),
        )
    }

    private fun usbDebugging(ctx: Context): Detection {
        val enabled = Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0)
        return Detection(if (enabled == 0) TweakStatus.ACTIVE else TweakStatus.INACTIVE)
    }

    private fun screenTimeout(ctx: Context): Detection {
        val ms = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, -1)
        if (ms <= 0) return Detection(TweakStatus.UNKNOWN)
        val info = when {
            ms >= Int.MAX_VALUE / 2 -> T("Aktuell: nie", "Currently: never")
            ms >= 60_000 -> {
                val m = ms / 60_000
                T(
                    "Aktuell: $m ${if (m == 1) "Minute" else "Minuten"}",
                    "Currently: $m ${if (m == 1) "minute" else "minutes"}",
                )
            }
            else -> {
                val s = ms / 1000
                T("Aktuell: $s Sekunden", "Currently: $s seconds")
            }
        }
        return Detection(if (ms <= 60_000) TweakStatus.ACTIVE else TweakStatus.INACTIVE, info)
    }

    private fun freeStorage(): Detection {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        if (total <= 0) return Detection(TweakStatus.UNKNOWN)
        val free = stat.availableBytes
        val pct = (free * 100 / total).toInt()
        val gb = (free / 1_000_000_000.0).roundToInt()
        return Detection(
            if (pct >= 15) TweakStatus.ACTIVE else TweakStatus.INACTIVE,
            T("Frei: $pct % (etwa $gb GB)", "Free: $pct% (about $gb GB)"),
        )
    }
}
