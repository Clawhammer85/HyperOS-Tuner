package de.hyperos.tuner

import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** Farben des Glas-Designs. Bewusst nur Dark Mode. */
object Glass {
    val bgTop = Color(0xFF0C1526)
    val bgBottom = Color(0xFF04070D)
    val surface = Color.White.copy(alpha = 0.06f)
    val borderTop = Color.White.copy(alpha = 0.20f)
    val borderBottom = Color.White.copy(alpha = 0.04f)
    val hairline = Color.White.copy(alpha = 0.12f)
    val text = Color(0xFFE8EEF6)
    val textDim = Color(0xFF97A6B9)
    val accent = Color(0xFF2DD4BF)
    val onAccent = Color(0xFF032420)
    val warn = Color(0xFFFBBF24)
    val inset = Color.Black.copy(alpha = 0.35f)
}

private val GlassColors = darkColorScheme(
    primary = Glass.accent,
    onPrimary = Glass.onAccent,
    secondary = Glass.accent,
    background = Glass.bgBottom,
    onBackground = Glass.text,
    surface = Color(0xFF111A2B),
    onSurface = Glass.text,
    surfaceVariant = Color(0xFF1A2438),
    onSurfaceVariant = Glass.textDim,
    surfaceContainer = Color(0xFF141E30),
    outline = Color(0xFF3A475C),
)

@Composable
fun TunerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GlassColors, content = content)
}

// ------------------------------------------------------------------------------- Haptik

/** Kurze, dezente Vibrationen. Folgt der System-Einstellung für haptisches Feedback. */
class Haptics(private val view: View) {
    fun tick() {
        view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    fun tap() {
        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
    }

    fun confirm() {
        view.performHapticFeedback(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.VIRTUAL_KEY
        )
    }

    fun reject() {
        view.performHapticFeedback(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.REJECT
            else HapticFeedbackConstants.LONG_PRESS
        )
    }
}

@Composable
fun rememberHaptics(): Haptics {
    val view = LocalView.current
    return remember(view) { Haptics(view) }
}

// ------------------------------------------------------------------------------- Flächen

/** Dunkler Verlauf mit weichen Farbflecken – dahinter wirken die Glasflächen. */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Glass.bgTop, Glass.bgBottom)))
            .drawBehind {
                glow(Color(0xFF14B8A6), 0.40f, Offset(size.width * 0.05f, size.height * 0.06f), size.width * 0.95f)
                glow(Color(0xFF7C3AED), 0.28f, Offset(size.width * 1.0f, size.height * 0.42f), size.width * 0.85f)
                glow(Color(0xFF0EA5E9), 0.20f, Offset(size.width * 0.2f, size.height * 0.95f), size.width * 0.9f)
            },
        content = content,
    )
}

private fun DrawScope.glow(color: Color, alpha: Float, center: Offset, radius: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(color.copy(alpha = alpha), Color.Transparent),
            center = center,
            radius = radius,
        ),
        radius = radius,
        center = center,
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    tint: Color = Glass.surface,
    shape: Shape = RoundedCornerShape(22.dp),
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .clip(shape)
            .background(tint)
            .border(1.dp, Brush.verticalGradient(listOf(Glass.borderTop, Glass.borderBottom)), shape),
        content = content,
    )
}

// ------------------------------------------------------------------------------- Bedienelemente

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    enabled: Boolean = true,
) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(50)
    val background = when {
        !enabled -> Color.White.copy(alpha = 0.04f)
        primary -> Glass.accent
        else -> Color.White.copy(alpha = 0.08f)
    }
    val foreground = when {
        !enabled -> Glass.textDim.copy(alpha = 0.5f)
        primary -> Glass.onAccent
        else -> Glass.text
    }
    Box(
        modifier
            .defaultMinSize(minHeight = 44.dp)
            .clip(shape)
            .background(background)
            .border(1.dp, if (primary && enabled) Color.Transparent else Glass.hairline, shape)
            .clickable(enabled = enabled) {
                haptics.tap()
                onClick()
            }
            .padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = foreground, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
    }
}

/** Runder Haken. Nur klickbar, wenn [onClick] gesetzt ist; Trefferfläche 48 dp. */
@Composable
fun CheckDot(checked: Boolean, dimmed: Boolean, onClick: (() -> Unit)?) {
    val fill by animateColorAsState(
        targetValue = when {
            !checked -> Color.Transparent
            dimmed -> Glass.textDim.copy(alpha = 0.35f)
            else -> Glass.accent
        },
        label = "checkFill",
    )
    val ring = when {
        checked -> Color.Transparent
        onClick != null -> Color.White.copy(alpha = 0.40f)
        else -> Color.White.copy(alpha = 0.18f)
    }
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(fill)
                .border(1.5.dp, ring, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (checked) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Glass.onAccent, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun RadioDot(selected: Boolean) {
    val ring by animateColorAsState(if (selected) Glass.accent else Color.White.copy(alpha = 0.35f), label = "radio")
    Box(
        Modifier
            .size(20.dp)
            .clip(CircleShape)
            .border(1.5.dp, ring, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Box(
                Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Glass.accent)
            )
        }
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = color,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

@Composable
fun FilterPill(label: String, count: String, color: Color, selected: Boolean, onClick: () -> Unit) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(50)
    val background by animateColorAsState(if (selected) color.copy(alpha = 0.18f) else Glass.surface, label = "pillBg")
    val border by animateColorAsState(if (selected) color.copy(alpha = 0.70f) else Glass.hairline, label = "pillBorder")
    Row(
        Modifier
            .clip(shape)
            .background(background)
            .border(1.dp, border, shape)
            .clickable {
                if (!selected) haptics.tick()
                onClick()
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = Glass.text,
            modifier = Modifier.padding(start = 8.dp),
        )
        Text(
            count,
            style = MaterialTheme.typography.labelMedium,
            color = Glass.textDim,
            modifier = Modifier.padding(start = 6.dp),
        )
    }
}

/** Fortschrittsring mit animiertem Verlauf. */
@Composable
fun ProgressRing(progress: Float, label: String, modifier: Modifier = Modifier) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 800),
        label = "ring",
    )
    Box(modifier.size(88.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 8.dp.toPx()
            val topLeft = Offset(stroke / 2, stroke / 2)
            val arcSize = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = Color.White.copy(alpha = 0.08f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke),
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(Glass.accent, Color(0xFF38BDF8), Color(0xFFA78BFA), Glass.accent)),
                startAngle = -90f,
                sweepAngle = 360f * animated,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
        }
        Text(label, style = MaterialTheme.typography.titleMedium, color = Glass.text, fontWeight = FontWeight.SemiBold)
    }
}

fun percentOf(progress: Float): Int = (progress.coerceIn(0f, 1f) * 100).roundToInt()
