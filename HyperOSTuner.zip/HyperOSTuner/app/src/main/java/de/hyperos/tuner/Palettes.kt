package de.hyperos.tuner

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Ein Farbdesign. Alle Designs sind dunkel; Text- und Glasfarben bleiben gleich. */
data class Palette(
    val id: String,
    val name: T,
    val accent: Color,
    val onAccent: Color,
    val bgTop: Color,
    val bgBottom: Color,
    /** Drei weiche Farbflecken im Hintergrund: oben links, rechts, unten. */
    val glows: List<Color>,
    /** Verlauf für Fortschrittsring, Blitz und Farbmuster. Erste und letzte Farbe gleich = nahtloser Ring. */
    val ring: List<Color>,
)

object Palettes {
    val all = listOf(
        Palette(
            id = "lagoon", name = T("Lagune", "Lagoon"),
            accent = Color(0xFF2DD4BF), onAccent = Color(0xFF032420),
            bgTop = Color(0xFF0C1526), bgBottom = Color(0xFF04070D),
            glows = listOf(Color(0xFF14B8A6), Color(0xFF7C3AED), Color(0xFF0EA5E9)),
            ring = listOf(Color(0xFF2DD4BF), Color(0xFF38BDF8), Color(0xFFA78BFA), Color(0xFF2DD4BF)),
        ),
        Palette(
            id = "aurora", name = T("Polarlicht", "Aurora"),
            accent = Color(0xFF4ADE80), onAccent = Color(0xFF052E16),
            bgTop = Color(0xFF08171A), bgBottom = Color(0xFF030A0A),
            glows = listOf(Color(0xFF22C55E), Color(0xFF06B6D4), Color(0xFF84CC16)),
            ring = listOf(Color(0xFF4ADE80), Color(0xFF22D3EE), Color(0xFFA3E635), Color(0xFF4ADE80)),
        ),
        Palette(
            id = "amethyst", name = T("Amethyst", "Amethyst"),
            accent = Color(0xFFC084FC), onAccent = Color(0xFF2E1065),
            bgTop = Color(0xFF140D26), bgBottom = Color(0xFF07040F),
            glows = listOf(Color(0xFF9333EA), Color(0xFFEC4899), Color(0xFF6366F1)),
            ring = listOf(Color(0xFFC084FC), Color(0xFFF472B6), Color(0xFF818CF8), Color(0xFFC084FC)),
        ),
        Palette(
            id = "ember", name = T("Glut", "Ember"),
            accent = Color(0xFFFB923C), onAccent = Color(0xFF431407),
            bgTop = Color(0xFF1B100D), bgBottom = Color(0xFF0A0605),
            glows = listOf(Color(0xFFF97316), Color(0xFFE11D48), Color(0xFFF59E0B)),
            ring = listOf(Color(0xFFFB923C), Color(0xFFF43F5E), Color(0xFFFBBF24), Color(0xFFFB923C)),
        ),
        Palette(
            id = "ocean", name = T("Ozean", "Ocean"),
            accent = Color(0xFF60A5FA), onAccent = Color(0xFF0B1B3F),
            bgTop = Color(0xFF0A1228), bgBottom = Color(0xFF03060E),
            glows = listOf(Color(0xFF2563EB), Color(0xFF0EA5E9), Color(0xFF6366F1)),
            ring = listOf(Color(0xFF60A5FA), Color(0xFF22D3EE), Color(0xFF818CF8), Color(0xFF60A5FA)),
        ),
        Palette(
            id = "graphite", name = T("Graphit", "Graphite"),
            accent = Color(0xFFE2E8F0), onAccent = Color(0xFF0F172A),
            bgTop = Color(0xFF14171C), bgBottom = Color(0xFF060708),
            glows = listOf(Color(0xFF64748B), Color(0xFF94A3B8), Color(0xFF475569)),
            ring = listOf(Color(0xFFF8FAFC), Color(0xFF94A3B8), Color(0xFFCBD5E1), Color(0xFFF8FAFC)),
        ),
    )

    fun byId(id: String?): Palette = all.firstOrNull { it.id == id } ?: all.first()
}

val LocalPalette = staticCompositionLocalOf { Palettes.all.first() }
