package de.hyperos.tuner

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.ContextWrapper
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal

/**
 * Bestätigung per Fingerabdruck, Gesicht oder Geräte-PIN.
 * Wichtig: Das ist nur eine Zustimmung des Nutzers – zusätzliche Rechte bekommt die App dadurch nicht.
 */
object Auth {

    fun confirm(
        ctx: Context,
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onCancel: () -> Unit,
    ) {
        val activity = ctx.findActivity()
        val keyguard = ctx.getSystemService(KeyguardManager::class.java)
        // Ohne Bildschirmsperre gibt es nichts abzufragen.
        if (activity == null || keyguard == null || !keyguard.isDeviceSecure) {
            onSuccess()
            return
        }
        val builder = BiometricPrompt.Builder(activity)
            .setTitle(title)
            .setSubtitle(subtitle)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
        } else {
            @Suppress("DEPRECATION")
            builder.setDeviceCredentialAllowed(true)
        }
        try {
            builder.build().authenticate(
                CancellationSignal(),
                activity.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        onCancel()
                    }
                },
            )
        } catch (e: Exception) {
            onCancel()
        }
    }
}

fun Context.findActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return null
}
