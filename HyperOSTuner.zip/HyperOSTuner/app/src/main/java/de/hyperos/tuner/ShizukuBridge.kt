package de.hyperos.tuner

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.lang.reflect.InvocationTargetException

/**
 * Optionaler Weg zur Freischaltung ohne PC.
 * Shizuku führt Befehle mit denselben Rechten aus wie ein per USB verbundener PC (ADB).
 * Die so erteilten Rechte bleiben erhalten, auch wenn Shizuku danach deinstalliert wird.
 */
object ShizukuBridge {

    /** Original und der empfohlene Fork verwenden denselben Paketnamen. */
    const val PACKAGE = "moe.shizuku.privileged.api"
    const val FORK_URL = "https://github.com/thedjchi/Shizuku/releases"
    const val PLAY_URL = "https://play.google.com/store/apps/details?id=$PACKAGE"
    private const val REQUEST_CODE = 4711

    enum class State { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

    data class ExecResult(val ok: Boolean, val output: String)

    fun state(ctx: Context): State = when {
        isRunning() -> if (hasPermission()) State.READY else State.NO_PERMISSION
        Launcher.isInstalled(ctx, PACKAGE) -> State.NOT_RUNNING
        else -> State.NOT_INSTALLED
    }

    private fun isRunning(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11()
    } catch (e: Throwable) {
        false
    }

    private fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Zeigt den Shizuku-Dialog „Zugriff erlauben?“. */
    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku läuft nicht mehr – der Zustand wird beim nächsten Prüfen korrigiert.
        }
    }

    /** Führt einen Shell-Befehl über Shizuku aus (im Hintergrund-Thread). */
    suspend fun exec(command: String): ExecResult = withContext(Dispatchers.IO) {
        try {
            // newProcess ist in der aktuellen API nicht öffentlich, für einzelne Befehle aber der einfachste Weg.
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java,
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val error = process.errorStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            ExecResult(code == 0, (output + "\n" + error).trim())
        } catch (e: Throwable) {
            val cause = (e as? InvocationTargetException)?.targetException ?: e
            ExecResult(false, cause.message ?: cause.javaClass.simpleName)
        }
    }
}
