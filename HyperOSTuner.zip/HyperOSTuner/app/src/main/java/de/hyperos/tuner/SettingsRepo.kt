package de.hyperos.tuner

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

enum class TweakStatus { ACTIVE, INACTIVE, UNKNOWN }

data class DnsState(val status: TweakStatus, val host: String?)

/**
 * Liest Settings.Global/Secure (geht ohne Freischaltung) und schreibt sie
 * (nur mit WRITE_SECURE_SETTINGS). Vor der ersten Änderung eines Schlüssels wird der Originalwert gesichert,
 * damit „Zurücksetzen“ genau den Zustand vor der App wiederherstellt.
 */
class SettingsRepo(private val ctx: Context) {

    private val cr: ContentResolver = ctx.contentResolver
    private val backup = ctx.getSharedPreferences("backup", Context.MODE_PRIVATE)

    fun hasWritePermission(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /** Erlaubnis „Systemeinstellungen ändern“ – vergibt der Nutzer selbst mit einem Schalter. */
    fun canWriteSystem(): Boolean = Settings.System.canWrite(ctx)

    /** Darf die App alle Werte dieses Punkts schreiben? */
    fun canApply(tweak: AutoTweak): Boolean = tweak.writes.all {
        if (it.table == Table.SYSTEM) canWriteSystem() else hasWritePermission()
    }

    fun status(tweak: AutoTweak): TweakStatus {
        var unknown = false
        for (w in tweak.writes) {
            val v = read(w.table, w.key)
            if (v == UNREADABLE) {
                unknown = true
                continue
            }
            if (!sameValue(v ?: w.androidDefault, w.value)) return TweakStatus.INACTIVE
        }
        return if (unknown) TweakStatus.UNKNOWN else TweakStatus.ACTIVE
    }

    fun devOptionsEnabled(): Boolean =
        read(Table.GLOBAL, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED) == "1"

    /** Erkennt Privates DNS unabhängig davon, welcher Anbieter eingetragen ist. */
    fun privateDnsState(): DnsState {
        val mode = read(Table.GLOBAL, "private_dns_mode")
        if (mode == UNREADABLE) return DnsState(TweakStatus.UNKNOWN, null)
        if (mode != "hostname") return DnsState(TweakStatus.INACTIVE, null)
        val host = read(Table.GLOBAL, "private_dns_specifier")
        if (host == null || host == UNREADABLE || host.isBlank()) return DnsState(TweakStatus.ACTIVE, null)
        return DnsState(TweakStatus.ACTIVE, host)
    }

    fun hasBackup(tweak: AutoTweak): Boolean =
        tweak.writes.any { backup.contains(backupKey(it)) }

    /** Setzt die empfohlenen Werte. Gibt die Schlüssel zurück, die nicht geschrieben werden konnten. */
    fun apply(tweak: AutoTweak): List<String> {
        val failed = mutableListOf<String>()
        for (w in tweak.writes) {
            val bk = backupKey(w)
            val createdBackup = !backup.contains(bk)
            if (createdBackup) {
                val current = read(w.table, w.key)
                val saved = if (current == null || current == UNREADABLE) NULL_MARK else current
                backup.edit().putString(bk, saved).apply()
            }
            if (!write(w.table, w.key, w.value)) {
                failed += w.key
                if (createdBackup) backup.edit().remove(bk).apply()
            }
        }
        return failed
    }

    /** Stellt nur zurück, was die App selbst geändert hat. */
    fun restore(tweak: AutoTweak): List<String> {
        val failed = mutableListOf<String>()
        for (w in tweak.writes) {
            val bk = backupKey(w)
            val saved = backup.getString(bk, null) ?: continue
            val target = if (saved == NULL_MARK) w.androidDefault else saved
            if (write(w.table, w.key, target)) {
                backup.edit().remove(bk).apply()
            } else {
                failed += w.key
            }
        }
        return failed
    }

    private fun read(table: Table, key: String): String? = try {
        when (table) {
            Table.GLOBAL -> Settings.Global.getString(cr, key)
            Table.SECURE -> Settings.Secure.getString(cr, key)
            Table.SYSTEM -> Settings.System.getString(cr, key)
        }
    } catch (e: Exception) {
        // Ab Android 12 sind manche versteckten Schlüssel für Apps nicht lesbar.
        UNREADABLE
    }

    private fun write(table: Table, key: String, value: String): Boolean = try {
        when (table) {
            Table.GLOBAL -> Settings.Global.putString(cr, key, value)
            Table.SECURE -> Settings.Secure.putString(cr, key, value)
            Table.SYSTEM -> Settings.System.putString(cr, key, value)
        }
    } catch (e: Exception) {
        false
    }

    private fun backupKey(w: SettingWrite) = "${w.table.name}:${w.key}"

    private fun sameValue(a: String, b: String): Boolean {
        if (a == b) return true
        val fa = a.toFloatOrNull()
        val fb = b.toFloatOrNull()
        return fa != null && fb != null && fa == fb
    }

    private companion object {
        const val UNREADABLE = "<<nicht-lesbar>>"
        const val NULL_MARK = "<<nicht-gesetzt>>"
    }
}
