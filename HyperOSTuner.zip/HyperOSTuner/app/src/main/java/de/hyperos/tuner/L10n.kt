package de.hyperos.tuner

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf

enum class Lang { DE, EN }

/** Ein Text in allen unterstützten Sprachen. Neue Sprache: Feld ergänzen und in [get] zuordnen. */
data class T(val de: String, val en: String) {
    fun get(lang: Lang): String = when (lang) {
        Lang.DE -> de
        Lang.EN -> en
    }
}

val LocalLang = staticCompositionLocalOf { Lang.DE }

@Composable
fun T.str(): String = get(LocalLang.current)

/** Texte der Oberfläche. Die Inhalte der Checkliste stehen in ManualSteps.kt. */
object S {
    val tabChecklist = T("Checkliste", "Checklist")
    val tabPc = T("PC (optional)", "PC (optional)")
    val langSystem = T("Systemsprache", "System language")
    val language = T("Sprache", "Language")
    val theme = T("Farbdesign", "Color theme")

    fun progress(done: Int, total: Int) =
        T("$done von $total Empfehlungen erledigt", "$done of $total recommendations done")
    val progressHint = T(
        "Tippe einen Punkt an, um zu sehen, wie es geht. Vieles hakt die App selbst ab, sobald du zurückkommst.",
        "Tap an item to see how it works. Many items are checked off automatically when you come back.",
    )

    // ---- Ansichten und „Nächster Schritt“ ----------------------------------------------
    val modeEssentials = T("Das Wichtigste", "Essentials")
    val modeAll = T("Alle Punkte", "All items")
    val nextTitle = T("NÄCHSTER SCHRITT", "NEXT STEP")
    val nextDo = T("Jetzt einstellen", "Set it now")
    val nextDone = T("Erledigt", "Done")
    val nextSkip = T("Später", "Later")
    val nextAuto = T(
        "Wenn du zurückkommst, prüft die App selbst, ob es geklappt hat.",
        "When you come back, the app checks by itself whether it worked.",
    )
    val skippedText = T(
        "Ein paar Punkte hast du auf später verschoben.",
        "You postponed a few items.",
    )
    val skippedShow = T("Jetzt ansehen", "Show them now")
    val essentialsDone = T(
        "Geschafft! Die wichtigsten Punkte sind erledigt.",
        "Done! The most important items are taken care of.",
    )
    val essentialsDoneHint = T(
        "Wenn du magst, findest du unter „Alle Punkte“ weitere Empfehlungen – nichts davon ist Pflicht.",
        "If you like, “All items” has more recommendations – none of them are required.",
    )
    val showAll = T("Alle Punkte ansehen", "Show all items")
    val allDone = T("Alles erledigt – dein Gerät ist gut eingestellt.", "All done – your device is well configured.")
    val listEssentials = T("Alle wichtigen Punkte", "All essential items")
    val helpTitle = T("Hilfe", "Help")
    val helpText = T(
        "Keine Sorge: Die App ändert nichts ohne dich, und jede Einstellung lässt sich jederzeit zurückdrehen.",
        "Don't worry: the app changes nothing without you, and every setting can be reverted at any time.",
    )
    val replayIntro = T("Einführung erneut ansehen", "Show introduction again")

    // ---- Einführung ---------------------------------------------------------------------
    val obSkip = T("Überspringen", "Skip")
    val obBack = T("Zurück", "Back")
    val obNext = T("Weiter", "Next")
    val obStart = T("Los geht's", "Let's go")
    val ob1Title = T("Mehr Privatsphäre in ein paar Minuten", "More privacy in a few minutes")
    val ob1Text = T(
        "Diese App zeigt dir, welche Einstellungen dein Handy privater, sicherer und schneller machen – und " +
            "bringt dich direkt an die richtige Stelle. Umstellen tust du selbst, mit einem Fingertipp.",
        "This app shows you which settings make your phone more private, secure and faster – and takes you " +
            "straight to the right place. You make the change yourself, with a single tap.",
    )
    val ob2Title = T("So funktioniert's", "How it works")
    val ob2Steps = listOf(
        T("Tippe auf „Jetzt einstellen“ – die App öffnet die passende Einstellung.", "Tap “Set it now” – the app opens the right setting."),
        T("Stell den Schalter um, wie es in der Anleitung steht.", "Flip the switch as described in the instructions."),
        T("Komm zurück – vieles hakt die App selbst ab, den Rest hakst du ab.", "Come back – many items are checked automatically, you check off the rest."),
    )
    val ob3Title = T("Keine Sorge", "Don't worry")
    val ob3Text = T(
        "Die App ändert nichts ohne dich, und jede Einstellung lässt sich jederzeit zurückdrehen. Wir starten mit " +
            "dem Wichtigsten – alle weiteren Punkte kannst du dir später in Ruhe ansehen.",
        "The app changes nothing without you, and every setting can be reverted at any time. We start with the " +
            "essentials – you can look at everything else later at your own pace.",
    )
    fun obDetected(platform: Platform) = T("Erkannt: ${platform.label.de}", "Detected: ${platform.label.en}")
    fun percent(p: Int) = T("$p %", "$p%")
    val autoApplyAll = T("Systemwerte automatisch setzen", "Apply system values automatically")
    val allApplied = T("Systemwerte gesetzt", "System values applied")
    val filterAll = T("Alle", "All")

    val pillDetected = T("Erkannt", "Detected")
    val pillOpen = T("Offen", "Open")
    val pillOptional = T("Optional", "Optional")
    val pillNotInstalled = T("Nicht installiert", "Not installed")
    val detectedDone = T("Eingestellt – von der App erkannt", "Set – detected by the app")
    val detectedOpen = T(
        "Noch nicht eingestellt. Die App prüft das erneut, sobald du zurückkommst.",
        "Not set yet. The app checks again when you come back.",
    )
    val notInstalled = T(
        "Die App ist nicht installiert – hier gibt es nichts zu tun.",
        "The app isn't installed – nothing to do here.",
    )
    val howTo = T("So geht's", "How to")
    val autoSet = T("Automatisch setzen", "Set automatically")
    val restore = T("Zurücksetzen", "Reset")
    val copyHost = T("Hostname kopieren", "Copy hostname")
    fun copiedHost(host: String) = T("Kopiert: $host", "Copied: $host")
    val hostname = T("Hostname", "Hostname")
    val openFailed = T(
        "Konnte nichts öffnen – bitte über den angegebenen Pfad gehen.",
        "Couldn't open anything – please follow the path shown.",
    )
    fun notSet(keys: String) = T("Nicht gesetzt: $keys", "Not set: $keys")
    fun applied(title: String) = T("„$title“ gesetzt", "“$title” applied")
    fun restored(title: String) = T("„$title“ zurückgesetzt", "“$title” reset")
    val openSettings = T("Einstellungen öffnen", "Open settings")

    // ---- Gerät / Plattform ------------------------------------------------------------
    val device = T("Gerät", "Device")
    fun platformAuto(detected: Platform) =
        T("Automatisch – ${detected.label.de}", "Automatic – ${detected.label.en}")

    // ---- PC (optional) ----------------------------------------------------------------
    val statusGranted = T(
        "Freischaltung aktiv. In der Checkliste setzt die App Systemwerte jetzt auf Knopfdruck selbst. " +
            "Diese Seite brauchst du nur noch, wenn du per PC Apps entfernen willst.",
        "Unlocked. The app now sets system values itself from the checklist. You only need this page " +
            "if you want to remove apps via PC.",
    )
    val statusNotGranted = T(
        "Nicht nötig – die Checkliste funktioniert komplett ohne. Eine einmalige Freischaltung am PC spart " +
            "nur Handgriffe: Die App setzt dann Animationen, WLAN-/Bluetooth-Suche, Sperrbildschirm, " +
            "Zwischenablage-Hinweis und Privates DNS selbst und kann sie zurücksetzen.",
        "Not required – the checklist works completely without it. A one-time unlock via PC only saves a " +
            "few taps: the app can then set animations, Wi‑Fi/Bluetooth scanning, lock screen, clipboard " +
            "notice and Private DNS itself – and reset them.",
    )
    val prepTitle = T("Am Handy vorbereiten", "Prepare the phone")
    val commandTitle = T("Am PC freischalten", "Unlock on the PC")
    val commandText = T(
        "Die „Android SDK Platform-Tools“ von developer.android.com herunterladen und entpacken. Im Ordner ein " +
            "Terminal öffnen – unter Windows in die Adresszeile des Explorers „cmd“ tippen – und die Befehle " +
            "ausführen. Die erste Zeile prüft, ob das Handy erkannt wird. Ob die Freischaltung geklappt hat, " +
            "zeigt diese App selbst an.",
        "Download and unzip the “Android SDK Platform-Tools” from developer.android.com. Open a terminal in the " +
            "folder – on Windows, type “cmd” into the Explorer address bar – and run the commands. The first " +
            "line checks whether the phone is detected. This app shows you whether the unlock worked.",
    )
    val afterTitle = T("Danach", "Afterwards")
    val debloatTitle = T("Werbe- und Tracking-Dienste entfernen", "Remove ad and tracking services")
    val debloatNone = T(
        "Keines der bekannten Werbe- oder Tracking-Pakete ist installiert – hier gibt es nichts zu tun.",
        "None of the known ad or tracking packages is installed – nothing to do here.",
    )
    val debloatTools = T(
        "Für mehr: Canta (am Handy, über Shizuku) oder Universal Android Debloater (am PC) zeigen zu jedem Paket, " +
            "wie riskant das Entfernen ist. Nie entfernen: Systemoberfläche, Startbildschirm, Sicherheits- und " +
            "Paketinstallations-Apps – das kann das Gerät unbrauchbar machen.",
        "For more: Canta (on the phone, via Shizuku) or Universal Android Debloater (on the PC) show how risky " +
            "removing each package is. Never remove system UI, launcher, security or package installer apps – " +
            "that can brick the device.",
    )
    val copyCommands = T("Befehle kopieren", "Copy commands")
    val copyRemove = T("Entfernen-Befehle kopieren", "Copy removal commands")
    val copyRestore = T("Wiederherstellen-Befehle kopieren", "Copy restore commands")
    val copied = T("Kopiert", "Copied")
    val noPcTitle = T("Ohne PC", "Without a PC")
    val noPcText = T(
        "Über „Kabelloses Debugging“ geht es auch direkt am Handy: Shizuku einrichten und die Befehle ohne " +
            "„adb shell“ in einem Shizuku-Terminal wie aShell ausführen. Die Vorbereitung oben braucht es trotzdem, " +
            "nur das Kabel entfällt. Zum Entfernen von Apps eignet sich Canta, das ebenfalls über Shizuku läuft.",
        "Using “Wireless debugging”, it also works directly on the phone: set up Shizuku and run the commands " +
            "without “adb shell” in a Shizuku terminal such as aShell. You still need the preparation above, just " +
            "no cable. To remove apps, Canta works well – it also runs via Shizuku.",
    )
}

/** Texte für „PC (optional)“, die je nach Oberfläche abweichen. */
object Setup {
    private val connect = T(
        "Handy per USB mit dem PC verbinden und „USB-Debugging zulassen?“ bestätigen.",
        "Connect the phone to the PC via USB and confirm “Allow USB debugging?”.",
    )

    fun prepSteps(platform: Platform): List<T> = when (platform) {
        Platform.XIAOMI -> listOf(
            T(
                "Einstellungen › Über das Telefon: siebenmal auf „OS-Version“ tippen, bis die Entwickleroptionen freigeschaltet sind.",
                "Settings › About phone: tap “OS version” seven times until developer options are enabled.",
            ),
            T(
                "Einstellungen › Weitere Einstellungen › Entwickleroptionen: „USB-Debugging“ einschalten.",
                "Settings › Additional settings › Developer options: turn on “USB debugging”.",
            ),
            T(
                "Darunter „USB-Debugging (Sicherheitseinstellungen)“ einschalten. Dafür muss ein Xiaomi-Konto angemeldet " +
                    "sein – ohne diesen Schalter lehnt HyperOS die Befehle ab.",
                "Below it, turn on “USB debugging (Security settings)”. This requires a signed-in Xiaomi account – " +
                    "without it, HyperOS rejects the commands.",
            ),
            connect,
        )
        Platform.SAMSUNG -> listOf(
            T(
                "Einstellungen › Telefoninfo › Softwareinformationen: siebenmal auf „Buildnummer“ tippen.",
                "Settings › About phone › Software information: tap “Build number” seven times.",
            ),
            T(
                "Einstellungen › Sicherheit und Datenschutz › „Automatische Sperre“ vorübergehend ausschalten – sie blockiert Befehle über USB.",
                "Settings › Security and privacy › temporarily turn off “Auto Blocker” – it blocks commands via USB.",
            ),
            T(
                "Einstellungen › Entwickleroptionen: „USB-Debugging“ einschalten.",
                "Settings › Developer options: turn on “USB debugging”.",
            ),
            connect,
        )
        Platform.GENERIC -> listOf(
            T(
                "Einstellungen › Über das Telefon: siebenmal auf „Build-Nummer“ tippen.",
                "Settings › About phone: tap “Build number” seven times.",
            ),
            T(
                "Einstellungen › System › Entwickleroptionen: „USB-Debugging“ einschalten.",
                "Settings › System › Developer options: turn on “USB debugging”.",
            ),
            connect,
        )
    }

    fun after(platform: Platform): List<T> = buildList {
        add(
            T(
                "USB-Debugging wieder ausschalten – die Berechtigung bleibt erhalten. Die Entwickleroptionen selbst " +
                    "eingeschaltet lassen, sonst setzt Android die Animationswerte zurück.",
                "Turn USB debugging off again – the permission stays. Keep developer options themselves on, " +
                    "otherwise Android resets the animation values.",
            )
        )
        when (platform) {
            Platform.XIAOMI -> add(
                T(
                    "Der Scan der Sicherheits-App schaltet die Entwickleroptionen manchmal ab – dann einfach wieder einschalten.",
                    "The Security app scan sometimes turns developer options off – just turn them back on.",
                )
            )
            Platform.SAMSUNG -> add(
                T("„Automatische Sperre“ danach wieder einschalten.", "Turn “Auto Blocker” back on afterwards.")
            )
            Platform.GENERIC -> Unit
        }
        add(
            T(
                "Große Updates können einzelne Werte zurücksetzen – die Checkliste zeigt sie dann wieder als offen.",
                "Major updates can reset individual values – the checklist then shows them as open again.",
            )
        )
    }

    fun debloatIntro(platform: Platform): T = when (platform) {
        Platform.XIAOMI -> T(
            "Werbe- und Telemetriedienste wie msa oder Analytics lassen sich ohne Root nur per ADB entfernen. Das gilt " +
                "nur für deinen Benutzer – mit den Wiederherstellen-Befehlen oder einem Werksreset ist alles wieder da. " +
                "Auf deinem Gerät gefunden:",
            "Ad and telemetry services such as msa or Analytics can only be removed via ADB without root. This only " +
                "affects your user – the restore commands or a factory reset bring everything back. Found on your device:",
        )
        Platform.SAMSUNG -> T(
            "Samsung-Systempakete hängen eng zusammen, deshalb hier nur eine kurze, unkritische Liste. Entfernt wird " +
                "nur für deinen Benutzer und lässt sich wiederherstellen. Auf deinem Gerät gefunden:",
            "Samsung system packages are tightly linked, so this is only a short, safe list. Removal only affects your " +
                "user and can be undone. Found on your device:",
        )
        Platform.GENERIC -> T(
            "Vorinstallierte Zusatzdienste lassen sich per ADB für deinen Benutzer entfernen und jederzeit " +
                "wiederherstellen. Auf deinem Gerät gefunden:",
            "Preinstalled extra services can be removed for your user via ADB and restored at any time. Found on your device:",
        )
    }
}
