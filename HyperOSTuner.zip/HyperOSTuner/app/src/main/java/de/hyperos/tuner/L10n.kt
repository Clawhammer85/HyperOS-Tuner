package de.hyperos.tuner

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf

enum class Lang { DE, EN }

/** Ein Text in allen unterstützten Sprachen. Neue Sprache: Feld ergänzen und in [get] zuordnen. */
data class T(val de: String, val en: String) {
    fun get(lang: Lang): String = when (lang) {
        Lang.DE -> de
        Lang.EN -> en
    }
}

val LocalLang = staticCompositionLocalOf { Lang.DE }

@Composable
fun T.str(): String = get(LocalLang.current)

/** Texte der Oberfläche. Die Inhalte der Checkliste stehen in ManualSteps.kt. */
object S {
    val tabChecklist = T("Checkliste", "Checklist")
    val tabPc = T("PC (optional)", "PC (optional)")
    val langSystem = T("Systemsprache", "System language")

    fun progress(done: Int, total: Int) =
        T("$done von $total Empfehlungen erledigt", "$done of $total recommendations done")
    val progressHint = T(
        "Tippe einen Punkt an, um Details zu sehen. Systemwerte erkennt die App selbst, sobald du zurückkommst.",
        "Tap an item to see details. System values are detected automatically when you come back.",
    )
    fun percent(p: Int) = T("$p %", "$p%")
    val autoApplyAll = T("Systemwerte automatisch setzen", "Apply system values automatically")
    val allApplied = T("Systemwerte gesetzt", "System values applied")
    val filterAll = T("Alle", "All")

    val pillDetected = T("Erkannt", "Detected")
    val pillOpen = T("Offen", "Open")
    val pillOptional = T("Optional", "Optional")
    val pillNotInstalled = T("Nicht installiert", "Not installed")
    val detectedDone = T("Eingestellt – von der App erkannt", "Set – detected by the app")
    val detectedOpen = T(
        "Noch nicht eingestellt. Die App prüft das erneut, sobald du zurückkommst.",
        "Not set yet. The app checks again when you come back.",
    )
    val notInstalled = T(
        "Die App ist nicht installiert – hier gibt es nichts zu tun.",
        "The app isn't installed – nothing to do here.",
    )
    val where = T("Wo", "Where")
    val autoSet = T("Automatisch setzen", "Set automatically")
    val restore = T("Zurücksetzen", "Reset")
    val copyHost = T("Hostname kopieren", "Copy hostname")
    fun copiedHost(host: String) = T("Kopiert: $host", "Copied: $host")
    val hostname = T("Hostname", "Hostname")
    val openFailed = T(
        "Konnte nichts öffnen – bitte über den angegebenen Pfad gehen.",
        "Couldn't open anything – please follow the path shown.",
    )
    fun notSet(keys: String) = T("Nicht gesetzt: $keys", "Not set: $keys")
    fun applied(title: String) = T("„$title“ gesetzt", "“$title” applied")
    fun restored(title: String) = T("„$title“ zurückgesetzt", "“$title” reset")
    val openSettings = T("Einstellungen öffnen", "Open settings")

    // ---- PC (optional) ----------------------------------------------------------------
    val statusGranted = T(
        "Freischaltung aktiv. In der Checkliste setzt die App Systemwerte jetzt auf Knopfdruck selbst. " +
            "Diese Seite brauchst du nur noch, wenn du per PC Apps entfernen willst.",
        "Unlocked. The app now sets system values itself from the checklist. You only need this page " +
            "if you want to remove apps via PC.",
    )
    val statusNotGranted = T(
        "Nicht nötig – die Checkliste funktioniert komplett ohne. Eine einmalige Freischaltung am PC spart " +
            "nur Handgriffe: Die App setzt dann Animationen, WLAN-/Bluetooth-Suche, Sperrbildschirm, " +
            "Zwischenablage-Hinweis und Privates DNS selbst und kann sie zurücksetzen.",
        "Not required – the checklist works completely without it. A one-time unlock via PC only saves a " +
            "few taps: the app can then set animations, Wi‑Fi/Bluetooth scanning, lock screen, clipboard " +
            "notice and Private DNS itself – and reset them.",
    )
    val prepTitle = T("Freischaltung: am Handy vorbereiten", "Unlock: prepare the phone")
    val prepSteps = listOf(
        T(
            "Einstellungen › Über das Telefon: siebenmal auf „OS-Version“ tippen, bis die Entwickleroptionen freigeschaltet sind.",
            "Settings › About phone: tap “OS version” seven times until developer options are enabled.",
        ),
        T(
            "Einstellungen › Weitere Einstellungen › Entwickleroptionen: „USB-Debugging“ einschalten.",
            "Settings › Additional settings › Developer options: turn on “USB debugging”.",
        ),
        T(
            "Darunter „USB-Debugging (Sicherheitseinstellungen)“ einschalten. Dafür muss ein Xiaomi-Konto angemeldet " +
                "sein – ohne diesen Schalter lehnt HyperOS die Freischaltung ab.",
            "Below it, turn on “USB debugging (Security settings)”. This requires a signed-in Xiaomi account – " +
                "without it, HyperOS rejects the unlock.",
        ),
        T(
            "Damit das Skript die App gleich mitinstalliert: zusätzlich „Über USB installieren“ einschalten.",
            "If the script should install the app as well: also turn on “Install via USB”.",
        ),
        T(
            "Handy per USB mit dem PC verbinden und „USB-Debugging zulassen?“ bestätigen.",
            "Connect the phone to the PC via USB and confirm “Allow USB debugging?”.",
        ),
    )
    val commandTitle = T("Am PC freischalten", "Unlock on the PC")
    val commandText = T(
        "Im Projektordner hyperos-setup.bat starten und Punkt 1 wählen. Das Skript installiert die App bei Bedarf " +
            "und prüft, ob die Freischaltung geklappt hat. Von Hand geht es mit diesem Befehl:",
        "Run hyperos-setup.bat in the project folder and choose option 1. The script installs the app if needed " +
            "and checks whether the unlock worked. To do it manually, use this command:",
    )
    val afterTitle = T("Danach", "Afterwards")
    val after1 = T(
        "USB-Debugging wieder ausschalten – die Berechtigung bleibt erhalten. Die Entwickleroptionen selbst bitte " +
            "eingeschaltet lassen, sonst setzt Android die Animationswerte zurück.",
        "Turn USB debugging off again – the permission stays. Keep developer options themselves switched on, " +
            "otherwise Android resets the animation values.",
    )
    val after2 = T(
        "Der Scan der Sicherheits-App schaltet die Entwickleroptionen manchmal ab, und große HyperOS-Updates setzen " +
            "einzelne Werte zurück. Die Checkliste zeigt den Punkt dann wieder als offen an.",
        "The Security app scan sometimes turns developer options off, and major HyperOS updates can reset " +
            "individual values. The checklist then shows the item as open again.",
    )
    val debloatTitle = T("Werbe- und Tracking-Dienste entfernen", "Remove ad and tracking services")
    val debloatText = T(
        "Dienste wie msa, Analytics oder das Hintergrund-Karussell lassen sich nur per ADB entfernen – eine App kann " +
            "das ohne Root nicht. hyperos-setup.bat erledigt das unter Punkt 2 und 3. Entfernt wird nur für deinen " +
            "Benutzer: Über Punkt 4 oder einen Werksreset ist alles wieder da.",
        "Services such as msa, Analytics or the wallpaper carousel can only be removed via ADB – an app can't do " +
            "that without root. hyperos-setup.bat handles this with options 2 and 3. Apps are only removed for " +
            "your user: option 4 or a factory reset brings everything back.",
    )
    val noPcTitle = T("Ohne PC", "Without a PC")
    val noPcText = T(
        "Über „Kabelloses Debugging“ geht es auch direkt am Handy: Shizuku einrichten und den Befehl unten in einem " +
            "Shizuku-Terminal wie aShell ausführen. Die Schalter aus Schritt 1 bis 3 braucht es trotzdem. Zum " +
            "Entfernen von Apps ohne PC eignet sich Canta, das ebenfalls über Shizuku läuft.",
        "Using “Wireless debugging”, it also works directly on the phone: set up Shizuku and run the command below " +
            "in a Shizuku terminal such as aShell. You still need the switches from steps 1 to 3. To remove apps " +
            "without a PC, Canta works well – it also runs via Shizuku.",
    )
    val copyCommand = T("Befehl kopieren", "Copy command")
    val copied = T("Befehl kopiert", "Command copied")
}
