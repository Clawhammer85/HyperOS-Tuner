package de.hyperos.tuner

import android.content.Intent
import android.provider.Settings

/** Wohin der „Öffnen“-Knopf springt. Mehrere Ziele werden der Reihe nach probiert. */
sealed interface Jump {
    data class Action(val action: String) : Jump
    data class App(val pkg: String) : Jump
    data class AppNotifications(val pkg: String) : Jump
    data class Url(val uri: String) : Jump
    data object Home : Jump
}

data class ManualStep(
    val id: String,
    val category: Category,
    val title: T,
    /** Wo der Schalter liegt. Menünamen können je nach HyperOS-Version leicht abweichen. */
    val path: T,
    val why: T? = null,
    val jumps: List<Jump> = emptyList(),
    val openLabel: T = S.openSettings,
    /** Ist das Paket nicht installiert, entfällt der Punkt. */
    val requiresPackage: String? = null,
    /** Woran die App selbst erkennt, ob der Punkt erledigt ist. */
    val detector: Detector? = null,
    /** Optionale Punkte zählen nicht in den Fortschritt. */
    val optional: Boolean = false,
) {
    /** Gehört zu „Das Wichtigste“ – der Einstieg für neue Nutzer. */
    val essential: Boolean get() = id in ManualSteps.ESSENTIAL_ORDER
}

/**
 * Empfehlungen je Oberfläche (Xiaomi HyperOS, Samsung One UI, Android allgemein).
 * Quellen: smartzone.de, Notebookcheck, techbone.de, netzwelt.de, Samsung Community, SamMobile,
 * Android Authority, Debloat-Projekte auf GitHub, adguard-dns.io, mullvad.net (Stand Oktober 2026).
 */
object ManualSteps {

    // Xiaomi
    private const val MSA = "com.miui.msa.global"
    private const val CAROUSEL = "com.miui.android.fashiongallery"
    private const val APP_VAULT = "com.mi.globalminusscreen"
    private const val MI_SECURITY = "com.miui.securitycenter"
    private const val MI_DOWNLOADS = "com.android.providers.downloads.ui"
    private const val MI_THEMES = "com.android.thememanager"
    private const val MI_FILES = "com.mi.android.globalFileexplorer"
    private const val MI_BROWSER = "com.mi.globalbrowser"
    private const val MI_MUSIC = "com.miui.player"
    private const val MI_VIDEO = "com.miui.videoplayer"
    private const val GETAPPS = "com.xiaomi.mipicks"

    // Samsung
    private const val DEVICE_CARE = "com.samsung.android.lool"
    private const val SAMSUNG_PUSH = "com.sec.spp.push"
    private const val GALAXY_STORE = "com.sec.android.app.samsungapps"
    private const val SAMSUNG_WALLET = "com.samsung.android.spay"
    private const val SAMSUNG_FREE = "com.samsung.android.app.spage"
    private const val SAMSUNG_INTERNET = "com.sec.android.app.sbrowser"

    // Google
    private const val GBOARD = "com.google.android.inputmethod.latin"
    private const val PLAY_STORE = "com.android.vending"
    private const val GOOGLE_ADS_ACTION = "com.google.android.gms.settings.ADS_PRIVACY"
    private const val NOTIFICATION_SETTINGS = "android.settings.NOTIFICATION_SETTINGS"
    private const val SYSTEM_UPDATE = "android.settings.SYSTEM_UPDATE_SETTINGS"

    const val PRIVATE_DNS_ID = "private_dns"

    /** Die wichtigsten Punkte in der Reihenfolge, in der „Nächster Schritt“ sie vorschlägt. */
    val ESSENTIAL_ORDER = listOf(
        "screen_lock",
        "security_patch",
        "find_device",
        "theft_protection",
        "msa",
        "customization_service",
        "personalized_ads",
        "excessive_ads",
        "diagnostics",
        "google_ad_id",
        "google_ads_personalization",
        "permissions",
        "free_storage",
    )

    private val settingsHome = listOf(Jump.Action(Settings.ACTION_SETTINGS))
    private val privacy = listOf(Jump.Action(Settings.ACTION_PRIVACY_SETTINGS))
    private val security = listOf(Jump.Action(Settings.ACTION_SECURITY_SETTINGS))
    private val apps = listOf(Jump.Action(Settings.ACTION_APPLICATION_SETTINGS))
    private val display = listOf(Jump.Action(Settings.ACTION_DISPLAY_SETTINGS))
    private val notifications = listOf(Jump.Action(NOTIFICATION_SETTINGS))
    private val devOptions = listOf(Jump.Action(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
    private val location = listOf(Jump.Action(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
    private fun app(pkg: String) = listOf(Jump.App(pkg))
    private fun openApp(de: String, en: String) = T("$de öffnen", "Open $en")

    fun all(ramGb: Int, devOptionsEnabled: Boolean, platform: Platform): List<ManualStep> {
        val isXiaomi = platform == Platform.XIAOMI
        val isSamsung = platform == Platform.SAMSUNG

        fun <V> pick(xiaomi: V, samsung: V, generic: V): V = when (platform) {
            Platform.XIAOMI -> xiaomi
            Platform.SAMSUNG -> samsung
            Platform.GENERIC -> generic
        }

        val devPath = pick(
            T("Einstellungen › Weitere Einstellungen › Entwickleroptionen", "Settings › Additional settings › Developer options"),
            T("Einstellungen › Entwickleroptionen (ganz unten)", "Settings › Developer options (at the bottom)"),
            T("Einstellungen › System › Entwickleroptionen", "Settings › System › Developer options"),
        )
        val devEnable = pick(
            T("Einstellungen › Über das Telefon › siebenmal auf „OS-Version“ tippen", "Settings › About phone › tap “OS version” seven times"),
            T(
                "Einstellungen › Telefoninfo › Softwareinformationen › siebenmal auf „Buildnummer“ tippen",
                "Settings › About phone › Software information › tap “Build number” seven times",
            ),
            T("Einstellungen › Über das Telefon › siebenmal auf „Build-Nummer“ tippen", "Settings › About phone › tap “Build number” seven times"),
        )
        val ramAdvice = when {
            ramGb == 0 -> T(
                "Faustregel: ab 8 GB RAM ausschalten, darunter eingeschaltet lassen.",
                "Rule of thumb: turn it off with 8 GB of RAM or more, keep it on below that.",
            )
            ramGb >= 8 -> T(
                "Dein Gerät hat etwa $ramGb GB RAM – ausschalten bzw. auf das Minimum stellen. Bei so viel " +
                    "Arbeitsspeicher bringt die Erweiterung kaum etwas, belegt aber Speicherplatz.",
                "Your device has about $ramGb GB of RAM – turn it off or set it to the minimum. With that much " +
                    "memory the extension adds little but takes up storage.",
            )
            else -> T(
                "Dein Gerät hat etwa $ramGb GB RAM – eingeschaltet lassen. Mit wenig Arbeitsspeicher hält die " +
                    "Erweiterung mehr Apps im Hintergrund.",
                "Your device has about $ramGb GB of RAM – keep it on. With little memory, the extension keeps more " +
                    "apps in the background.",
            )
        }

        return buildList<ManualStep> {
            // =========================================================================== Datenschutz
            add(
                ManualStep(
                    id = "lockscreen_notifications",
                    category = Category.PRIVACY,
                    title = T("Nachrichteninhalte auf dem Sperrbildschirm verbergen", "Hide message content on the lock screen"),
                    path = pick(
                        T(
                            "Einstellungen › Benachrichtigungen und Statusleiste › Sperrbildschirm-Benachrichtigungen › Inhalte ausblenden",
                            "Settings › Notifications & status bar › Lock screen notifications › Hide content",
                        ),
                        T(
                            "Einstellungen › Benachrichtigungen › Benachrichtigungen auf dem Sperrbildschirm › Inhalte ausblenden",
                            "Settings › Notifications › Lock screen notifications › Hide content",
                        ),
                        T(
                            "Einstellungen › Benachrichtigungen › Benachrichtigungen auf dem Sperrbildschirm › vertrauliche Inhalte ausblenden",
                            "Settings › Notifications › Notifications on lock screen › hide sensitive content",
                        ),
                    ),
                    why = T(
                        "Auf dem Sperrbildschirm steht dann nur noch, dass eine Nachricht da ist – Absender und Text erst nach dem Entsperren.",
                        "The lock screen then only shows that a message arrived – sender and text appear after unlocking.",
                    ),
                    jumps = notifications,
                    detector = Detector.Values(AutoTweaks.lockscreen),
                )
            )
            add(
                ManualStep(
                    id = "clipboard",
                    category = Category.PRIVACY,
                    title = T("Hinweis bei Zugriff auf die Zwischenablage", "Notice when apps read the clipboard"),
                    path = pick(
                        T("Einstellungen › Datenschutz › „Zugriff auf Zwischenablage anzeigen“ einschalten", "Settings › Privacy › turn on “Show clipboard access”"),
                        T(
                            "Einstellungen › Sicherheit und Datenschutz › Datenschutz › Weitere Datenschutzeinstellungen › „Zugriff auf Zwischenablage anzeigen“",
                            "Settings › Security and privacy › Privacy › More privacy settings › “Show clipboard access”",
                        ),
                        T(
                            "Einstellungen › Sicherheit & Datenschutz › Datenschutzeinstellungen › „Zugriff auf Zwischenablage anzeigen“",
                            "Settings › Security & privacy › Privacy controls › “Show clipboard access”",
                        ),
                    ),
                    why = T(
                        "Android meldet dann, wenn eine App deine Zwischenablage liest – etwa ein kopiertes Passwort. Meist ab Werk aktiv.",
                        "Android then tells you when an app reads your clipboard – a copied password, for example. Usually on by default.",
                    ),
                    jumps = privacy,
                    detector = Detector.Values(AutoTweaks.clipboard),
                )
            )
            add(
                ManualStep(
                    id = "diagnostics",
                    category = Category.PRIVACY,
                    title = pick(
                        T("Benutzererfahrungsprogramm und Diagnosedaten aus", "Turn off user experience program and diagnostics"),
                        T("Diagnosedaten an Samsung aus", "Turn off diagnostic data to Samsung"),
                        T("Nutzungs- und Diagnosedaten aus", "Turn off usage & diagnostics"),
                    ),
                    path = pick(
                        T(
                            "Einstellungen › Datenschutz › „Benutzererfahrungsprogramm“ ausschalten, außerdem „Verwendung und " +
                                "Diagnostik“ bzw. das automatische Senden von Diagnosedaten",
                            "Settings › Privacy › turn off “User experience program” as well as “Usage & diagnostics” or the " +
                                "automatic sending of diagnostic data",
                        ),
                        T(
                            "Einstellungen › Sicherheit und Datenschutz › Datenschutz › Weitere (bzw. Andere) Datenschutzeinstellungen › " +
                                "„Diagnosedaten senden“ ausschalten",
                            "Settings › Security and privacy › Privacy › More privacy settings › turn off “Send diagnostic data”",
                        ),
                        T(
                            "Einstellungen › Google › Alle Dienste › Nutzung und Diagnose › ausschalten",
                            "Settings › Google › All services › Usage & diagnostics › turn off",
                        ),
                    ),
                    why = pick(
                        T(
                            "Nutzungs- und Absturzdaten gehen sonst an Xiaomi. Telefonie, Apps und Updates funktionieren unverändert.",
                            "Otherwise usage and crash data is sent to Xiaomi. Calls, apps and updates keep working as before.",
                        ),
                        T(
                            "Absturzberichte und Nutzungsstatistiken gehen sonst an Samsung. Google-Diagnosedaten stellst du separat " +
                                "unter Einstellungen › Google ab.",
                            "Otherwise crash reports and usage statistics go to Samsung. Google diagnostics are set separately " +
                                "under Settings › Google.",
                        ),
                        T(
                            "Nutzungs- und Absturzdaten gehen sonst an Google. Das Gerät funktioniert unverändert.",
                            "Otherwise usage and crash data is sent to Google. The device keeps working as before.",
                        ),
                    ),
                    jumps = pick(privacy, privacy, settingsHome),
                )
            )
            add(
                ManualStep(
                    id = "google_ad_id",
                    category = Category.PRIVACY,
                    title = T("Google-Werbe-ID löschen", "Delete the Google advertising ID"),
                    path = T(
                        "Einstellungen › Google › Alle Dienste › Werbung › „Werbe-ID löschen“",
                        "Settings › Google › All services › Ads › “Delete advertising ID”",
                    ),
                    why = T(
                        "Apps können dich dann nicht mehr über diese ID wiedererkennen.",
                        "Apps can no longer recognize you via this ID.",
                    ),
                    jumps = listOf(Jump.Action(GOOGLE_ADS_ACTION)),
                    openLabel = T("Google-Werbung öffnen", "Open Google ads settings"),
                )
            )
            add(
                ManualStep(
                    id = "permissions",
                    category = Category.PRIVACY,
                    title = T("Berechtigungen durchgehen", "Review app permissions"),
                    path = pick(
                        T(
                            "Einstellungen › Datenschutz › Berechtigungsmanager: Standort, Kamera und Mikrofon prüfen",
                            "Settings › Privacy › Permission manager: check location, camera and microphone",
                        ),
                        T(
                            "Einstellungen › Sicherheit und Datenschutz › Datenschutz › Berechtigungsmanager: Standort, Kamera und Mikrofon prüfen",
                            "Settings › Security and privacy › Privacy › Permission manager: check location, camera and microphone",
                        ),
                        T(
                            "Einstellungen › Sicherheit & Datenschutz › Datenschutzeinstellungen › Berechtigungsmanager: Standort, Kamera und Mikrofon prüfen",
                            "Settings › Security & privacy › Privacy controls › Permission manager: check location, camera and microphone",
                        ),
                    ),
                    why = T(
                        "„Nur während der Nutzung“ statt „Immer zulassen“ reicht fast immer.",
                        "“Only while using the app” instead of “Allow all the time” is almost always enough.",
                    ),
                    jumps = privacy,
                )
            )
            add(
                ManualStep(
                    id = "gboard",
                    category = Category.PRIVACY,
                    title = T("Gboard: Statistiken nicht teilen", "Gboard: don't share statistics"),
                    path = T(
                        "Gboard-Einstellungen › Datenschutz › „Nutzungsstatistiken teilen“ und die Optionen zum Verbessern von Gboard ausschalten",
                        "Gboard settings › Privacy › turn off “Share usage statistics” and the options for improving Gboard",
                    ),
                    jumps = app(GBOARD),
                    openLabel = openApp("Gboard", "Gboard"),
                    requiresPackage = GBOARD,
                )
            )
            add(
                ManualStep(
                    id = "google_location_accuracy",
                    category = Category.PRIVACY,
                    title = T("Google-Standortgenauigkeit", "Google Location Accuracy"),
                    path = T(
                        "Einstellungen › Standort › Standortdienste › Google-Standortgenauigkeit",
                        "Settings › Location › Location services › Google Location Accuracy",
                    ),
                    why = T(
                        "Schickt WLAN- und Mobilfunkdaten zur Ortung an Google. Ohne dauert die erste Ortung per GPS etwas länger.",
                        "Sends Wi‑Fi and mobile network data to Google for positioning. Without it, the first GPS fix takes a little longer.",
                    ),
                    jumps = location,
                    optional = true,
                )
            )

            // =========================================================================== Sicherheit
            add(
                ManualStep(
                    id = "screen_lock",
                    category = Category.SECURITY,
                    title = T("Bildschirmsperre mit PIN oder Passwort", "Screen lock with PIN or password"),
                    path = pick(
                        T(
                            "Einstellungen › Fingerabdrücke, Gesichtsdaten und Bildschirmsperre › Bildschirmsperre",
                            "Settings › Fingerprints, face data, and screen lock › Screen lock",
                        ),
                        T("Einstellungen › Sperrbildschirm und AOD › Sperrbildschirmtyp", "Settings › Lock screen and AOD › Screen lock type"),
                        T(
                            "Einstellungen › Sicherheit & Datenschutz › Entsperren des Geräts › Displaysperre",
                            "Settings › Security & privacy › Device unlock › Screen lock",
                        ),
                    ),
                    why = T(
                        "Eine PIN mit mindestens sechs Ziffern oder ein Passwort ist sicherer als ein Muster. Fingerabdruck " +
                            "oder Gesicht kommen bequem dazu.",
                        "A PIN with at least six digits or a password is safer than a pattern. Fingerprint or face unlock " +
                            "can be added for convenience.",
                    ),
                    jumps = security,
                    detector = Detector.ScreenLock,
                )
            )
            add(
                ManualStep(
                    id = "security_patch",
                    category = Category.SECURITY,
                    title = T("Sicherheitsupdates aktuell", "Security updates up to date"),
                    path = pick(
                        T("Einstellungen › Über das Telefon › HyperOS-Version › Nach Updates suchen", "Settings › About phone › HyperOS version › Check for updates"),
                        T("Einstellungen › Software-Update › Herunterladen und installieren", "Settings › Software update › Download and install"),
                        T("Einstellungen › System › Softwareupdates", "Settings › System › Software updates"),
                    ),
                    why = T(
                        "Als aktuell gilt ein Patch-Stand, der höchstens drei Monate alt ist.",
                        "A patch level no older than three months counts as up to date.",
                    ),
                    jumps = pick(
                        listOf(Jump.Action(Settings.ACTION_DEVICE_INFO_SETTINGS)),
                        settingsHome,
                        listOf(Jump.Action(SYSTEM_UPDATE)),
                    ),
                    detector = Detector.SecurityPatch,
                )
            )
            add(
                ManualStep(
                    id = "screen_timeout",
                    category = Category.SECURITY,
                    title = T("Bildschirm sperrt nach höchstens 1 Minute", "Screen locks after 1 minute at most"),
                    path = pick(
                        T("Einstellungen › Sperrbildschirm › Ruhezustand: 30 Sekunden bis 1 Minute", "Settings › Lock screen › Sleep: 30 seconds to 1 minute"),
                        T("Einstellungen › Anzeige › Bildschirm-Timeout: 30 Sekunden bis 1 Minute", "Settings › Display › Screen timeout: 30 seconds to 1 minute"),
                        T("Einstellungen › Display › Bildschirm-Timeout: 30 Sekunden bis 1 Minute", "Settings › Display › Screen timeout: 30 seconds to 1 minute"),
                    ),
                    why = T(
                        "Ein unbeaufsichtigtes Handy ist so schneller gesperrt – und der Akku hält länger.",
                        "An unattended phone locks sooner – and the battery lasts longer.",
                    ),
                    jumps = pick(settingsHome, display, display),
                    detector = Detector.ScreenTimeout,
                )
            )
            if (isSamsung) {
                add(
                    ManualStep(
                        id = "auto_blocker",
                        category = Category.SECURITY,
                        title = T("Automatische Sperre einschalten", "Turn on Auto Blocker"),
                        path = T(
                            "Einstellungen › Sicherheit und Datenschutz › Automatische Sperre",
                            "Settings › Security and privacy › Auto Blocker",
                        ),
                        why = T(
                            "Blockiert Apps aus unbekannten Quellen, Befehle über USB und getarnte Schadsoftware in Bildern. " +
                                "Erst nach der Installation dieser App einschalten – und für die optionale PC-Freischaltung kurz aus.",
                            "Blocks apps from unknown sources, commands via USB and malware hidden in images. Turn it on " +
                                "after installing this app – and briefly off for the optional PC unlock.",
                        ),
                        jumps = security,
                    )
                )
            }
            add(
                ManualStep(
                    id = "theft_protection",
                    category = Category.SECURITY,
                    title = T("Diebstahlschutz einschalten", "Turn on theft protection"),
                    path = pick(
                        T(
                            "Einstellungen › Google › Alle Dienste › Diebstahlschutz: „Sperre bei Diebstahlerkennung“ und „Offline-Gerätesperre“ einschalten",
                            "Settings › Google › All services › Theft protection: turn on “Theft Detection Lock” and “Offline Device Lock”",
                        ),
                        T(
                            "Einstellungen › Sicherheit und Datenschutz › Schutz bei Geräteverlust › Diebstahlschutz",
                            "Settings › Security and privacy › Lost device protection › Theft protection",
                        ),
                        T(
                            "Einstellungen › Sicherheit & Datenschutz › Entsperren des Geräts › Diebstahlschutz",
                            "Settings › Security & privacy › Device unlock › Theft protection",
                        ),
                    ),
                    why = T(
                        "Sperrt das Handy automatisch, wenn es dir aus der Hand gerissen wird oder längere Zeit offline ist.",
                        "Locks the phone automatically if it's snatched from your hand or stays offline for a long time.",
                    ),
                    jumps = pick(settingsHome, security, security),
                )
            )
            add(
                ManualStep(
                    id = "sim_pin",
                    category = Category.SECURITY,
                    title = T("SIM-PIN aktivieren", "Turn on SIM PIN"),
                    path = pick(
                        T(
                            "Einstellungen › Fingerabdrücke, Gesichtsdaten und Bildschirmsperre › Datenschutz › Weitere " +
                                "Sicherheitseinstellungen › SIM-Karte wählen › SIM-Sperre einschalten",
                            "Settings › Passwords & security › Privacy › SIM card lock › choose SIM › Lock SIM card",
                        ),
                        T(
                            "Einstellungen › Sicherheit und Datenschutz › Weitere Sicherheitseinstellungen › SIM-Kartensperre einrichten",
                            "Settings › Security and privacy › More security settings › Set up SIM card lock",
                        ),
                        T(
                            "Einstellungen › Sicherheit & Datenschutz › Weitere Sicherheits- & Datenschutzeinstellungen › SIM-Sperre",
                            "Settings › Security & privacy › More security & privacy › SIM lock",
                        ),
                    ),
                    why = T(
                        "Schützt die SIM-Karte, wenn sie in ein anderes Gerät gesteckt wird. Die PIN steht in den Unterlagen " +
                            "deines Anbieters – nach drei Fehleingaben sperrt sich die Karte.",
                        "Protects the SIM card if it's put into another device. The PIN is in your carrier's documents – " +
                            "three wrong attempts lock the card.",
                    ),
                    jumps = security,
                )
            )
            add(
                ManualStep(
                    id = "find_device",
                    category = Category.SECURITY,
                    title = T("Geräteortung einschalten", "Turn on device finding"),
                    path = pick(
                        T(
                            "Einstellungen › Google › Alle Dienste › Find Hub (früher „Mein Gerät finden“) einschalten",
                            "Settings › Google › All services › turn on Find Hub (formerly Find My Device)",
                        ),
                        T(
                            "Einstellungen › Sicherheit und Datenschutz › Schutz bei Geräteverlust › „Mein Mobilgerät finden“ " +
                                "einschalten – zusätzlich Google Find Hub unter Einstellungen › Google",
                            "Settings › Security and privacy › Lost device protection › turn on “Find My Mobile” – plus " +
                                "Google Find Hub under Settings › Google",
                        ),
                        T(
                            "Einstellungen › Google › Alle Dienste › Find Hub (früher „Mein Gerät finden“) einschalten",
                            "Settings › Google › All services › turn on Find Hub (formerly Find My Device)",
                        ),
                    ),
                    why = T(
                        "Damit lässt sich ein verlorenes Handy orten, sperren oder aus der Ferne löschen.",
                        "Lets you locate, lock or remotely erase a lost phone.",
                    ),
                    jumps = pick(settingsHome, security, settingsHome),
                )
            )
            if (isSamsung) {
                add(
                    ManualStep(
                        id = "samsung_2fa",
                        category = Category.SECURITY,
                        title = T("Zweistufige Bestätigung fürs Samsung-Konto", "Two-step verification for your Samsung account"),
                        path = T(
                            "Einstellungen › Samsung-Konto (ganz oben) › Sicherheit und Datenschutz › Zweistufige Bestätigung",
                            "Settings › Samsung account (at the top) › Security and privacy › Two-step verification",
                        ),
                        why = T(
                            "Über das Konto lässt sich das Handy orten, sperren und löschen – es verdient denselben Schutz wie dein E-Mail-Konto.",
                            "The account can locate, lock and erase your phone – it deserves the same protection as your email account.",
                        ),
                        jumps = settingsHome,
                    )
                )
            }
            add(
                ManualStep(
                    id = "play_protect",
                    category = Category.SECURITY,
                    title = T("Play Protect eingeschaltet lassen", "Keep Play Protect on"),
                    path = T(
                        "Play Store › Profilbild › Play Protect › Zahnrad › „Apps mit Play Protect scannen“ einschalten",
                        "Play Store › profile picture › Play Protect › gear icon › turn on “Scan apps with Play Protect”",
                    ),
                    why = T("Prüft installierte Apps regelmäßig auf Schadsoftware.", "Regularly checks installed apps for malware."),
                    jumps = app(PLAY_STORE),
                    openLabel = openApp("Play Store", "Play Store"),
                    requiresPackage = PLAY_STORE,
                )
            )
            add(
                ManualStep(
                    id = "unknown_sources",
                    category = Category.SECURITY,
                    title = T("„Unbekannte Apps installieren“ einschränken", "Restrict “Install unknown apps”"),
                    path = pick(
                        T(
                            "Einstellungen › Apps › Besondere Berechtigungen › Unbekannte Apps installieren: nur erlauben, was es wirklich braucht",
                            "Settings › Apps › Special permissions › Install unknown apps: only allow what really needs it",
                        ),
                        T(
                            "Einstellungen › Apps › ⋮ › Spezieller Zugriff › Unbekannte Apps installieren: nur erlauben, was es wirklich braucht",
                            "Settings › Apps › ⋮ › Special access › Install unknown apps: only allow what really needs it",
                        ),
                        T(
                            "Einstellungen › Apps › Spezieller App-Zugriff › Unbekannte Apps installieren: nur erlauben, was es wirklich braucht",
                            "Settings › Apps › Special app access › Install unknown apps: only allow what really needs it",
                        ),
                    ),
                    why = T(
                        "Nach der Installation dieser App kannst du die Erlaubnis für Browser oder Dateimanager wieder entziehen.",
                        "After installing this app, you can revoke the permission for your browser or file manager again.",
                    ),
                    jumps = listOf(Jump.Action(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)),
                )
            )
            add(
                ManualStep(
                    id = "usb_debugging",
                    category = Category.SECURITY,
                    title = T("USB-Debugging ausschalten", "Turn off USB debugging"),
                    path = T(
                        "${devPath.de} › „USB-Debugging“ ausschalten – die Entwickleroptionen selbst eingeschaltet lassen",
                        "${devPath.en} › turn off “USB debugging” – keep developer options themselves on",
                    ),
                    why = T(
                        "Bei eingeschaltetem USB-Debugging kann ein PC tief ins System eingreifen. Nur für die optionale " +
                            "Freischaltung kurz einschalten.",
                        "With USB debugging on, a PC can reach deep into the system. Only turn it on briefly for the " +
                            "optional unlock.",
                    ),
                    jumps = devOptions,
                    openLabel = T("Entwickleroptionen öffnen", "Open developer options"),
                    detector = Detector.UsbDebuggingOff,
                )
            )
            add(
                ManualStep(
                    id = "accessibility",
                    category = Category.SECURITY,
                    title = T("Bedienungshilfen prüfen", "Review accessibility services"),
                    path = pick(
                        T(
                            "Einstellungen › Weitere Einstellungen › Bedienungshilfen › Heruntergeladene Apps: nur bekannte Apps zulassen",
                            "Settings › Additional settings › Accessibility › Downloaded apps: only allow apps you know",
                        ),
                        T(
                            "Einstellungen › Eingabehilfe › Installierte Apps: nur bekannte Apps zulassen",
                            "Settings › Accessibility › Installed apps: only allow apps you know",
                        ),
                        T(
                            "Einstellungen › Bedienungshilfen › Heruntergeladene Apps: nur bekannte Apps zulassen",
                            "Settings › Accessibility › Downloaded apps: only allow apps you know",
                        ),
                    ),
                    why = T(
                        "Bedienungshilfen dürfen Bildschirminhalte lesen und Eingaben auslösen – ein beliebtes Einfallstor für Schadsoftware.",
                        "Accessibility services can read screen content and trigger input – a popular entry point for malware.",
                    ),
                    jumps = listOf(Jump.Action(Settings.ACTION_ACCESSIBILITY_SETTINGS)),
                )
            )
            if (isXiaomi) {
                add(
                    ManualStep(
                        id = "lockscreen_control_center",
                        category = Category.SECURITY,
                        title = T("Kontrollzentrum im gesperrten Zustand sperren", "Block Control center while locked"),
                        path = T(
                            "Einstellungen › Benachrichtigungen und Statusleiste › „Kontrollzentrum/Benachrichtigungen vom " +
                                "Sperrbildschirm aus öffnen“ › Nicht zulassen",
                            "Settings › Notifications & status bar › “Open Control center/notifications from lock screen” › Don't allow",
                        ),
                        why = T(
                            "Verhindert, dass jemand am gesperrten Handy den Flugmodus einschaltet und so die Ortung verhindert. " +
                                "Dafür siehst du Benachrichtigungen erst nach dem Entsperren.",
                            "Prevents someone from switching on airplane mode on a locked phone to stop it from being located. " +
                                "In return, you only see notifications after unlocking.",
                        ),
                        jumps = notifications,
                        optional = true,
                    )
                )
            }
            if (isSamsung) {
                add(
                    ManualStep(
                        id = "lock_network",
                        category = Category.SECURITY,
                        title = T("Netzwerk und Sicherheit im gesperrten Zustand sperren", "Lock network and security while locked"),
                        path = T(
                            "Einstellungen › Sperrbildschirm und AOD › Einstellungen für sichere Sperre › „Netzwerk und Sicherheit sperren“",
                            "Settings › Lock screen and AOD › Secure lock settings › “Lock network and security”",
                        ),
                        why = T(
                            "Flugmodus und mobile Daten lassen sich dann nur nach dem Entsperren abschalten – so bleibt ein gestohlenes Handy ortbar.",
                            "Airplane mode and mobile data can then only be turned off after unlocking – so a stolen phone stays locatable.",
                        ),
                        jumps = settingsHome,
                    )
                )
            }
            add(
                ManualStep(
                    id = "app_lock",
                    category = Category.SECURITY,
                    title = pick(
                        T("App-Sperre für sensible Apps", "App lock for sensitive apps"),
                        T("Sicherer Ordner für sensible Apps", "Secure Folder for sensitive apps"),
                        T("Privater Bereich für sensible Apps", "Private space for sensitive apps"),
                    ),
                    path = pick(
                        T(
                            "Einstellungen › Apps › App-Sperre (oder Sicherheit › App-Sperre): z. B. Banking, Messenger und Galerie auswählen",
                            "Settings › Apps › App lock (or Security › App lock): select e.g. banking, messengers and gallery",
                        ),
                        T(
                            "Einstellungen › Sicherheit und Datenschutz › Weitere Sicherheitseinstellungen › Sicherer Ordner",
                            "Settings › Security and privacy › More security settings › Secure Folder",
                        ),
                        T(
                            "Einstellungen › Sicherheit & Datenschutz › Privater Bereich (ab Android 15)",
                            "Settings › Security & privacy › Private space (Android 15 and later)",
                        ),
                    ),
                    why = T(
                        "Diese Apps verlangen dann zusätzlich Fingerabdruck oder PIN – praktisch, wenn du das Handy entsperrt weitergibst.",
                        "These apps then also require fingerprint or PIN – handy when you hand over your unlocked phone.",
                    ),
                    jumps = pick(app(MI_SECURITY), security, security),
                    openLabel = pick(openApp("Sicherheit", "Security"), S.openSettings, S.openSettings),
                    optional = true,
                )
            )

            // =========================================================================== Netzwerk
            add(
                ManualStep(
                    id = "scanning",
                    category = Category.NETWORK,
                    title = T("WLAN- und Bluetooth-Suche aus", "Turn off Wi‑Fi and Bluetooth scanning"),
                    path = T(
                        "Einstellungen › Standort › Standortdienste: „WLAN-Suche“ und „Bluetooth-Suche“ ausschalten",
                        "Settings › Location › Location services: turn off “Wi‑Fi scanning” and “Bluetooth scanning”",
                    ),
                    why = T(
                        "Sonst suchen Ortungsdienste auch bei ausgeschaltetem WLAN und Bluetooth nach Netzen und Geräten in " +
                            "der Nähe, um deinen Standort zu bestimmen. Spart nebenbei etwas Akku.",
                        "Otherwise location services keep scanning for nearby networks and devices even with Wi‑Fi and " +
                            "Bluetooth off, to work out your location. Saves some battery, too.",
                    ),
                    jumps = location,
                    detector = Detector.Values(AutoTweaks.scanning),
                )
            )
            add(
                ManualStep(
                    id = "mac_random",
                    category = Category.NETWORK,
                    title = T("Zufällige MAC-Adresse im WLAN", "Randomized MAC address on Wi‑Fi"),
                    path = pick(
                        T(
                            "Einstellungen › WLAN › gespeichertes Netz antippen › Datenschutz: „Zufällige MAC-Adresse“ verwenden",
                            "Settings › Wi‑Fi › tap a saved network › Privacy: use “Randomized MAC”",
                        ),
                        T(
                            "Einstellungen › Verbindungen › WLAN › Zahnrad neben dem Netz › Weitere anzeigen › MAC-Adresstyp: „Zufällige MAC“",
                            "Settings › Connections › Wi‑Fi › gear next to the network › View more › MAC address type: “Randomized MAC”",
                        ),
                        T(
                            "Einstellungen › Netzwerk & Internet › Internet › Zahnrad neben dem Netz › Datenschutz: „Zufällige MAC-Adresse verwenden“",
                            "Settings › Network & internet › Internet › gear next to the network › Privacy: “Use randomized MAC”",
                        ),
                    ),
                    why = T(
                        "Erschwert es, dein Gerät über verschiedene WLAN-Netze hinweg wiederzuerkennen. Bei neuen Netzen meist " +
                            "schon aktiv – vor allem ältere, gespeicherte Netze prüfen.",
                        "Makes it harder to recognize your device across Wi‑Fi networks. Usually already on for new " +
                            "networks – check older saved ones in particular.",
                    ),
                    jumps = listOf(Jump.Action(Settings.ACTION_WIFI_SETTINGS)),
                )
            )
            add(
                ManualStep(
                    id = "quick_share",
                    category = Category.NETWORK,
                    title = T("Quick Share nur für Kontakte", "Quick Share for contacts only"),
                    path = pick(
                        T(
                            "Einstellungen › Google › Alle Dienste › Geräte und Teilen › Quick Share › Sichtbarkeit: „Deine Geräte“ oder „Kontakte“",
                            "Settings › Google › All services › Devices & sharing › Quick Share › Visibility: “Your devices” or “Contacts”",
                        ),
                        T(
                            "Einstellungen › Verbundene Geräte › Quick Share › „Wer kann mit dir teilen“: Nur Kontakte",
                            "Settings › Connected devices › Quick Share › “Who can share with you”: Contacts only",
                        ),
                        T(
                            "Einstellungen › Google › Alle Dienste › Geräte und Teilen › Quick Share › Sichtbarkeit: „Deine Geräte“ oder „Kontakte“",
                            "Settings › Google › All services › Devices & sharing › Quick Share › Visibility: “Your devices” or “Contacts”",
                        ),
                    ),
                    why = T(
                        "Mit „Alle“ kann dir jeder in der Nähe Dateien anbieten – das wird für Spam und Phishing ausgenutzt.",
                        "With “Everyone”, anyone nearby can send you files – which gets abused for spam and phishing.",
                    ),
                    jumps = settingsHome,
                )
            )
            add(
                ManualStep(
                    id = PRIVATE_DNS_ID,
                    category = Category.NETWORK,
                    title = T("Privates DNS mit Werbefilter", "Private DNS with ad filter"),
                    path = pick(
                        T(
                            "Anbieter wählen und „Hostname kopieren“ tippen. Dann Einstellungen › Verbindung & Freigabe › Privates " +
                                "DNS › „Hostname des privaten DNS-Anbieters“ wählen und einfügen.",
                            "Pick a provider and tap “Copy hostname”. Then go to Settings › Connection & sharing › Private DNS › " +
                                "choose “Private DNS provider hostname” and paste it.",
                        ),
                        T(
                            "Anbieter wählen und „Hostname kopieren“ tippen. Dann Einstellungen › Verbindungen › Weitere " +
                                "Verbindungseinstellungen › Privates DNS › „Hostname des privaten DNS-Anbieters“ wählen und einfügen.",
                            "Pick a provider and tap “Copy hostname”. Then go to Settings › Connections › More connection " +
                                "settings › Private DNS › choose “Private DNS provider hostname” and paste it.",
                        ),
                        T(
                            "Anbieter wählen und „Hostname kopieren“ tippen. Dann Einstellungen › Netzwerk & Internet › Privates " +
                                "DNS › „Hostname des privaten DNS-Anbieters“ wählen und einfügen.",
                            "Pick a provider and tap “Copy hostname”. Then go to Settings › Network & internet › Private DNS › " +
                                "choose “Private DNS provider hostname” and paste it.",
                        ),
                    ),
                    why = T(
                        "Filtert Werbe- und Tracking-Adressen systemweit, auch in vorinstallierten Apps. In manchen Firmen- oder " +
                            "Hotel-WLANs ist der nötige Port 853 gesperrt – dann dort auf „Automatisch“ zurückstellen. Einen " +
                            "eigenen Filter im Heimnetz, etwa ein Pi-hole, umgeht Privates DNS.",
                        "Filters ad and tracking domains system-wide, including in preinstalled apps. Some company or hotel " +
                            "Wi‑Fi networks block the required port 853 – switch back to “Automatic” there. Private DNS " +
                            "bypasses your own filter at home, such as a Pi-hole.",
                    ),
                    jumps = listOf(Jump.Action(Settings.ACTION_WIRELESS_SETTINGS)),
                    detector = Detector.PrivateDns,
                    optional = true,
                )
            )

            // =========================================================================== Werbung
            if (isXiaomi) addAll(xiaomiAdsTop())
            if (isSamsung) addAll(samsungAds())
            addAll(commonAds(platform))
            if (isXiaomi) addAll(xiaomiAdsApps())

            // =========================================================================== Geschwindigkeit
            add(
                ManualStep(
                    id = "animations",
                    category = Category.SPEED,
                    title = T("Animationen auf 0,5×", "Animations at 0.5×"),
                    path = if (devOptionsEnabled) {
                        T(
                            "${devPath.de} › die drei Einträge zur Animationsskalierung (Fenster, Übergang, Animator) jeweils auf 0,5× stellen",
                            "${devPath.en} › set the three animation scale entries (window, transition, animator) to 0.5× each",
                        )
                    } else {
                        T(
                            "Zuerst die Entwickleroptionen freischalten: ${devEnable.de}. Danach ${devPath.de} › die drei " +
                                "Einträge zur Animationsskalierung (Fenster, Übergang, Animator) jeweils auf 0,5× stellen.",
                            "First enable developer options: ${devEnable.en}. Then ${devPath.en} › set the three animation " +
                                "scale entries (window, transition, animator) to 0.5× each.",
                        )
                    },
                    why = if (isSamsung) {
                        T(
                            "Das System reagiert spürbar flotter. Entwickleroptionen danach eingeschaltet lassen. Ganz ohne " +
                                "Entwickleroptionen: Eingabehilfe › Sichtbarkeitsverbesserungen › „Animationen reduzieren“.",
                            "The system feels noticeably snappier. Keep developer options on afterwards. Without developer " +
                                "options: Accessibility › Visibility enhancements › “Reduce animations”.",
                        )
                    } else {
                        T(
                            "Das System reagiert spürbar flotter, Animationen bleiben sichtbar. Die Entwickleroptionen danach " +
                                "eingeschaltet lassen – beim Abschalten setzt Android die Werte zurück.",
                            "The system feels noticeably snappier while animations stay visible. Keep developer options on " +
                                "afterwards – turning them off resets the values.",
                        )
                    },
                    jumps = if (devOptionsEnabled) devOptions else listOf(Jump.Action(Settings.ACTION_DEVICE_INFO_SETTINGS)),
                    openLabel = if (devOptionsEnabled) {
                        T("Entwickleroptionen öffnen", "Open developer options")
                    } else {
                        T("„Über das Telefon“ öffnen", "Open “About phone”")
                    },
                    detector = Detector.Values(AutoTweaks.animations),
                )
            )
            if (isXiaomi) {
                add(
                    ManualStep(
                        id = "launcher_animation",
                        category = Category.SPEED,
                        title = T("Animationen des Startbildschirms: schnell", "Home screen animations: fast"),
                        path = T(
                            "Einstellungen › Startbildschirm › Animationsgeschwindigkeit › „Schnell“",
                            "Settings › Home screen › Animation speed › “Fast”",
                        ),
                        why = T(
                            "Ergänzt die 0,5×-Animationen – betrifft Öffnen, Schließen und Wischen auf dem Startbildschirm.",
                            "Complements the 0.5× animations – affects opening, closing and swiping on the home screen.",
                        ),
                        jumps = settingsHome,
                    )
                )
                add(
                    ManualStep(
                        id = "autostart",
                        category = Category.SPEED,
                        title = T("Hintergrund-Autostart begrenzen", "Limit background autostart"),
                        path = T(
                            "Einstellungen › Apps › (Berechtigungen ›) Hintergrund-Autostart: nur Messenger und Apps erlauben, " +
                                "die zuverlässig benachrichtigen müssen",
                            "Settings › Apps › (Permissions ›) Background autostart: only allow messengers and apps that must " +
                                "notify you reliably",
                        ),
                        why = T(
                            "Jede App mit Autostart läuft im Hintergrund weiter und kostet Arbeitsspeicher und Akku.",
                            "Every app with autostart keeps running in the background, costing memory and battery.",
                        ),
                        jumps = apps,
                    )
                )
            }
            if (isSamsung) {
                add(
                    ManualStep(
                        id = "background_limits",
                        category = Category.SPEED,
                        title = T("Nicht verwendete Apps in Standby versetzen", "Put unused apps to sleep"),
                        path = T(
                            "Einstellungen › Gerätewartung › Akku › Hintergrundnutzungsbeschränkungen › „Nicht verwendete Apps in Standby versetzen“",
                            "Settings › Device care › Battery › Background usage limits › “Put unused apps to sleep”",
                        ),
                        why = T(
                            "Apps, die du länger nicht genutzt hast, laufen dann nicht mehr im Hintergrund weiter.",
                            "Apps you haven't used for a while stop running in the background.",
                        ),
                        jumps = app(DEVICE_CARE),
                        openLabel = openApp("Gerätewartung", "Device care"),
                    )
                )
            }
            add(
                ManualStep(
                    id = "free_storage",
                    category = Category.SPEED,
                    title = T("Mindestens 15 % Speicher frei", "At least 15% storage free"),
                    path = pick(
                        T("Einstellungen › Über das Telefon › Speicher – oder Sicherheit › Bereinigen", "Settings › About phone › Storage – or Security › Cleaner"),
                        T("Einstellungen › Gerätewartung › Speicher", "Settings › Device care › Storage"),
                        T("Einstellungen › Speicher", "Settings › Storage"),
                    ),
                    why = T(
                        "Ist der Speicher fast voll, wird das ganze System spürbar langsamer.",
                        "When storage is almost full, the whole system slows down noticeably.",
                    ),
                    jumps = listOf(Jump.Action(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)),
                    detector = Detector.FreeStorage,
                )
            )
            if (isXiaomi) {
                add(
                    ManualStep(
                        id = "memory_extension",
                        category = Category.SPEED,
                        title = T("Speichererweiterung", "Memory extension"),
                        path = T("Einstellungen › Weitere Einstellungen › Speichererweiterung", "Settings › Additional settings › Memory extension"),
                        why = ramAdvice,
                        jumps = settingsHome,
                    )
                )
                add(
                    ManualStep(
                        id = "performance_mode",
                        category = Category.SPEED,
                        title = T("Leistungsmodus", "Performance mode"),
                        path = T("Einstellungen › Akku › Leistungsmodus", "Settings › Battery › Performance mode"),
                        why = T(
                            "Mehr Tempo bei Spielen und anspruchsvollen Apps, dafür mehr Akkuverbrauch und Wärme. Nur " +
                                "einschalten, wenn dir das wichtiger ist als die Laufzeit.",
                            "More speed in games and demanding apps, at the cost of battery and heat. Only turn it on if " +
                                "that matters more to you than battery life.",
                        ),
                        jumps = listOf(Jump.Action(Intent.ACTION_POWER_USAGE_SUMMARY)),
                        optional = true,
                    )
                )
            }
            if (isSamsung) {
                add(
                    ManualStep(
                        id = "ram_plus",
                        category = Category.SPEED,
                        title = T("RAM Plus", "RAM Plus"),
                        path = T("Einstellungen › Gerätewartung › Arbeitsspeicher › RAM Plus", "Settings › Device care › Memory › RAM Plus"),
                        why = ramAdvice,
                        jumps = app(DEVICE_CARE),
                        openLabel = openApp("Gerätewartung", "Device care"),
                    )
                )
                add(
                    ManualStep(
                        id = "performance_profile",
                        category = Category.SPEED,
                        title = T("Leistungsprofil", "Performance profile"),
                        path = T(
                            "Einstellungen › Gerätewartung › Leistungsprofil: „Standard“ für volles Tempo, „Leicht“ für mehr Akkulaufzeit",
                            "Settings › Device care › Performance profile: “Standard” for full speed, “Light” for longer battery life",
                        ),
                        why = T(
                            "Nicht auf jedem Modell vorhanden. „Leicht“ spart Akku und Wärme, wirkt aber etwas träger.",
                            "Not available on every model. “Light” saves battery and heat but feels a little slower.",
                        ),
                        jumps = app(DEVICE_CARE),
                        openLabel = openApp("Gerätewartung", "Device care"),
                        optional = true,
                    )
                )
            }
        }
    }

    // =============================================================================== Werbung – für alle

    private fun commonAds(platform: Platform) = listOf(
        ManualStep(
            id = "google_ads_personalization",
            category = Category.ADS,
            title = T("Personalisierte Google-Werbung aus", "Turn off personalized Google ads"),
            path = T(
                "Mein Werbecenter (myadcenter.google.com) › „Personalisierte Werbung“ ausschalten",
                "My Ad Center (myadcenter.google.com) › turn off “Personalized ads”",
            ),
            why = T(
                "Gilt für dein Google-Konto auf allen Geräten und ergänzt das Löschen der Werbe-ID.",
                "Applies to your Google account on all devices and complements deleting the advertising ID.",
            ),
            jumps = listOf(Jump.Url("https://myadcenter.google.com")),
            openLabel = T("Werbecenter öffnen", "Open My Ad Center"),
        ),
        ManualStep(
            id = "ad_notifications",
            category = Category.ADS,
            title = T("Werbe-Benachrichtigungen gezielt abschalten", "Silence ad notifications"),
            path = T(
                "Bei der nächsten Werbe-Benachrichtigung: lange darauf drücken › Benachrichtigungen dieser Kategorie bzw. App ausschalten",
                "Next time an ad notification appears: long-press it › turn off notifications for that category or app",
            ),
            why = if (platform == Platform.SAMSUNG) {
                T(
                    "Damit das bei allen Apps klappt: Einstellungen › Benachrichtigungen › Erweiterte Einstellungen › " +
                        "„Benachrichtigungskategorien für alle Apps“ einschalten.",
                    "To make this work for all apps: Settings › Notifications › Advanced settings › turn on " +
                        "“Notification categories for all apps”.",
                )
            } else {
                T(
                    "Viele Apps trennen Werbung in eine eigene Kategorie – so bleiben wichtige Hinweise erhalten.",
                    "Many apps put ads in a separate category – so important notifications stay on.",
                )
            },
        ),
    )

    // =============================================================================== Werbung – Samsung

    private fun samsungAds() = listOf(
        ManualStep(
            id = "customization_service",
            category = Category.ADS,
            title = T("Anpassungsdienst aus", "Turn off Customization Service"),
            path = T(
                "Einstellungen › Sicherheit und Datenschutz › Datenschutz › Weitere Datenschutzeinstellungen › " +
                    "Anpassungsdienst (oder Samsung-Konto › Datenschutz › Anpassungsdienst)",
                "Settings › Security and privacy › Privacy › More privacy settings › Customization Service (or Samsung " +
                    "account › Privacy › Customization Service)",
            ),
            why = T(
                "Samsung wertet sonst deine Nutzung für personalisierte Inhalte und Werbung aus.",
                "Otherwise Samsung analyzes your usage for personalized content and ads.",
            ),
            jumps = privacy,
        ),
        ManualStep(
            id = "excessive_ads",
            category = Category.ADS,
            title = T("Apps mit übermäßig viel Werbung blockieren", "Block apps with excessive ads"),
            path = T(
                "Einstellungen › Gerätewartung › ⋮ › Einstellungen › „Blockieren von Apps mit übermäßig viel Werbung“ › Intelligente Blockierung",
                "Settings › Device care › ⋮ › Settings › “Block apps with excessive ads” › Intelligent blocking",
            ),
            why = T(
                "Ab One UI 8.5: Apps, die häufig Werbe-Benachrichtigungen schicken, kommen in den Tiefschlaf. " +
                    "Fehleinschätzungen sind möglich – betroffene Apps lassen sich dort wieder freigeben.",
                "From One UI 8.5: apps that frequently send ad notifications are put into deep sleep. Misjudgements " +
                    "are possible – affected apps can be released there again.",
            ),
            jumps = app(DEVICE_CARE),
            openLabel = openApp("Gerätewartung", "Device care"),
        ),
        ManualStep(
            id = "samsung_push",
            category = Category.ADS,
            title = T("Samsung Push Service: Werbung aus", "Samsung Push Service: turn off ads"),
            path = T(
                "Benachrichtigungen von „Samsung Push Service“ öffnen und Werbe- bzw. Marketing-Kategorien ausschalten",
                "Open notifications for “Samsung Push Service” and turn off promotional or marketing categories",
            ),
            why = T(
                "Über diesen Dienst kommen viele Werbe-Benachrichtigungen von Samsung-Apps.",
                "Many promotional notifications from Samsung apps come through this service.",
            ),
            jumps = listOf(Jump.AppNotifications(SAMSUNG_PUSH)),
            openLabel = T("Benachrichtigungen öffnen", "Open notifications"),
            requiresPackage = SAMSUNG_PUSH,
        ),
        ManualStep(
            id = "galaxy_store",
            category = Category.ADS,
            title = T("Galaxy Store: Marketing aus", "Galaxy Store: turn off marketing"),
            path = T(
                "Galaxy Store › Menü › Einstellungen › Marketinginformationen und Werbe-Benachrichtigungen ausschalten",
                "Galaxy Store › Menu › Settings › turn off marketing information and promotional notifications",
            ),
            jumps = app(GALAXY_STORE),
            openLabel = openApp("Galaxy Store", "Galaxy Store"),
            requiresPackage = GALAXY_STORE,
        ),
        ManualStep(
            id = "samsung_wallet",
            category = Category.ADS,
            title = T("Samsung Wallet: Marketing aus", "Samsung Wallet: turn off marketing"),
            path = T(
                "Samsung Wallet › Menü › Einstellungen › Marketinginformationen ausschalten",
                "Samsung Wallet › Menu › Settings › turn off marketing information",
            ),
            jumps = app(SAMSUNG_WALLET),
            openLabel = openApp("Wallet", "Wallet"),
            requiresPackage = SAMSUNG_WALLET,
        ),
        ManualStep(
            id = "samsung_free",
            category = Category.ADS,
            title = T("Samsung Free auf der linken Seite aus", "Turn off Samsung Free on the left screen"),
            path = T(
                "Lange auf eine freie Stelle des Startbildschirms drücken › ganz nach rechts zur linken Seite wischen › " +
                    "ausschalten oder „Google Discover“ wählen",
                "Long-press an empty spot on the home screen › swipe right to the leftmost page › turn it off or choose " +
                    "“Google Discover”",
            ),
            why = T(
                "Samsung bündelt dort Nachrichten und eigene Angebote.",
                "Samsung bundles news and its own offers there.",
            ),
            jumps = listOf(Jump.Home),
            openLabel = T("Startbildschirm öffnen", "Open home screen"),
            requiresPackage = SAMSUNG_FREE,
        ),
        ManualStep(
            id = "samsung_internet",
            category = Category.ADS,
            title = T("Samsung Internet: Tracking-Schutz", "Samsung Internet: tracking protection"),
            path = T(
                "Samsung Internet › Menü › Einstellungen › Datenschutz und Sicherheit › Tracking-Schutz einschalten, " +
                    "optional einen Werbeblocker hinzufügen",
                "Samsung Internet › Menu › Settings › Privacy and security › turn on tracking protection, optionally add " +
                    "an ad blocker",
            ),
            jumps = app(SAMSUNG_INTERNET),
            openLabel = openApp("Samsung Internet", "Samsung Internet"),
            requiresPackage = SAMSUNG_INTERNET,
        ),
    )

    // =============================================================================== Werbung – Xiaomi

    private fun xiaomiAdsTop() = listOf(
        ManualStep(
            id = "msa",
            category = Category.ADS,
            title = T("Werbedienst „msa“ widerrufen", "Revoke the “msa” ad service"),
            path = T(
                "Einstellungen › Fingerabdrücke, Gesichtsdaten und Bildschirmsperre (je nach Version: Passwörter & " +
                    "Sicherheit) › Autorisierung & Widerruf › „msa“ ausschalten",
                "Settings › Fingerprints, face data, and screen lock (or Passwords & security) › Authorization & " +
                    "revocation › turn off “msa”",
            ),
            why = T(
                "Die Schaltzentrale der Systemwerbung. Klappt oft erst im zweiten oder dritten Anlauf – den " +
                    "10-Sekunden-Countdown jeweils abwarten.",
                "The control center of system ads. Often only works on the second or third try – wait for the " +
                    "10-second countdown each time.",
            ),
            jumps = security,
            requiresPackage = MSA,
        ),
        ManualStep(
            id = "personalized_ads",
            category = Category.ADS,
            title = T("Personalisierte Werbung aus", "Turn off personalized ads"),
            path = T(
                "Einstellungen › Datenschutz › Werbedienste › „Personalisierte Werbung“ ausschalten",
                "Settings › Privacy › Ad services › turn off “Personalized ad recommendations”",
            ),
            why = T(
                "Xiaomi bildet dann kein Werbeprofil mehr aus deiner Nutzung.",
                "Xiaomi then stops building an ad profile from your usage.",
            ),
            jumps = privacy,
        ),
        ManualStep(
            id = "app_manager_recommendations",
            category = Category.ADS,
            title = T("Empfehlungen in der App-Verwaltung aus", "Turn off recommendations in Manage apps"),
            path = T(
                "Einstellungen › Apps › Apps verwalten › ⋮ (oben rechts) › Weitere Einstellungen › „Empfehlungen“ ausschalten",
                "Settings › Apps › Manage apps › ⋮ (top right) › More settings › turn off “Recommendations”",
            ),
            why = T("Gut versteckt: Auch hier blendet Xiaomi Werbung ein.", "Well hidden: Xiaomi shows ads here, too."),
            jumps = apps,
        ),
    )

    private fun xiaomiAdsApps() = listOf(
        ManualStep(
            id = "carousel",
            category = Category.ADS,
            title = T("Hintergrund-Karussell entfernen", "Remove the wallpaper carousel"),
            path = T(
                "Am einfachsten im Play Store deinstallieren. Alternativ: Einstellungen › Sperrbildschirm › " +
                    "Hintergrund-Karussell ausschalten.",
                "Easiest: uninstall it in the Play Store. Alternatively: Settings › Lock screen › turn off Wallpaper carousel.",
            ),
            why = T(
                "Zeigt Werbe-Hintergründe auf dem Sperrbildschirm und lädt dafür regelmäßig Daten nach.",
                "Shows promotional wallpapers on the lock screen and regularly downloads data for them.",
            ),
            jumps = listOf(
                Jump.Url("market://details?id=$CAROUSEL"),
                Jump.Url("https://play.google.com/store/apps/details?id=$CAROUSEL"),
            ),
            openLabel = T("Im Play Store öffnen", "Open in Play Store"),
            requiresPackage = CAROUSEL,
        ),
        ManualStep(
            id = "app_vault",
            category = Category.ADS,
            title = T("App Vault auf der linken Seite ersetzen", "Replace App Vault on the left screen"),
            path = T(
                "Einstellungen › Startbildschirm (oder lange auf eine freie Stelle drücken › Einstellungen) › linke " +
                    "Seite auf „Google Discover“ oder „Nichts“ stellen",
                "Settings › Home screen (or long-press an empty spot › Settings) › set the left screen to “Google " +
                    "Discover” or “None”",
            ),
            why = T("Der Info-Assistent blendet Werbung und App-Vorschläge ein.", "The App Vault shows ads and app suggestions."),
            jumps = settingsHome,
            requiresPackage = APP_VAULT,
        ),
        ManualStep(
            id = "folder_suggestions",
            category = Category.ADS,
            title = T("App-Vorschläge in Ordnern aus", "Turn off app suggestions in folders"),
            path = T(
                "Einen Ordner auf dem Startbildschirm öffnen › Ordnernamen lange drücken › Vorschläge ausschalten",
                "Open a folder on the home screen › long-press the folder name › turn off suggestions",
            ),
            why = T(
                "Sonst stehen beworbene Apps zwischen deinen, als wären sie schon installiert.",
                "Otherwise promoted apps appear among yours as if they were already installed.",
            ),
            jumps = listOf(Jump.Home),
            openLabel = T("Startbildschirm öffnen", "Open home screen"),
        ),
        ManualStep(
            id = "security_app",
            category = Category.ADS,
            title = T("Sicherheit-App: Empfehlungen aus", "Security app: turn off recommendations"),
            path = T(
                "Sicherheit › Zahnrad oben rechts › „Empfehlungen anzeigen“ ausschalten. Dann Bereinigen › " +
                    "Einstellungen › dort ebenfalls „Empfehlungen anzeigen“ ausschalten.",
                "Security › gear icon top right › turn off “Receive recommendations”. Then Cleaner › Settings › " +
                    "turn off “Receive recommendations” there as well.",
            ),
            why = T(
                "Im selben Menü lässt sich die Zusatzprüfung neuer Apps abschalten – Installationen gehen dann " +
                    "schneller. Lass sie an, wenn du öfter Apps außerhalb des Play Stores installierst.",
                "In the same menu you can turn off the extra scan of new apps – installs get faster. Keep it on if " +
                    "you often install apps from outside the Play Store.",
            ),
            jumps = app(MI_SECURITY),
            openLabel = openApp("Sicherheit", "Security"),
            requiresPackage = MI_SECURITY,
        ),
        ManualStep(
            id = "downloads",
            category = Category.ADS,
            title = T("Downloads: Werbung aus", "Downloads: turn off ads"),
            path = T(
                "Downloads › Menü (drei Striche oben rechts) › Einstellungen › „Werbung anzeigen“ bzw. „Empfehlungen“ ausschalten",
                "Downloads › menu (three lines top right) › Settings › turn off “Show recommended content”",
            ),
            jumps = app(MI_DOWNLOADS),
            openLabel = openApp("Downloads", "Downloads"),
            requiresPackage = MI_DOWNLOADS,
        ),
        ManualStep(
            id = "themes",
            category = Category.ADS,
            title = T("Designs: Werbung aus", "Themes: turn off ads"),
            path = T(
                "Designs › Profil (unten rechts) › Zahnrad › „Werbung anzeigen“ und „Personalisierte Empfehlungen“ ausschalten",
                "Themes › Profile (bottom right) › gear icon › turn off “Show ads” and “Personalized recommendations”",
            ),
            jumps = app(MI_THEMES),
            openLabel = openApp("Designs", "Themes"),
            requiresPackage = MI_THEMES,
        ),
        ManualStep(
            id = "files",
            category = Category.ADS,
            title = T("Dateimanager: Empfehlungen aus", "File Manager: turn off recommendations"),
            path = T("Dateimanager › Einstellungen › „Empfehlungen“ ausschalten", "File Manager › Settings › turn off “Recommendations”"),
            why = T(
                "Laut aktuellen Tests lässt er sich nicht mehr überall ganz werbefrei bekommen. Google Files ist eine werbefreie Alternative.",
                "According to recent tests, it can't always be made fully ad-free. Google Files is an ad-free alternative.",
            ),
            jumps = app(MI_FILES),
            openLabel = openApp("Dateimanager", "File Manager"),
            requiresPackage = MI_FILES,
        ),
        ManualStep(
            id = "browser",
            category = Category.ADS,
            title = T("Mi Browser: Werbung aus", "Mi Browser: turn off ads"),
            path = T(
                "Mi Browser › Profilsymbol unten rechts › Zahnrad › Erweitert › „Werbung anzeigen“ ausschalten",
                "Mi Browser › profile icon bottom right › gear icon › Advanced › turn off “Show ads”",
            ),
            why = T(
                "Besser: einen anderen Browser als Standard nutzen und den Mi Browser unter „PC (optional)“ entfernen.",
                "Better: use another browser as default and remove Mi Browser via “PC (optional)”.",
            ),
            jumps = app(MI_BROWSER),
            openLabel = openApp("Browser", "Browser"),
            requiresPackage = MI_BROWSER,
        ),
        ManualStep(
            id = "music",
            category = Category.ADS,
            title = T("Musik: Werbung aus", "Music: turn off ads"),
            path = T(
                "Musik › Symbol oben links › Einstellungen › Erweiterte Einstellungen › „Werbung anzeigen“ und " +
                    "„Personalisierte Empfehlungen“ ausschalten",
                "Music › icon top left › Settings › Advanced settings › turn off “Show ads” and “Personalized recommendations”",
            ),
            jumps = app(MI_MUSIC),
            openLabel = openApp("Musik", "Music"),
            requiresPackage = MI_MUSIC,
        ),
        ManualStep(
            id = "video",
            category = Category.ADS,
            title = T("Mi Video: Empfehlungen aus", "Mi Video: turn off recommendations"),
            path = T(
                "Mi Video › Profil › Zahnrad › „Personalisierte Empfehlungen“ ausschalten",
                "Mi Video › Profile › gear icon › turn off “Personalized recommendations”",
            ),
            why = T(
                "Xiaomi schaltet das nach 90 Tagen wieder ein. Wer die App nicht braucht, entfernt sie besser unter „PC (optional)“.",
                "Xiaomi turns this back on after 90 days. If you don't need the app, better remove it via “PC (optional)”.",
            ),
            jumps = app(MI_VIDEO),
            openLabel = openApp("Mi Video", "Mi Video"),
            requiresPackage = MI_VIDEO,
        ),
        ManualStep(
            id = "getapps_notifications",
            category = Category.ADS,
            title = T("GetApps-Benachrichtigungen aus", "Turn off GetApps notifications"),
            path = T("Alle Benachrichtigungen von GetApps ausschalten", "Turn off all notifications from GetApps"),
            why = T("GetApps bewirbt per Benachrichtigung Apps und Spiele.", "GetApps advertises apps and games via notifications."),
            jumps = listOf(Jump.AppNotifications(GETAPPS)),
            openLabel = T("Benachrichtigungen öffnen", "Open notifications"),
            requiresPackage = GETAPPS,
        ),
    )
}
