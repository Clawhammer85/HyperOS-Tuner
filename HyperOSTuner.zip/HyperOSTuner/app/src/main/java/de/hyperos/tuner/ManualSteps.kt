package de.hyperos.tuner

import android.content.Intent
import android.provider.Settings

/** Wohin der „Öffnen“-Knopf springt. Mehrere Ziele werden der Reihe nach probiert. */
sealed interface Jump {
    data class Action(val action: String) : Jump
    data class App(val pkg: String) : Jump
    data class AppNotifications(val pkg: String) : Jump
    data class Url(val uri: String) : Jump
    data object Home : Jump
}

data class ManualStep(
    val id: String,
    val category: Category,
    val title: T,
    /** Wo der Schalter liegt. Menünamen können je nach HyperOS-Version leicht abweichen. */
    val path: T,
    val why: T? = null,
    val jumps: List<Jump> = emptyList(),
    val openLabel: T = S.openSettings,
    /** Ist das Paket nicht installiert, entfällt der Punkt. */
    val requiresPackage: String? = null,
    /** Woran die App selbst erkennt, ob der Punkt erledigt ist. */
    val detector: Detector? = null,
    /** Optionale Punkte zählen nicht in den Fortschritt. */
    val optional: Boolean = false,
)

/**
 * Empfehlungen für HyperOS 2/3, zusammengestellt aus smartzone.de, Notebookcheck, techbone.de,
 * Debloat-Projekten auf GitHub und den Herstellerseiten der DNS-Anbieter (Stand Oktober 2026).
 */
object ManualSteps {

    private const val MSA = "com.miui.msa.global"
    private const val CAROUSEL = "com.miui.android.fashiongallery"
    private const val APP_VAULT = "com.mi.globalminusscreen"
    private const val SECURITY = "com.miui.securitycenter"
    private const val DOWNLOADS = "com.android.providers.downloads.ui"
    private const val THEMES = "com.android.thememanager"
    private const val FILES = "com.mi.android.globalFileexplorer"
    private const val BROWSER = "com.mi.globalbrowser"
    private const val MUSIC = "com.miui.player"
    private const val VIDEO = "com.miui.videoplayer"
    private const val GETAPPS = "com.xiaomi.mipicks"
    private const val GBOARD = "com.google.android.inputmethod.latin"
    private const val PLAY_STORE = "com.android.vending"
    private const val GOOGLE_ADS_ACTION = "com.google.android.gms.settings.ADS_PRIVACY"
    private const val NOTIFICATION_SETTINGS = "android.settings.NOTIFICATION_SETTINGS"

    private val settingsHome = listOf(Jump.Action(Settings.ACTION_SETTINGS))
    private val privacy = listOf(Jump.Action(Settings.ACTION_PRIVACY_SETTINGS))
    private val security = listOf(Jump.Action(Settings.ACTION_SECURITY_SETTINGS))
    private val apps = listOf(Jump.Action(Settings.ACTION_APPLICATION_SETTINGS))
    private val notifications = listOf(Jump.Action(NOTIFICATION_SETTINGS))
    private val devOptions = listOf(Jump.Action(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
    private fun app(pkg: String) = listOf(Jump.App(pkg))
    private fun openApp(de: String, en: String) = T("$de öffnen", "Open $en")

    fun all(ramGb: Int, devOptionsEnabled: Boolean): List<ManualStep> {
        val ramAdvice = when {
            ramGb == 0 -> T(
                "Faustregel: ab 8 GB RAM ausschalten, darunter eingeschaltet lassen.",
                "Rule of thumb: turn it off with 8 GB of RAM or more, keep it on below that.",
            )
            ramGb >= 8 -> T(
                "Dein Gerät hat etwa $ramGb GB RAM – ausschalten. Bei so viel Arbeitsspeicher bringt die Erweiterung " +
                    "kaum etwas, belegt aber Speicherplatz.",
                "Your device has about $ramGb GB of RAM – turn it off. With that much memory the extension adds " +
                    "little but takes up storage.",
            )
            else -> T(
                "Dein Gerät hat etwa $ramGb GB RAM – eingeschaltet lassen. Mit wenig Arbeitsspeicher hält die " +
                    "Erweiterung mehr Apps im Hintergrund.",
                "Your device has about $ramGb GB of RAM – keep it on. With little memory, the extension keeps more " +
                    "apps in the background.",
            )
        }

        return listOf(
            // =================================================================== Datenschutz
            ManualStep(
                id = "lockscreen_notifications",
                category = Category.PRIVACY,
                title = T("Nachrichteninhalte auf dem Sperrbildschirm verbergen", "Hide message content on the lock screen"),
                path = T(
                    "Einstellungen › Benachrichtigungen und Statusleiste › Sperrbildschirm-Benachrichtigungen › Inhalte ausblenden",
                    "Settings › Notifications & status bar › Lock screen notifications › Hide content",
                ),
                why = T(
                    "Auf dem Sperrbildschirm steht dann nur noch, dass eine Nachricht da ist – Absender und Text erst nach dem Entsperren.",
                    "The lock screen then only shows that a message arrived – sender and text appear after unlocking.",
                ),
                jumps = notifications,
                detector = Detector.Values(AutoTweaks.lockscreen),
            ),
            ManualStep(
                id = "clipboard",
                category = Category.PRIVACY,
                title = T("Hinweis bei Zugriff auf die Zwischenablage", "Notice when apps read the clipboard"),
                path = T(
                    "Einstellungen › Datenschutz › „Zugriff auf Zwischenablage anzeigen“ einschalten",
                    "Settings › Privacy › turn on “Show clipboard access”",
                ),
                why = T(
                    "Android meldet dann, wenn eine App deine Zwischenablage liest – etwa ein kopiertes Passwort. Meist ab Werk aktiv.",
                    "Android then tells you when an app reads your clipboard – a copied password, for example. Usually on by default.",
                ),
                jumps = privacy,
                detector = Detector.Values(AutoTweaks.clipboard),
            ),
            ManualStep(
                id = "diagnostics",
                category = Category.PRIVACY,
                title = T("Benutzererfahrungsprogramm und Diagnosedaten aus", "Turn off user experience program and diagnostics"),
                path = T(
                    "Einstellungen › Datenschutz › „Benutzererfahrungsprogramm“ ausschalten, außerdem „Verwendung und Diagnostik“ " +
                        "bzw. das automatische Senden von Diagnosedaten",
                    "Settings › Privacy › turn off “User experience program” as well as “Usage & diagnostics” or the " +
                        "automatic sending of diagnostic data",
                ),
                why = T(
                    "Nutzungs- und Absturzdaten gehen sonst an Xiaomi. Telefonie, Apps und Updates funktionieren unverändert.",
                    "Otherwise usage and crash data is sent to Xiaomi. Calls, apps and updates keep working as before.",
                ),
                jumps = privacy,
            ),
            ManualStep(
                id = "google_ad_id",
                category = Category.PRIVACY,
                title = T("Google-Werbe-ID löschen", "Delete the Google advertising ID"),
                path = T(
                    "Einstellungen › Google › Alle Dienste › Werbung › „Werbe-ID löschen“",
                    "Settings › Google › All services › Ads › “Delete advertising ID”",
                ),
                why = T(
                    "Apps können dich dann nicht mehr über diese ID wiedererkennen.",
                    "Apps can no longer recognize you via this ID.",
                ),
                jumps = listOf(Jump.Action(GOOGLE_ADS_ACTION)),
                openLabel = T("Google-Werbung öffnen", "Open Google ads settings"),
            ),
            ManualStep(
                id = "permissions",
                category = Category.PRIVACY,
                title = T("Berechtigungen durchgehen", "Review app permissions"),
                path = T(
                    "Einstellungen › Datenschutz › Berechtigungsmanager: Standort, Kamera und Mikrofon prüfen",
                    "Settings › Privacy › Permission manager: check location, camera and microphone",
                ),
                why = T(
                    "„Nur während der Nutzung“ statt „Immer zulassen“ reicht fast immer.",
                    "“Only while using the app” instead of “Allow all the time” is almost always enough.",
                ),
                jumps = privacy,
            ),
            ManualStep(
                id = "gboard",
                category = Category.PRIVACY,
                title = T("Gboard: Statistiken nicht teilen", "Gboard: don't share statistics"),
                path = T(
                    "Gboard-Einstellungen › Datenschutz › „Nutzungsstatistiken teilen“ und die Optionen zum Verbessern von Gboard ausschalten",
                    "Gboard settings › Privacy › turn off “Share usage statistics” and the options for improving Gboard",
                ),
                jumps = app(GBOARD),
                openLabel = openApp("Gboard", "Gboard"),
                requiresPackage = GBOARD,
            ),
            ManualStep(
                id = "google_location_accuracy",
                category = Category.PRIVACY,
                title = T("Google-Standortgenauigkeit", "Google Location Accuracy"),
                path = T(
                    "Einstellungen › Standort › Standortdienste › Google-Standortgenauigkeit",
                    "Settings › Location › Location services › Google Location Accuracy",
                ),
                why = T(
                    "Schickt WLAN- und Mobilfunkdaten zur Ortung an Google. Ohne dauert die erste Ortung per GPS etwas länger.",
                    "Sends Wi‑Fi and mobile network data to Google for positioning. Without it, the first GPS fix takes a little longer.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_LOCATION_SOURCE_SETTINGS)),
                optional = true,
            ),

            // =================================================================== Sicherheit
            ManualStep(
                id = "screen_lock",
                category = Category.SECURITY,
                title = T("Bildschirmsperre mit PIN oder Passwort", "Screen lock with PIN or password"),
                path = T(
                    "Einstellungen › Fingerabdrücke, Gesichtsdaten und Bildschirmsperre › Bildschirmsperre",
                    "Settings › Fingerprints, face data, and screen lock › Screen lock",
                ),
                why = T(
                    "Eine PIN mit mindestens sechs Ziffern oder ein Passwort ist sicherer als ein Muster. Fingerabdruck " +
                        "oder Gesicht kommen bequem dazu.",
                    "A PIN with at least six digits or a password is safer than a pattern. Fingerprint or face unlock " +
                        "can be added for convenience.",
                ),
                jumps = security,
                detector = Detector.ScreenLock,
            ),
            ManualStep(
                id = "security_patch",
                category = Category.SECURITY,
                title = T("Sicherheitsupdates aktuell", "Security updates up to date"),
                path = T(
                    "Einstellungen › Über das Telefon › HyperOS-Version › Nach Updates suchen",
                    "Settings › About phone › HyperOS version › Check for updates",
                ),
                why = T(
                    "Als aktuell gilt ein Patch-Stand, der höchstens drei Monate alt ist.",
                    "A patch level no older than three months counts as up to date.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_DEVICE_INFO_SETTINGS)),
                detector = Detector.SecurityPatch,
            ),
            ManualStep(
                id = "screen_timeout",
                category = Category.SECURITY,
                title = T("Bildschirm sperrt nach höchstens 1 Minute", "Screen locks after 1 minute at most"),
                path = T(
                    "Einstellungen › Sperrbildschirm › Ruhezustand: 30 Sekunden bis 1 Minute",
                    "Settings › Lock screen › Sleep: 30 seconds to 1 minute",
                ),
                why = T(
                    "Ein unbeaufsichtigtes Handy ist so schneller gesperrt – und der Akku hält länger.",
                    "An unattended phone locks sooner – and the battery lasts longer.",
                ),
                jumps = settingsHome,
                detector = Detector.ScreenTimeout,
            ),
            ManualStep(
                id = "sim_pin",
                category = Category.SECURITY,
                title = T("SIM-PIN aktivieren", "Turn on SIM PIN"),
                path = T(
                    "Einstellungen › Fingerabdrücke, Gesichtsdaten und Bildschirmsperre › Datenschutz › Weitere " +
                        "Sicherheitseinstellungen › SIM-Karte wählen › SIM-Sperre einschalten",
                    "Settings › Passwords & security › Privacy › SIM card lock › choose SIM › Lock SIM card",
                ),
                why = T(
                    "Schützt die SIM-Karte, wenn sie in ein anderes Gerät gesteckt wird. Die PIN steht in den Unterlagen " +
                        "deines Anbieters – nach drei Fehleingaben sperrt sich die Karte.",
                    "Protects the SIM card if it's put into another device. The PIN is in your carrier's documents – " +
                        "three wrong attempts lock the card.",
                ),
                jumps = security,
            ),
            ManualStep(
                id = "find_device",
                category = Category.SECURITY,
                title = T("Geräteortung einschalten", "Turn on device finding"),
                path = T(
                    "Einstellungen › Google › Alle Dienste › Find Hub (früher „Mein Gerät finden“) einschalten",
                    "Settings › Google › All services › turn on Find Hub (formerly Find My Device)",
                ),
                why = T(
                    "Damit lässt sich ein verlorenes Handy orten, sperren oder aus der Ferne löschen.",
                    "Lets you locate, lock or remotely erase a lost phone.",
                ),
                jumps = settingsHome,
            ),
            ManualStep(
                id = "play_protect",
                category = Category.SECURITY,
                title = T("Play Protect eingeschaltet lassen", "Keep Play Protect on"),
                path = T(
                    "Play Store › Profilbild › Play Protect › Zahnrad › „Apps mit Play Protect scannen“ einschalten",
                    "Play Store › profile picture › Play Protect › gear icon › turn on “Scan apps with Play Protect”",
                ),
                why = T(
                    "Prüft installierte Apps regelmäßig auf Schadsoftware.",
                    "Regularly checks installed apps for malware.",
                ),
                jumps = app(PLAY_STORE),
                openLabel = openApp("Play Store", "Play Store"),
                requiresPackage = PLAY_STORE,
            ),
            ManualStep(
                id = "unknown_sources",
                category = Category.SECURITY,
                title = T("„Unbekannte Apps installieren“ einschränken", "Restrict “Install unknown apps”"),
                path = T(
                    "Einstellungen › Apps › Besondere Berechtigungen › Unbekannte Apps installieren: nur erlauben, was es wirklich braucht",
                    "Settings › Apps › Special permissions › Install unknown apps: only allow what really needs it",
                ),
                why = T(
                    "Nach der Installation dieser App kannst du die Erlaubnis für Browser oder Dateimanager wieder entziehen.",
                    "After installing this app, you can revoke the permission for your browser or file manager again.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)),
            ),
            ManualStep(
                id = "usb_debugging",
                category = Category.SECURITY,
                title = T("USB-Debugging ausschalten", "Turn off USB debugging"),
                path = T(
                    "Einstellungen › Weitere Einstellungen › Entwickleroptionen › „USB-Debugging“ ausschalten – die " +
                        "Entwickleroptionen selbst eingeschaltet lassen",
                    "Settings › Additional settings › Developer options › turn off “USB debugging” – keep developer " +
                        "options themselves on",
                ),
                why = T(
                    "Bei eingeschaltetem USB-Debugging kann ein PC tief ins System eingreifen. Nur für die optionale " +
                        "Freischaltung kurz einschalten.",
                    "With USB debugging on, a PC can reach deep into the system. Only turn it on briefly for the " +
                        "optional unlock.",
                ),
                jumps = devOptions,
                openLabel = T("Entwickleroptionen öffnen", "Open developer options"),
                detector = Detector.UsbDebuggingOff,
            ),
            ManualStep(
                id = "accessibility",
                category = Category.SECURITY,
                title = T("Bedienungshilfen prüfen", "Review accessibility services"),
                path = T(
                    "Einstellungen › Weitere Einstellungen › Bedienungshilfen › Heruntergeladene Apps: nur bekannte Apps zulassen",
                    "Settings › Additional settings › Accessibility › Downloaded apps: only allow apps you know",
                ),
                why = T(
                    "Bedienungshilfen dürfen Bildschirminhalte lesen und Eingaben auslösen – ein beliebtes Einfallstor für Schadsoftware.",
                    "Accessibility services can read screen content and trigger input – a popular entry point for malware.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_ACCESSIBILITY_SETTINGS)),
            ),
            ManualStep(
                id = "lockscreen_control_center",
                category = Category.SECURITY,
                title = T("Kontrollzentrum im gesperrten Zustand sperren", "Block Control center while locked"),
                path = T(
                    "Einstellungen › Benachrichtigungen und Statusleiste › „Kontrollzentrum/Benachrichtigungen vom " +
                        "Sperrbildschirm aus öffnen“ › Nicht zulassen",
                    "Settings › Notifications & status bar › “Open Control center/notifications from lock screen” › Don't allow",
                ),
                why = T(
                    "Verhindert, dass jemand am gesperrten Handy den Flugmodus einschaltet und so die Ortung verhindert. " +
                        "Dafür siehst du Benachrichtigungen erst nach dem Entsperren.",
                    "Prevents someone from switching on airplane mode on a locked phone to stop it from being located. " +
                        "In return, you only see notifications after unlocking.",
                ),
                jumps = notifications,
                optional = true,
            ),
            ManualStep(
                id = "app_lock",
                category = Category.SECURITY,
                title = T("App-Sperre für sensible Apps", "App lock for sensitive apps"),
                path = T(
                    "Einstellungen › Apps › App-Sperre (oder Sicherheit › App-Sperre): z. B. Banking, Messenger und Galerie auswählen",
                    "Settings › Apps › App lock (or Security › App lock): select e.g. banking, messengers and gallery",
                ),
                why = T(
                    "Diese Apps verlangen dann zusätzlich Fingerabdruck oder PIN – praktisch, wenn du das Handy entsperrt weitergibst.",
                    "These apps then also require fingerprint or PIN – handy when you hand over your unlocked phone.",
                ),
                jumps = app(SECURITY),
                openLabel = openApp("Sicherheit", "Security"),
                optional = true,
            ),

            // =================================================================== Netzwerk
            ManualStep(
                id = "scanning",
                category = Category.NETWORK,
                title = T("WLAN- und Bluetooth-Suche aus", "Turn off Wi‑Fi and Bluetooth scanning"),
                path = T(
                    "Einstellungen › Standort › Standortdienste: „WLAN-Suche“ und „Bluetooth-Suche“ ausschalten",
                    "Settings › Location › Location services: turn off “Wi‑Fi scanning” and “Bluetooth scanning”",
                ),
                why = T(
                    "Sonst suchen Ortungsdienste auch bei ausgeschaltetem WLAN und Bluetooth nach Netzen und Geräten in " +
                        "der Nähe, um deinen Standort zu bestimmen. Spart nebenbei etwas Akku.",
                    "Otherwise location services keep scanning for nearby networks and devices even with Wi‑Fi and " +
                        "Bluetooth off, to work out your location. Saves some battery, too.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_LOCATION_SOURCE_SETTINGS)),
                detector = Detector.Values(AutoTweaks.scanning),
            ),
            ManualStep(
                id = "mac_random",
                category = Category.NETWORK,
                title = T("Zufällige MAC-Adresse im WLAN", "Randomized MAC address on Wi‑Fi"),
                path = T(
                    "Einstellungen › WLAN › gespeichertes Netz antippen › Datenschutz: „Zufällige MAC-Adresse“ verwenden",
                    "Settings › Wi‑Fi › tap a saved network › Privacy: use “Randomized MAC”",
                ),
                why = T(
                    "Erschwert es, dein Gerät über verschiedene WLAN-Netze hinweg wiederzuerkennen. Bei neuen Netzen meist " +
                        "schon aktiv – vor allem ältere, gespeicherte Netze prüfen.",
                    "Makes it harder to recognize your device across Wi‑Fi networks. Usually already on for new " +
                        "networks – check older saved ones in particular.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_WIFI_SETTINGS)),
            ),
            ManualStep(
                id = "quick_share",
                category = Category.NETWORK,
                title = T("Quick Share nur für Kontakte", "Quick Share for contacts only"),
                path = T(
                    "Einstellungen › Google › Alle Dienste › Geräte und Teilen › Quick Share › Sichtbarkeit: „Deine " +
                        "Geräte“ oder „Kontakte“",
                    "Settings › Google › All services › Devices & sharing › Quick Share › Visibility: “Your devices” " +
                        "or “Contacts”",
                ),
                why = T(
                    "Mit „Alle“ kann dir jeder in der Nähe Dateien anbieten – das wird für Spam und Phishing ausgenutzt.",
                    "With “Everyone”, anyone nearby can send you files – which gets abused for spam and phishing.",
                ),
                jumps = settingsHome,
            ),
            ManualStep(
                id = "private_dns",
                category = Category.NETWORK,
                title = T("Privates DNS mit Werbefilter", "Private DNS with ad filter"),
                path = T(
                    "Anbieter wählen und „Hostname kopieren“ tippen. Dann Einstellungen › Verbindung & Freigabe › Privates " +
                        "DNS › „Hostname des privaten DNS-Anbieters“ wählen und einfügen.",
                    "Pick a provider and tap “Copy hostname”. Then go to Settings › Connection & sharing › Private DNS › " +
                        "choose “Private DNS provider hostname” and paste it.",
                ),
                why = T(
                    "Filtert Werbe- und Tracking-Adressen systemweit, auch in Xiaomi-Apps. In manchen Firmen- oder " +
                        "Hotel-WLANs ist der nötige Port 853 gesperrt – dann dort auf „Automatisch“ zurückstellen. Einen " +
                        "eigenen Filter im Heimnetz, etwa ein Pi-hole, umgeht Privates DNS.",
                    "Filters ad and tracking domains system-wide, including in Xiaomi apps. Some company or hotel Wi‑Fi " +
                        "networks block the required port 853 – switch back to “Automatic” there. Private DNS bypasses " +
                        "your own filter at home, such as a Pi-hole.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_WIRELESS_SETTINGS)),
                detector = Detector.PrivateDns,
                optional = true,
            ),

            // =================================================================== Werbung
            ManualStep(
                id = "msa",
                category = Category.ADS,
                title = T("Werbedienst „msa“ widerrufen", "Revoke the “msa” ad service"),
                path = T(
                    "Einstellungen › Fingerabdrücke, Gesichtsdaten und Bildschirmsperre (je nach Version: Passwörter & " +
                        "Sicherheit) › Autorisierung & Widerruf › „msa“ ausschalten",
                    "Settings › Fingerprints, face data, and screen lock (or Passwords & security) › Authorization & " +
                        "revocation › turn off “msa”",
                ),
                why = T(
                    "Die Schaltzentrale der Systemwerbung. Klappt oft erst im zweiten oder dritten Anlauf – den " +
                        "10-Sekunden-Countdown jeweils abwarten.",
                    "The control center of system ads. Often only works on the second or third try – wait for the " +
                        "10-second countdown each time.",
                ),
                jumps = security,
                requiresPackage = MSA,
            ),
            ManualStep(
                id = "personalized_ads",
                category = Category.ADS,
                title = T("Personalisierte Werbung aus", "Turn off personalized ads"),
                path = T(
                    "Einstellungen › Datenschutz › Werbedienste › „Personalisierte Werbung“ ausschalten",
                    "Settings › Privacy › Ad services › turn off “Personalized ad recommendations”",
                ),
                why = T(
                    "Xiaomi bildet dann kein Werbeprofil mehr aus deiner Nutzung.",
                    "Xiaomi then stops building an ad profile from your usage.",
                ),
                jumps = privacy,
            ),
            ManualStep(
                id = "app_manager_recommendations",
                category = Category.ADS,
                title = T("Empfehlungen in der App-Verwaltung aus", "Turn off recommendations in Manage apps"),
                path = T(
                    "Einstellungen › Apps › Apps verwalten › ⋮ (oben rechts) › Weitere Einstellungen › „Empfehlungen“ ausschalten",
                    "Settings › Apps › Manage apps › ⋮ (top right) › More settings › turn off “Recommendations”",
                ),
                why = T("Gut versteckt: Auch hier blendet Xiaomi Werbung ein.", "Well hidden: Xiaomi shows ads here, too."),
                jumps = apps,
            ),
            ManualStep(
                id = "carousel",
                category = Category.ADS,
                title = T("Hintergrund-Karussell entfernen", "Remove the wallpaper carousel"),
                path = T(
                    "Am einfachsten im Play Store deinstallieren. Alternativ: Einstellungen › Sperrbildschirm › " +
                        "Hintergrund-Karussell ausschalten.",
                    "Easiest: uninstall it in the Play Store. Alternatively: Settings › Lock screen › turn off Wallpaper carousel.",
                ),
                why = T(
                    "Zeigt Werbe-Hintergründe auf dem Sperrbildschirm und lädt dafür regelmäßig Daten nach.",
                    "Shows promotional wallpapers on the lock screen and regularly downloads data for them.",
                ),
                jumps = listOf(
                    Jump.Url("market://details?id=$CAROUSEL"),
                    Jump.Url("https://play.google.com/store/apps/details?id=$CAROUSEL"),
                ),
                openLabel = T("Im Play Store öffnen", "Open in Play Store"),
                requiresPackage = CAROUSEL,
            ),
            ManualStep(
                id = "app_vault",
                category = Category.ADS,
                title = T("App Vault auf der linken Seite ersetzen", "Replace App Vault on the left screen"),
                path = T(
                    "Einstellungen › Startbildschirm (oder lange auf eine freie Stelle drücken › Einstellungen) › linke " +
                        "Seite auf „Google Discover“ oder „Nichts“ stellen",
                    "Settings › Home screen (or long-press an empty spot › Settings) › set the left screen to “Google " +
                        "Discover” or “None”",
                ),
                why = T(
                    "Der Info-Assistent blendet Werbung und App-Vorschläge ein.",
                    "The App Vault shows ads and app suggestions.",
                ),
                jumps = settingsHome,
                requiresPackage = APP_VAULT,
            ),
            ManualStep(
                id = "folder_suggestions",
                category = Category.ADS,
                title = T("App-Vorschläge in Ordnern aus", "Turn off app suggestions in folders"),
                path = T(
                    "Einen Ordner auf dem Startbildschirm öffnen › Ordnernamen lange drücken › Vorschläge ausschalten",
                    "Open a folder on the home screen › long-press the folder name › turn off suggestions",
                ),
                why = T(
                    "Sonst stehen beworbene Apps zwischen deinen, als wären sie schon installiert.",
                    "Otherwise promoted apps appear among yours as if they were already installed.",
                ),
                jumps = listOf(Jump.Home),
                openLabel = T("Startbildschirm öffnen", "Open home screen"),
            ),
            ManualStep(
                id = "security_app",
                category = Category.ADS,
                title = T("Sicherheit-App: Empfehlungen aus", "Security app: turn off recommendations"),
                path = T(
                    "Sicherheit › Zahnrad oben rechts › „Empfehlungen anzeigen“ ausschalten. Dann Bereinigen › " +
                        "Einstellungen › dort ebenfalls „Empfehlungen anzeigen“ ausschalten.",
                    "Security › gear icon top right › turn off “Receive recommendations”. Then Cleaner › Settings › " +
                        "turn off “Receive recommendations” there as well.",
                ),
                why = T(
                    "Im selben Menü lässt sich die Zusatzprüfung neuer Apps abschalten – Installationen gehen dann " +
                        "schneller. Lass sie an, wenn du öfter Apps außerhalb des Play Stores installierst.",
                    "In the same menu you can turn off the extra scan of new apps – installs get faster. Keep it on if " +
                        "you often install apps from outside the Play Store.",
                ),
                jumps = app(SECURITY),
                openLabel = openApp("Sicherheit", "Security"),
                requiresPackage = SECURITY,
            ),
            ManualStep(
                id = "downloads",
                category = Category.ADS,
                title = T("Downloads: Werbung aus", "Downloads: turn off ads"),
                path = T(
                    "Downloads › Menü (drei Striche oben rechts) › Einstellungen › „Werbung anzeigen“ bzw. „Empfehlungen“ ausschalten",
                    "Downloads › menu (three lines top right) › Settings › turn off “Show recommended content”",
                ),
                jumps = app(DOWNLOADS),
                openLabel = openApp("Downloads", "Downloads"),
                requiresPackage = DOWNLOADS,
            ),
            ManualStep(
                id = "themes",
                category = Category.ADS,
                title = T("Designs: Werbung aus", "Themes: turn off ads"),
                path = T(
                    "Designs › Profil (unten rechts) › Zahnrad › „Werbung anzeigen“ und „Personalisierte Empfehlungen“ ausschalten",
                    "Themes › Profile (bottom right) › gear icon › turn off “Show ads” and “Personalized recommendations”",
                ),
                jumps = app(THEMES),
                openLabel = openApp("Designs", "Themes"),
                requiresPackage = THEMES,
            ),
            ManualStep(
                id = "files",
                category = Category.ADS,
                title = T("Dateimanager: Empfehlungen aus", "File Manager: turn off recommendations"),
                path = T(
                    "Dateimanager › Einstellungen › „Empfehlungen“ ausschalten",
                    "File Manager › Settings › turn off “Recommendations”",
                ),
                why = T(
                    "Laut aktuellen Tests lässt er sich nicht mehr überall ganz werbefrei bekommen. Google Files ist eine werbefreie Alternative.",
                    "According to recent tests, it can't always be made fully ad-free. Google Files is an ad-free alternative.",
                ),
                jumps = app(FILES),
                openLabel = openApp("Dateimanager", "File Manager"),
                requiresPackage = FILES,
            ),
            ManualStep(
                id = "browser",
                category = Category.ADS,
                title = T("Mi Browser: Werbung aus", "Mi Browser: turn off ads"),
                path = T(
                    "Mi Browser › Profilsymbol unten rechts › Zahnrad › Erweitert › „Werbung anzeigen“ ausschalten",
                    "Mi Browser › profile icon bottom right › gear icon › Advanced › turn off “Show ads”",
                ),
                why = T(
                    "Besser: einen anderen Browser als Standard nutzen und den Mi Browser per PC-Skript entfernen.",
                    "Better: use another browser as default and remove Mi Browser with the PC script.",
                ),
                jumps = app(BROWSER),
                openLabel = openApp("Browser", "Browser"),
                requiresPackage = BROWSER,
            ),
            ManualStep(
                id = "music",
                category = Category.ADS,
                title = T("Musik: Werbung aus", "Music: turn off ads"),
                path = T(
                    "Musik › Symbol oben links › Einstellungen › Erweiterte Einstellungen › „Werbung anzeigen“ und " +
                        "„Personalisierte Empfehlungen“ ausschalten",
                    "Music › icon top left › Settings › Advanced settings › turn off “Show ads” and “Personalized recommendations”",
                ),
                jumps = app(MUSIC),
                openLabel = openApp("Musik", "Music"),
                requiresPackage = MUSIC,
            ),
            ManualStep(
                id = "video",
                category = Category.ADS,
                title = T("Mi Video: Empfehlungen aus", "Mi Video: turn off recommendations"),
                path = T(
                    "Mi Video › Profil › Zahnrad › „Personalisierte Empfehlungen“ ausschalten",
                    "Mi Video › Profile › gear icon › turn off “Personalized recommendations”",
                ),
                why = T(
                    "Xiaomi schaltet das nach 90 Tagen wieder ein. Wer die App nicht braucht, entfernt sie besser per PC-Skript.",
                    "Xiaomi turns this back on after 90 days. If you don't need the app, better remove it with the PC script.",
                ),
                jumps = app(VIDEO),
                openLabel = openApp("Mi Video", "Mi Video"),
                requiresPackage = VIDEO,
            ),
            ManualStep(
                id = "getapps_notifications",
                category = Category.ADS,
                title = T("GetApps-Benachrichtigungen aus", "Turn off GetApps notifications"),
                path = T("Alle Benachrichtigungen von GetApps ausschalten", "Turn off all notifications from GetApps"),
                why = T(
                    "GetApps bewirbt per Benachrichtigung Apps und Spiele.",
                    "GetApps advertises apps and games via notifications.",
                ),
                jumps = listOf(Jump.AppNotifications(GETAPPS)),
                openLabel = T("Benachrichtigungen öffnen", "Open notifications"),
                requiresPackage = GETAPPS,
            ),

            // =================================================================== Geschwindigkeit
            ManualStep(
                id = "animations",
                category = Category.SPEED,
                title = T("Animationen auf 0,5×", "Animations at 0.5×"),
                path = if (devOptionsEnabled) {
                    T(
                        "Einstellungen › Weitere Einstellungen › Entwickleroptionen › die drei Einträge zur " +
                            "Animationsskalierung (Fenster, Übergang, Animator) jeweils auf 0,5× stellen",
                        "Settings › Additional settings › Developer options › set the three animation scale entries " +
                            "(window, transition, animator) to 0.5× each",
                    )
                } else {
                    T(
                        "Zuerst die Entwickleroptionen freischalten: Über das Telefon › siebenmal auf „OS-Version“ " +
                            "tippen. Danach unter Weitere Einstellungen › Entwickleroptionen die drei Einträge zur " +
                            "Animationsskalierung (Fenster, Übergang, Animator) jeweils auf 0,5× stellen.",
                        "First enable developer options: About phone › tap “OS version” seven times. Then, under " +
                            "Additional settings › Developer options, set the three animation scale entries (window, " +
                            "transition, animator) to 0.5× each.",
                    )
                },
                why = T(
                    "Das System reagiert spürbar flotter, Animationen bleiben sichtbar. Die Entwickleroptionen danach " +
                        "eingeschaltet lassen – beim Abschalten setzt Android die Werte zurück.",
                    "The system feels noticeably snappier while animations stay visible. Keep developer options on " +
                        "afterwards – turning them off resets the values.",
                ),
                jumps = if (devOptionsEnabled) devOptions else listOf(Jump.Action(Settings.ACTION_DEVICE_INFO_SETTINGS)),
                openLabel = if (devOptionsEnabled) {
                    T("Entwickleroptionen öffnen", "Open developer options")
                } else {
                    T("„Über das Telefon“ öffnen", "Open “About phone”")
                },
                detector = Detector.Values(AutoTweaks.animations),
            ),
            ManualStep(
                id = "launcher_animation",
                category = Category.SPEED,
                title = T("Animationen des Startbildschirms: schnell", "Home screen animations: fast"),
                path = T(
                    "Einstellungen › Startbildschirm › Animationsgeschwindigkeit › „Schnell“",
                    "Settings › Home screen › Animation speed › “Fast”",
                ),
                why = T(
                    "Ergänzt die 0,5×-Animationen – betrifft Öffnen, Schließen und Wischen auf dem Startbildschirm.",
                    "Complements the 0.5× animations – affects opening, closing and swiping on the home screen.",
                ),
                jumps = settingsHome,
            ),
            ManualStep(
                id = "autostart",
                category = Category.SPEED,
                title = T("Hintergrund-Autostart begrenzen", "Limit background autostart"),
                path = T(
                    "Einstellungen › Apps › (Berechtigungen ›) Hintergrund-Autostart: nur Messenger und Apps erlauben, " +
                        "die zuverlässig benachrichtigen müssen",
                    "Settings › Apps › (Permissions ›) Background autostart: only allow messengers and apps that must " +
                        "notify you reliably",
                ),
                why = T(
                    "Jede App mit Autostart läuft im Hintergrund weiter und kostet Arbeitsspeicher und Akku.",
                    "Every app with autostart keeps running in the background, costing memory and battery.",
                ),
                jumps = apps,
            ),
            ManualStep(
                id = "free_storage",
                category = Category.SPEED,
                title = T("Mindestens 15 % Speicher frei", "At least 15% storage free"),
                path = T(
                    "Einstellungen › Über das Telefon › Speicher – oder Sicherheit › Bereinigen",
                    "Settings › About phone › Storage – or Security › Cleaner",
                ),
                why = T(
                    "Ist der Speicher fast voll, wird das ganze System spürbar langsamer.",
                    "When storage is almost full, the whole system slows down noticeably.",
                ),
                jumps = listOf(Jump.Action(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)),
                detector = Detector.FreeStorage,
            ),
            ManualStep(
                id = "memory_extension",
                category = Category.SPEED,
                title = T("Speichererweiterung", "Memory extension"),
                path = T(
                    "Einstellungen › Weitere Einstellungen › Speichererweiterung",
                    "Settings › Additional settings › Memory extension",
                ),
                why = ramAdvice,
                jumps = settingsHome,
            ),
            ManualStep(
                id = "performance_mode",
                category = Category.SPEED,
                title = T("Leistungsmodus", "Performance mode"),
                path = T("Einstellungen › Akku › Leistungsmodus", "Settings › Battery › Performance mode"),
                why = T(
                    "Mehr Tempo bei Spielen und anspruchsvollen Apps, dafür mehr Akkuverbrauch und Wärme. Nur " +
                        "einschalten, wenn dir das wichtiger ist als die Laufzeit.",
                    "More speed in games and demanding apps, at the cost of battery and heat. Only turn it on if that " +
                        "matters more to you than battery life.",
                ),
                jumps = listOf(Jump.Action(Intent.ACTION_POWER_USAGE_SUMMARY)),
                optional = true,
            ),
        )
    }
}
