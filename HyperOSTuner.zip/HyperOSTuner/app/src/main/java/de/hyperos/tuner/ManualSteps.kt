package de.hyperos.tuner

import android.content.Intent
import android.provider.Settings

/** Wohin der „Öffnen“-Knopf springt. Mehrere Ziele werden der Reihe nach probiert. */
sealed interface Jump {
    data class Action(val action: String) : Jump
    data class App(val pkg: String) : Jump
    data class AppNotifications(val pkg: String) : Jump
    data class Url(val uri: String) : Jump
    data object Home : Jump
}

data class ManualStep(
    val id: String,
    val category: Category,
    val title: String,
    /** Wo der Schalter in HyperOS liegt. Menünamen können je nach Version leicht abweichen. */
    val path: String,
    val why: String = "",
    val jumps: List<Jump> = emptyList(),
    val openLabel: String = "Einstellungen öffnen",
    /** Ist das Paket nicht installiert, entfällt der Schritt. */
    val requiresPackage: String? = null,
    /** Systemwerte, an denen die App erkennt, ob der Punkt erledigt ist. */
    val tweak: AutoTweak? = null,
)

/**
 * Schalter, die keine öffentliche Schnittstelle haben und deshalb von Hand gesetzt werden.
 * Zusammengestellt aus aktuellen HyperOS-3-Anleitungen (smartzone.de, Notebookcheck, techbone.de).
 */
object ManualSteps {

    const val PRIVATE_DNS_ID = "private_dns"

    private const val MSA = "com.miui.msa.global"
    private const val CAROUSEL = "com.miui.android.fashiongallery"
    private const val APP_VAULT = "com.mi.globalminusscreen"
    private const val SECURITY = "com.miui.securitycenter"
    private const val DOWNLOADS = "com.android.providers.downloads.ui"
    private const val THEMES = "com.android.thememanager"
    private const val FILES = "com.mi.android.globalFileexplorer"
    private const val BROWSER = "com.mi.globalbrowser"
    private const val MUSIC = "com.miui.player"
    private const val VIDEO = "com.miui.videoplayer"
    private const val GETAPPS = "com.xiaomi.mipicks"
    private const val GBOARD = "com.google.android.inputmethod.latin"
    private const val GOOGLE_ADS_ACTION = "com.google.android.gms.settings.ADS_PRIVACY"

    private val settingsHome = listOf(Jump.Action(Settings.ACTION_SETTINGS))
    private val privacy = listOf(Jump.Action(Settings.ACTION_PRIVACY_SETTINGS))
    private fun app(pkg: String) = listOf(Jump.App(pkg))

    fun all(ramGb: Int, devOptionsEnabled: Boolean): List<ManualStep> {
        val ramAdvice = when {
            ramGb == 0 -> "Faustregel: ab 8 GB RAM ausschalten, darunter eingeschaltet lassen."
            ramGb >= 8 -> "Dein Gerät hat etwa $ramGb GB RAM – ausschalten. Bei so viel Arbeitsspeicher " +
                "bringt die Erweiterung kaum etwas, belegt aber Speicherplatz."
            else -> "Dein Gerät hat etwa $ramGb GB RAM – eingeschaltet lassen. Mit wenig " +
                "Arbeitsspeicher hält die Erweiterung mehr Apps im Hintergrund."
        }

        return listOf(
            // ---------------------------------------------------------------- Werbung
            ManualStep(
                id = "msa",
                category = Category.ADS,
                title = "Werbedienst „msa“ widerrufen",
                path = "Einstellungen › Fingerabdrücke, Gesichtsdaten und Bildschirmsperre (je nach " +
                    "Version: Passwörter & Sicherheit) › Autorisierung & Widerruf › „msa“ ausschalten",
                why = "Die Schaltzentrale der Systemwerbung. Klappt oft erst im zweiten oder dritten " +
                    "Anlauf – den 10-Sekunden-Countdown jeweils abwarten.",
                jumps = listOf(Jump.Action(Settings.ACTION_SECURITY_SETTINGS)),
                requiresPackage = MSA,
            ),
            ManualStep(
                id = "personalized_ads",
                category = Category.ADS,
                title = "Personalisierte Werbung aus",
                path = "Einstellungen › Datenschutz › Werbedienste › „Personalisierte Werbung“ ausschalten",
                why = "Xiaomi bildet dann kein Werbeprofil mehr aus deiner Nutzung.",
                jumps = privacy,
            ),
            ManualStep(
                id = PRIVATE_DNS_ID,
                category = Category.ADS,
                title = "Privates DNS mit Werbefilter (optional)",
                path = "Anbieter unten wählen und „Hostname kopieren“. Dann Einstellungen › Verbindung & " +
                    "Freigabe › Privates DNS › „Hostname des privaten DNS-Anbieters“ wählen und einfügen.",
                why = "Filtert Werbe- und Tracking-Adressen systemweit, auch in Xiaomi-Apps. In manchen Firmen- " +
                    "oder Hotel-WLANs ist der nötige Port 853 gesperrt – dann dort auf „Automatisch“ zurückstellen. " +
                    "Einen eigenen Filter im Heimnetz, etwa ein Pi-hole, umgeht Privates DNS.",
                jumps = listOf(Jump.Action(Settings.ACTION_WIRELESS_SETTINGS)),
            ),
            ManualStep(
                id = "carousel",
                category = Category.ADS,
                title = "Hintergrund-Karussell entfernen",
                path = "Am einfachsten im Play Store deinstallieren. Alternativ: Einstellungen › " +
                    "Sperrbildschirm › Hintergrund-Karussell ausschalten.",
                why = "Zeigt Werbe-Hintergründe auf dem Sperrbildschirm und lädt dafür regelmäßig Daten nach.",
                jumps = listOf(
                    Jump.Url("market://details?id=$CAROUSEL"),
                    Jump.Url("https://play.google.com/store/apps/details?id=$CAROUSEL"),
                ),
                openLabel = "Im Play Store öffnen",
                requiresPackage = CAROUSEL,
            ),
            ManualStep(
                id = "app_vault",
                category = Category.ADS,
                title = "App Vault auf der linken Seite ersetzen",
                path = "Einstellungen › Startbildschirm (oder lange auf eine freie Stelle drücken › " +
                    "Einstellungen) › linke Seite auf „Google Discover“ oder „Nichts“ stellen",
                why = "Der Info-Assistent blendet Werbung und App-Vorschläge ein.",
                jumps = settingsHome,
                requiresPackage = APP_VAULT,
            ),
            ManualStep(
                id = "folder_suggestions",
                category = Category.ADS,
                title = "App-Vorschläge in Ordnern aus",
                path = "Einen Ordner auf dem Startbildschirm öffnen › Ordnernamen lange drücken › " +
                    "Vorschläge ausschalten",
                why = "Sonst stehen beworbene Apps zwischen deinen, als wären sie schon installiert.",
                jumps = listOf(Jump.Home),
                openLabel = "Startbildschirm öffnen",
            ),
            ManualStep(
                id = "security_app",
                category = Category.ADS,
                title = "Sicherheit-App: Empfehlungen aus",
                path = "Sicherheit › Zahnrad oben rechts › „Empfehlungen anzeigen“ aus. Dann " +
                    "Bereinigen › Einstellungen › dort ebenfalls „Empfehlungen anzeigen“ aus.",
                why = "Im selben Menü lässt sich die Zusatzprüfung neuer Apps abschalten – " +
                    "Installationen gehen dann schneller. Lass sie an, wenn du öfter Apps außerhalb " +
                    "des Play Stores installierst.",
                jumps = app(SECURITY),
                openLabel = "Sicherheit öffnen",
                requiresPackage = SECURITY,
            ),
            ManualStep(
                id = "downloads",
                category = Category.ADS,
                title = "Downloads: Werbung aus",
                path = "Downloads › Menü (drei Striche oben rechts) › Einstellungen › „Werbung anzeigen“ " +
                    "bzw. „Empfehlungen“ aus",
                jumps = app(DOWNLOADS),
                openLabel = "Downloads öffnen",
                requiresPackage = DOWNLOADS,
            ),
            ManualStep(
                id = "themes",
                category = Category.ADS,
                title = "Designs: Werbung aus",
                path = "Designs › Profil (unten rechts) › Zahnrad › „Werbung anzeigen“ und " +
                    "„Personalisierte Empfehlungen“ aus",
                jumps = app(THEMES),
                openLabel = "Designs öffnen",
                requiresPackage = THEMES,
            ),
            ManualStep(
                id = "files",
                category = Category.ADS,
                title = "Dateimanager: Empfehlungen aus",
                path = "Dateimanager › Einstellungen › „Empfehlungen“ aus",
                why = "Laut aktuellen Tests nicht mehr überall ganz werbefrei zu bekommen. " +
                    "Google Files ist eine werbefreie Alternative.",
                jumps = app(FILES),
                openLabel = "Dateimanager öffnen",
                requiresPackage = FILES,
            ),
            ManualStep(
                id = "browser",
                category = Category.ADS,
                title = "Mi Browser: Werbung aus",
                path = "Mi Browser › Profil-Symbol unten rechts › Zahnrad › Erweitert › " +
                    "„Werbung anzeigen“ aus",
                why = "Besser: einen anderen Browser als Standard nutzen und den Mi Browser per " +
                    "PC-Skript entfernen.",
                jumps = app(BROWSER),
                openLabel = "Browser öffnen",
                requiresPackage = BROWSER,
            ),
            ManualStep(
                id = "music",
                category = Category.ADS,
                title = "Musik: Werbung aus",
                path = "Musik › Symbol oben links › Einstellungen › Erweiterte Einstellungen › " +
                    "„Werbung anzeigen“ und „Personalisierte Empfehlungen“ aus",
                jumps = app(MUSIC),
                openLabel = "Musik öffnen",
                requiresPackage = MUSIC,
            ),
            ManualStep(
                id = "video",
                category = Category.ADS,
                title = "Mi Video: Empfehlungen aus",
                path = "Mi Video › Profil › Zahnrad › „Personalisierte Empfehlungen“ aus",
                why = "Xiaomi schaltet das nach 90 Tagen wieder ein. Wer die App nicht braucht, " +
                    "entfernt sie besser per PC-Skript.",
                jumps = app(VIDEO),
                openLabel = "Mi Video öffnen",
                requiresPackage = VIDEO,
            ),
            ManualStep(
                id = "getapps_notifications",
                category = Category.ADS,
                title = "GetApps-Benachrichtigungen aus",
                path = "Alle Benachrichtigungen von GetApps ausschalten",
                why = "GetApps bewirbt per Benachrichtigung Apps und Spiele.",
                jumps = listOf(Jump.AppNotifications(GETAPPS)),
                openLabel = "Benachrichtigungen öffnen",
                requiresPackage = GETAPPS,
            ),

            // ---------------------------------------------------------------- Datenschutz
            ManualStep(
                id = "scanning",
                category = Category.PRIVACY,
                title = "WLAN- und Bluetooth-Suche aus",
                path = "Einstellungen › Standort › Standortdienste: „WLAN-Suche“ und „Bluetooth-Suche“ ausschalten",
                why = "Sonst suchen Ortungsdienste auch bei ausgeschaltetem WLAN und Bluetooth nach Netzen und " +
                    "Geräten in der Nähe, um deinen Standort zu bestimmen. Spart nebenbei etwas Akku.",
                jumps = listOf(Jump.Action(Settings.ACTION_LOCATION_SOURCE_SETTINGS)),
                tweak = AutoTweaks.scanning,
            ),
            ManualStep(
                id = "lockscreen_notifications",
                category = Category.PRIVACY,
                title = "Nachrichteninhalte auf dem Sperrbildschirm verbergen",
                path = "Einstellungen › Benachrichtigungen & Kontrollzentrum (oder Sperrbildschirm) › " +
                    "Benachrichtigungen auf dem Sperrbildschirm › Inhalte verbergen",
                why = "Auf dem Sperrbildschirm steht dann nur noch, dass eine Nachricht da ist – Absender und Text " +
                    "erst nach dem Entsperren.",
                jumps = listOf(Jump.Action("android.settings.NOTIFICATION_SETTINGS")),
                tweak = AutoTweaks.lockscreen,
            ),
            ManualStep(
                id = "diagnostics",
                category = Category.PRIVACY,
                title = "Benutzererfahrungsprogramm und Diagnosedaten aus",
                path = "Einstellungen › Datenschutz › „Benutzererfahrungsprogramm“ aus, außerdem " +
                    "„Verwendung und Diagnostik“ bzw. das automatische Senden von Diagnosedaten aus",
                why = "Nutzungs- und Absturzdaten gehen sonst an Xiaomi. Telefonie, Apps und Updates " +
                    "funktionieren unverändert.",
                jumps = privacy,
            ),
            ManualStep(
                id = "google_ad_id",
                category = Category.PRIVACY,
                title = "Google-Werbe-ID löschen",
                path = "Einstellungen › Google › Alle Dienste › Werbung › „Werbe-ID löschen“",
                why = "Apps können dich dann nicht mehr über diese ID wiedererkennen.",
                jumps = listOf(Jump.Action(GOOGLE_ADS_ACTION)),
                openLabel = "Google-Werbung öffnen",
            ),
            ManualStep(
                id = "permissions",
                category = Category.PRIVACY,
                title = "Berechtigungen durchgehen",
                path = "Einstellungen › Datenschutz › Berechtigungsmanager: Standort, Kamera und " +
                    "Mikrofon prüfen",
                why = "„Nur während der Nutzung“ statt „Immer zulassen“ reicht fast immer.",
                jumps = privacy,
            ),
            ManualStep(
                id = "google_location_accuracy",
                category = Category.PRIVACY,
                title = "Google-Standortgenauigkeit (optional)",
                path = "Einstellungen › Standort › Standortdienste › Google-Standortgenauigkeit",
                why = "Schickt WLAN- und Mobilfunkdaten zur Ortung an Google. Ohne dauert die erste " +
                    "Ortung per GPS etwas länger.",
                jumps = listOf(Jump.Action(Settings.ACTION_LOCATION_SOURCE_SETTINGS)),
            ),
            ManualStep(
                id = "gboard",
                category = Category.PRIVACY,
                title = "Gboard: Statistiken nicht teilen",
                path = "Gboard › Datenschutz › „Nutzungsstatistiken teilen“ und die Optionen zum " +
                    "Verbessern von Gboard ausschalten",
                jumps = app(GBOARD),
                openLabel = "Gboard öffnen",
                requiresPackage = GBOARD,
            ),

            // ---------------------------------------------------------------- Geschwindigkeit
            ManualStep(
                id = "animations",
                category = Category.SPEED,
                title = "Animationen auf 0,5×",
                path = if (devOptionsEnabled) {
                    "Einstellungen › Weitere Einstellungen › Entwickleroptionen › die drei Einträge zur " +
                        "Animationsskalierung (Fenster, Übergang, Animator) jeweils auf 0,5× stellen"
                } else {
                    "Zuerst die Entwickleroptionen freischalten: Über das Telefon › siebenmal auf „OS-Version“ " +
                        "tippen. Danach unter Weitere Einstellungen › Entwickleroptionen die drei Einträge zur " +
                        "Animationsskalierung (Fenster, Übergang, Animator) jeweils auf 0,5× stellen."
                },
                why = "Das System reagiert spürbar flotter, Animationen bleiben sichtbar. Die Entwickleroptionen " +
                    "danach eingeschaltet lassen – beim Abschalten setzt Android die Werte zurück.",
                jumps = if (devOptionsEnabled) {
                    listOf(Jump.Action(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                } else {
                    listOf(Jump.Action(Settings.ACTION_DEVICE_INFO_SETTINGS))
                },
                openLabel = if (devOptionsEnabled) "Entwickleroptionen öffnen" else "„Über das Telefon“ öffnen",
                tweak = AutoTweaks.animations,
            ),
            ManualStep(
                id = "launcher_animation",
                category = Category.SPEED,
                title = "Animationsgeschwindigkeit des Startbildschirms",
                path = "Einstellungen › Startbildschirm › Animationsgeschwindigkeit › „Schnell“",
                why = "Ergänzt die 0,5×-Animationen – betrifft Öffnen, Schließen " +
                    "und Wischen auf dem Startbildschirm.",
                jumps = settingsHome,
            ),
            ManualStep(
                id = "memory_extension",
                category = Category.SPEED,
                title = "Speichererweiterung",
                path = "Einstellungen › Weitere Einstellungen › Speichererweiterung",
                why = ramAdvice,
                jumps = settingsHome,
            ),
            ManualStep(
                id = "performance_mode",
                category = Category.SPEED,
                title = "Leistungsmodus (optional)",
                path = "Einstellungen › Akku › Leistungsmodus",
                why = "Mehr Tempo bei Spielen und schweren Apps, dafür mehr Akkuverbrauch und Wärme. " +
                    "Nur einschalten, wenn dir das wichtiger ist als die Laufzeit.",
                jumps = listOf(Jump.Action(Intent.ACTION_POWER_USAGE_SUMMARY)),
            ),
        )
    }
}
