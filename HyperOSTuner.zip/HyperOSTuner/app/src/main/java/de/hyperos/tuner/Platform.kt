package de.hyperos.tuner

import android.os.Build

/** Für welche Oberfläche die Empfehlungen gelten. */
enum class Platform(val label: T) {
    XIAOMI(T("Xiaomi · HyperOS", "Xiaomi · HyperOS")),
    SAMSUNG(T("Samsung · One UI", "Samsung · One UI")),
    GENERIC(T("Android allgemein", "Generic Android")),
}

/** Schriftzug oben links: [left]⚡[right]. */
data class Brand(val left: String, val right: String)

object Platforms {

    private val manufacturer: String
        get() = "${Build.MANUFACTURER} ${Build.BRAND}".lowercase()

    fun detect(): Platform = when {
        listOf("xiaomi", "redmi", "poco").any { it in manufacturer } -> Platform.XIAOMI
        "samsung" in manufacturer -> Platform.SAMSUNG
        else -> Platform.GENERIC
    }

    fun fromPref(pref: String?): Platform? = when (pref) {
        "xiaomi" -> Platform.XIAOMI
        "samsung" -> Platform.SAMSUNG
        "generic" -> Platform.GENERIC
        else -> null
    }

    fun prefOf(platform: Platform?): String = when (platform) {
        Platform.XIAOMI -> "xiaomi"
        Platform.SAMSUNG -> "samsung"
        Platform.GENERIC -> "generic"
        null -> "auto"
    }

    /** Schriftzug passend zur Oberfläche; bei anderen Herstellern deren Oberflächenname. */
    fun brand(platform: Platform): Brand {
        val onDevice = detect()
        return when (platform) {
            Platform.XIAOMI ->
                // Ältere Geräte mit MIUI haben eine Build-Version, die mit „V“ beginnt (HyperOS: „OS“).
                if (onDevice == Platform.XIAOMI && Build.VERSION.INCREMENTAL.startsWith("V")) Brand("MI", "UI")
                else Brand("HYPER", "OS")
            Platform.SAMSUNG -> Brand("ONE", "UI")
            Platform.GENERIC -> when {
                onDevice != Platform.GENERIC -> Brand("ANDROID", Build.VERSION.RELEASE)
                "oneplus" in manufacturer -> Brand("OXYGEN", "OS")
                "oppo" in manufacturer -> Brand("COLOR", "OS")
                "realme" in manufacturer -> Brand("REALME", "UI")
                "nothing" in manufacturer -> Brand("NOTHING", "OS")
                "motorola" in manufacturer -> Brand("HELLO", "UI")
                else -> Brand("ANDROID", Build.VERSION.RELEASE)
            }
        }
    }
}

/** Pakete, die sich per ADB für den eigenen Benutzer entfernen lassen – bewusst kurze, unkritische Listen. */
object Debloat {
    data class Pkg(val name: String, val label: T)

    private val facebook = listOf(
        Pkg("com.facebook.appmanager", T("Facebook App Manager", "Facebook App Manager")),
        Pkg("com.facebook.services", T("Facebook Services", "Facebook Services")),
        Pkg("com.facebook.system", T("Facebook App Installer", "Facebook App Installer")),
    )

    fun list(platform: Platform): List<Pkg> = when (platform) {
        Platform.XIAOMI -> listOf(
            Pkg("com.miui.msa.global", T("msa – zentraler Werbedienst", "msa – central ad service")),
            Pkg("com.miui.analytics", T("Analytics – Telemetrie", "Analytics – telemetry")),
            Pkg("com.miui.daemon", T("MIUI Daemon – Datensammlung im Hintergrund", "MIUI Daemon – background data collection")),
            Pkg("com.miui.bugreport", T("Fehlerberichte", "Bug reports")),
            Pkg("com.miui.miservice", T("Dienste und Feedback", "Services & feedback")),
            Pkg("com.miui.hybrid", T("Quick Apps", "Quick apps")),
            Pkg("com.miui.android.fashiongallery", T("Hintergrund-Karussell", "Wallpaper carousel")),
        ) + facebook
        Platform.SAMSUNG -> listOf(
            Pkg("com.samsung.android.app.spage", T("Samsung Free / News", "Samsung Free / News")),
        ) + facebook
        Platform.GENERIC -> facebook
    }
}
