package de.hyperos.tuner

import android.provider.Settings

enum class Table { GLOBAL, SECURE }

enum class Category(val label: String) {
    ADS("Werbung"),
    PRIVACY("Datenschutz"),
    SPEED("Geschwindigkeit"),
}

/** Ein einzelner Systemwert, den die App liest und – mit Freischaltung – setzt. */
data class SettingWrite(
    val table: Table,
    val key: String,
    val value: String,
    /** Wert, von dem Android ausgeht, wenn der Schlüssel nicht gesetzt ist. */
    val androidDefault: String,
)

/** Systemwerte hinter einem Checklisten-Punkt. Ohne Freischaltung nur zur Erkennung genutzt. */
data class AutoTweak(
    val id: String,
    val title: String,
    val writes: List<SettingWrite>,
)

data class DnsPreset(val name: String, val host: String, val info: String)

/** Alle drei Dienste sind kostenlos und ohne Konto nutzbar. */
object DnsPresets {
    val list = listOf(
        DnsPreset("AdGuard DNS", "dns.adguard-dns.com", "Kostenlos, blockt Werbung und Tracker"),
        DnsPreset("Mullvad", "adblock.dns.mullvad.net", "Kostenlos, blockt Werbung und Tracker"),
        DnsPreset("Quad9", "dns.quad9.net", "Kostenlos und gemeinnützig, blockt nur Schadsoftware – keine Werbung"),
    )
}

object AutoTweaks {

    val animations = AutoTweak(
        id = "animations",
        title = "Animationen auf 0,5×",
        writes = listOf(
            SettingWrite(Table.GLOBAL, Settings.Global.WINDOW_ANIMATION_SCALE, "0.5", "1.0"),
            SettingWrite(Table.GLOBAL, Settings.Global.TRANSITION_ANIMATION_SCALE, "0.5", "1.0"),
            SettingWrite(Table.GLOBAL, Settings.Global.ANIMATOR_DURATION_SCALE, "0.5", "1.0"),
        ),
    )

    val scanning = AutoTweak(
        id = "scanning",
        title = "WLAN- und Bluetooth-Suche aus",
        writes = listOf(
            SettingWrite(Table.GLOBAL, "wifi_scan_always_enabled", "0", "1"),
            SettingWrite(Table.GLOBAL, "ble_scan_always_enabled", "0", "1"),
        ),
    )

    val lockscreen = AutoTweak(
        id = "lockscreen_notifications",
        title = "Nachrichteninhalte auf dem Sperrbildschirm verbergen",
        writes = listOf(
            SettingWrite(Table.SECURE, "lock_screen_allow_private_notifications", "0", "1"),
        ),
    )

    /** Werden mit Freischaltung über „Systemwerte automatisch setzen“ gesetzt. DNS bewusst nicht. */
    val standard: List<AutoTweak> = listOf(animations, scanning, lockscreen)

    fun privateDns(host: String) = AutoTweak(
        id = "private_dns",
        title = "Privates DNS",
        writes = listOf(
            SettingWrite(Table.GLOBAL, "private_dns_mode", "hostname", "opportunistic"),
            SettingWrite(Table.GLOBAL, "private_dns_specifier", host, ""),
        ),
    )
}
