package de.hyperos.tuner

import android.provider.Settings
import androidx.compose.ui.graphics.Color

/** GLOBAL/SECURE brauchen die Freischaltung, SYSTEM nur die Erlaubnis „Systemeinstellungen ändern“. */
enum class Table { GLOBAL, SECURE, SYSTEM }

enum class Category(val label: T, val color: Color) {
    PRIVACY(T("Datenschutz", "Privacy"), Color(0xFF2DD4BF)),
    SECURITY(T("Sicherheit", "Security"), Color(0xFFA78BFA)),
    NETWORK(T("Netzwerk", "Network"), Color(0xFF38BDF8)),
    ADS(T("Werbung", "Ads"), Color(0xFFFBBF24)),
    SPEED(T("Geschwindigkeit", "Performance"), Color(0xFFFB7185)),
}

/** Ein einzelner Systemwert, den die App liest und – mit Freischaltung – setzt. */
data class SettingWrite(
    val table: Table,
    val key: String,
    val value: String,
    /** Wert, von dem Android ausgeht, wenn der Schlüssel nicht gesetzt ist. */
    val androidDefault: String,
)

/** Systemwerte hinter einem Checklisten-Punkt. Ohne Freischaltung nur zur Erkennung genutzt. */
data class AutoTweak(
    val id: String,
    val label: T,
    val writes: List<SettingWrite>,
)

data class DnsPreset(val name: String, val host: String, val info: T)

/**
 * Nach Empfehlung sortiert (Werbefilter, Zuverlässigkeit, Datenschutz) – der erste Eintrag ist die Voreinstellung.
 * Alle Dienste sind kostenlos, ohne Konto nutzbar und unterstützen DNS-over-TLS (Androids „Privates DNS“).
 */
object DnsPresets {
    val list = listOf(
        DnsPreset(
            "AdGuard DNS", "dns.adguard-dns.com",
            T(
                "Blockt Werbung, Tracker und Schadsoftware – seit Jahren bewährt, sehr gründliche Filterlisten",
                "Blocks ads, trackers and malware – proven for years, very thorough filter lists",
            ),
        ),
        DnsPreset(
            "DNS4EU – ohne Werbung", "noads.joindns4.eu",
            T(
                "EU-Initiative mit Servern in der EU und DSGVO – blockt Werbung und Schadsoftware",
                "EU initiative with servers in the EU and GDPR – blocks ads and malware",
            ),
        ),
        DnsPreset(
            "HaGeZi DNS", "root.hagezi.org",
            T(
                "Server in Deutschland, sehr gründliche Filter – blockt Werbung, Tracker und Telemetrie. Betrieben von " +
                    "einer Privatperson, daher etwas weniger ausfallsicher",
                "Servers in Germany, very thorough filters – blocks ads, trackers and telemetry. Run by a private " +
                    "individual, so slightly less fail-safe",
            ),
        ),
        DnsPreset(
            "Control D – ohne Werbung", "p2.freedns.controld.com",
            T(
                "Blockt Werbung, Tracker und Schadsoftware, speichert laut Anbieter keine Anfragen",
                "Blocks ads, trackers and malware, does not log queries according to the provider",
            ),
        ),
        DnsPreset(
            "Quad9", "dns.quad9.net",
            T(
                "Gemeinnützig (Schweiz), stärkster Datenschutz – blockt aber nur Schadsoftware, keine Werbung",
                "Non-profit (Switzerland), strongest privacy – but blocks malware only, no ads",
            ),
        ),
    )

    /** Mullvad hat seinen öffentlichen DNS-Dienst zum 2. November 2026 eingestellt. */
    fun isDiscontinued(host: String?): Boolean =
        host != null && host.trim().lowercase().endsWith("mullvad.net")
}

object AutoTweaks {

    val animations = AutoTweak(
        id = "animations",
        label = T("Animationen auf 0,5×", "Animations at 0.5×"),
        writes = listOf(
            SettingWrite(Table.GLOBAL, Settings.Global.WINDOW_ANIMATION_SCALE, "0.5", "1.0"),
            SettingWrite(Table.GLOBAL, Settings.Global.TRANSITION_ANIMATION_SCALE, "0.5", "1.0"),
            SettingWrite(Table.GLOBAL, Settings.Global.ANIMATOR_DURATION_SCALE, "0.5", "1.0"),
        ),
    )

    val scanning = AutoTweak(
        id = "scanning",
        label = T("WLAN- und Bluetooth-Suche aus", "Wi‑Fi and Bluetooth scanning off"),
        writes = listOf(
            SettingWrite(Table.GLOBAL, "wifi_scan_always_enabled", "0", "1"),
            SettingWrite(Table.GLOBAL, "ble_scan_always_enabled", "0", "1"),
        ),
    )

    val lockscreen = AutoTweak(
        id = "lockscreen_notifications",
        label = T("Sperrbildschirm-Inhalte verbergen", "Hide lock screen content"),
        writes = listOf(
            SettingWrite(Table.SECURE, "lock_screen_allow_private_notifications", "0", "1"),
        ),
    )

    val clipboard = AutoTweak(
        id = "clipboard",
        label = T("Hinweis bei Zugriff auf die Zwischenablage", "Clipboard access notice"),
        writes = listOf(
            SettingWrite(Table.SECURE, "clipboard_show_access_notifications", "1", "1"),
        ),
    )

    /** Geht ohne Freischaltung – nur mit der Erlaubnis „Systemeinstellungen ändern“. */
    val screenTimeout = AutoTweak(
        id = "screen_timeout",
        label = T("Bildschirm sperrt nach 1 Minute", "Screen locks after 1 minute"),
        writes = listOf(
            SettingWrite(Table.SYSTEM, Settings.System.SCREEN_OFF_TIMEOUT, "60000", "60000"),
        ),
    )

    /** Getippte Zeichen nicht kurz im Klartext zeigen – ebenfalls ohne Freischaltung möglich. */
    val hidePasswords = AutoTweak(
        id = "hide_passwords",
        label = T("Passwörter beim Tippen verbergen", "Hide passwords while typing"),
        writes = listOf(
            SettingWrite(Table.SYSTEM, Settings.System.TEXT_SHOW_PASSWORD, "0", "1"),
        ),
    )

    /** Spart Akku – optional, ohne Freischaltung möglich. */
    val adaptiveBrightness = AutoTweak(
        id = "adaptive_brightness",
        label = T("Automatische Helligkeit", "Adaptive brightness"),
        writes = listOf(
            SettingWrite(
                Table.SYSTEM,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC.toString(),
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL.toString(),
            ),
        ),
    )

    /** Teil des automatischen Durchlaufs (braucht die Freischaltung). DNS nur auf Wunsch. */
    val standard: List<AutoTweak> = listOf(animations, scanning, lockscreen, clipboard)

    fun privateDns(host: String) = AutoTweak(
        id = "private_dns",
        label = T("Privates DNS ($host)", "Private DNS ($host)"),
        writes = listOf(
            SettingWrite(Table.GLOBAL, "private_dns_mode", "hostname", "opportunistic"),
            SettingWrite(Table.GLOBAL, "private_dns_specifier", host, ""),
        ),
    )
}
