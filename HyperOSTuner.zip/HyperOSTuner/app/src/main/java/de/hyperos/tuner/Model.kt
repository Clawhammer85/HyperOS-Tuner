package de.hyperos.tuner

import android.provider.Settings
import androidx.compose.ui.graphics.Color

enum class Table { GLOBAL, SECURE }

enum class Category(val label: T, val color: Color) {
    PRIVACY(T("Datenschutz", "Privacy"), Color(0xFF2DD4BF)),
    SECURITY(T("Sicherheit", "Security"), Color(0xFFA78BFA)),
    NETWORK(T("Netzwerk", "Network"), Color(0xFF38BDF8)),
    ADS(T("Werbung", "Ads"), Color(0xFFFBBF24)),
    SPEED(T("Geschwindigkeit", "Performance"), Color(0xFFFB7185)),
}

/** Ein einzelner Systemwert, den die App liest und – mit Freischaltung – setzt. */
data class SettingWrite(
    val table: Table,
    val key: String,
    val value: String,
    /** Wert, von dem Android ausgeht, wenn der Schlüssel nicht gesetzt ist. */
    val androidDefault: String,
)

/** Systemwerte hinter einem Checklisten-Punkt. Ohne Freischaltung nur zur Erkennung genutzt. */
data class AutoTweak(
    val id: String,
    val writes: List<SettingWrite>,
)

data class DnsPreset(val name: String, val host: String, val info: T)

/** Alle drei Dienste sind kostenlos und ohne Konto nutzbar. */
object DnsPresets {
    val list = listOf(
        DnsPreset(
            "AdGuard DNS", "dns.adguard-dns.com",
            T("Kostenlos, blockt Werbung und Tracker", "Free, blocks ads and trackers"),
        ),
        DnsPreset(
            "Mullvad", "adblock.dns.mullvad.net",
            T("Kostenlos, blockt Werbung und Tracker", "Free, blocks ads and trackers"),
        ),
        DnsPreset(
            "Quad9", "dns.quad9.net",
            T(
                "Kostenlos und gemeinnützig, blockt nur Schadsoftware – keine Werbung",
                "Free and non-profit, blocks malware only – no ads",
            ),
        ),
    )
}

object AutoTweaks {

    val animations = AutoTweak(
        id = "animations",
        writes = listOf(
            SettingWrite(Table.GLOBAL, Settings.Global.WINDOW_ANIMATION_SCALE, "0.5", "1.0"),
            SettingWrite(Table.GLOBAL, Settings.Global.TRANSITION_ANIMATION_SCALE, "0.5", "1.0"),
            SettingWrite(Table.GLOBAL, Settings.Global.ANIMATOR_DURATION_SCALE, "0.5", "1.0"),
        ),
    )

    val scanning = AutoTweak(
        id = "scanning",
        writes = listOf(
            SettingWrite(Table.GLOBAL, "wifi_scan_always_enabled", "0", "1"),
            SettingWrite(Table.GLOBAL, "ble_scan_always_enabled", "0", "1"),
        ),
    )

    val lockscreen = AutoTweak(
        id = "lockscreen_notifications",
        writes = listOf(
            SettingWrite(Table.SECURE, "lock_screen_allow_private_notifications", "0", "1"),
        ),
    )

    val clipboard = AutoTweak(
        id = "clipboard",
        writes = listOf(
            SettingWrite(Table.SECURE, "clipboard_show_access_notifications", "1", "1"),
        ),
    )

    /** Werden mit Freischaltung über „Systemwerte automatisch setzen“ gesetzt. DNS bewusst nicht. */
    val standard: List<AutoTweak> = listOf(animations, scanning, lockscreen, clipboard)

    fun privateDns(host: String) = AutoTweak(
        id = "private_dns",
        writes = listOf(
            SettingWrite(Table.GLOBAL, "private_dns_mode", "hostname", "opportunistic"),
            SettingWrite(Table.GLOBAL, "private_dns_specifier", host, ""),
        ),
    )
}
