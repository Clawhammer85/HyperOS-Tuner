package de.hyperos.tuner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    /** Wird bei jeder Rückkehr in die App erhöht, damit alle Erkennungen neu laufen. */
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val repo = SettingsRepo(applicationContext)
        setContent {
            TunerTheme {
                TunerApp(repo = repo, resumeTick = resumeTick.intValue)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue += 1
    }
}

// =============================================================================== Rahmen

@Composable
private fun TunerApp(repo: SettingsRepo, resumeTick: Int) {
    val ctx = LocalContext.current
    val uiPrefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var langPref by remember { mutableStateOf(uiPrefs.getString("lang", "system") ?: "system") }
    val systemLang = LocalConfiguration.current.locales[0].language
    val lang = when (langPref) {
        "de" -> Lang.DE
        "en" -> Lang.EN
        else -> if (systemLang == "de") Lang.DE else Lang.EN
    }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf(0) }
    var localTick by remember { mutableStateOf(0) }
    val tick = resumeTick + localTick
    val hasPermission = remember(tick) { repo.hasWritePermission() }
    val showMessage: (String) -> Unit = { msg ->
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }
    val header: @Composable () -> Unit = {
        AppHeader(
            langPref = langPref,
            onLangPref = { pref ->
                langPref = pref
                uiPrefs.edit().putString("lang", pref).apply()
            },
        )
    }

    CompositionLocalProvider(LocalLang provides lang) {
        GlassBackground {
            when (tab) {
                0 -> ChecklistScreen(
                    repo = repo,
                    tick = tick,
                    hasPermission = hasPermission,
                    onChanged = { localTick++ },
                    showMessage = showMessage,
                    header = header,
                )
                else -> SetupScreen(hasPermission = hasPermission, showMessage = showMessage, header = header)
            }

            // Abdeckung hinter der Statusleiste, damit gescrollter Inhalt nicht mit den Symbolen kollidiert.
            Box(
                Modifier
                    .fillMaxWidth()
                    .windowInsetsTopHeight(WindowInsets.statusBars)
                    .background(Glass.bgTop.copy(alpha = 0.92f))
            )

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                SnackbarHost(snackbar) { data ->
                    Snackbar(
                        data,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        containerColor = Color(0xF21A2436),
                        contentColor = Glass.text,
                    )
                }
                BottomNav(selected = tab, onSelect = { tab = it })
            }
        }
    }
}

@Composable
private fun AppHeader(langPref: String, onLangPref: (String) -> Unit) {
    val haptics = rememberHaptics()
    val lang = LocalLang.current
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "HYPEROS",
                style = MaterialTheme.typography.labelMedium,
                color = Glass.accent,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                "Privacy Tuner",
                style = MaterialTheme.typography.headlineMedium,
                color = Glass.text,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Box {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Glass.surface)
                    .border(1.dp, Glass.hairline, CircleShape)
                    .clickable {
                        haptics.tick()
                        menuOpen = true
                    },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (lang == Lang.DE) "DE" else "EN",
                    style = MaterialTheme.typography.labelLarge,
                    color = Glass.text,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                listOf(
                    "system" to S.langSystem.str(),
                    "de" to "Deutsch",
                    "en" to "English",
                ).forEach { (key, label) ->
                    DropdownMenuItem(
                        text = { Text(label, color = Glass.text) },
                        onClick = {
                            haptics.confirm()
                            onLangPref(key)
                            menuOpen = false
                        },
                        trailingIcon = {
                            if (langPref == key) Icon(Icons.Filled.Check, contentDescription = null, tint = Glass.accent)
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val haptics = rememberHaptics()
    val labels = listOf(S.tabChecklist.str(), S.tabPc.str())
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(Color(0xE60F1828))
            .border(1.dp, Glass.hairline, shape)
            .padding(5.dp),
    ) {
        labels.forEachIndexed { index, label ->
            val isSelected = index == selected
            val background by animateColorAsState(if (isSelected) Glass.accent else Color.Transparent, label = "tabBg")
            val foreground by animateColorAsState(if (isSelected) Glass.onAccent else Glass.textDim, label = "tabFg")
            Box(
                Modifier
                    .clip(shape)
                    .background(background)
                    .clickable {
                        if (!isSelected) {
                            haptics.tick()
                            onSelect(index)
                        }
                    }
                    .padding(horizontal = 22.dp, vertical = 12.dp),
            ) {
                Text(label, color = foreground, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// =============================================================================== Checkliste

/** Erkannt = die App liest den Wert selbst; sonst hakt man von Hand ab. */
private enum class StepState { DETECTED_DONE, DETECTED_OPEN, MANUAL }

@Composable
private fun ChecklistScreen(
    repo: SettingsRepo,
    tick: Int,
    hasPermission: Boolean,
    onChanged: () -> Unit,
    showMessage: (String) -> Unit,
    header: @Composable () -> Unit,
) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val haptics = rememberHaptics()
    val checklistPrefs = remember { ctx.getSharedPreferences("checklist", Context.MODE_PRIVATE) }
    val uiPrefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }

    var done by remember {
        mutableStateOf(checklistPrefs.getStringSet("done", emptySet())?.toSet() ?: emptySet())
    }
    var dnsHost by remember {
        mutableStateOf(
            uiPrefs.getString("dns_host", null)
                ?: repo.privateDnsState().host
                ?: DnsPresets.list.first().host
        )
    }
    var filter by rememberSaveable { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(emptySet<String>()) }

    val ramGb = remember { Device.ramGb(ctx) }
    val devEnabled = remember(tick) { repo.devOptionsEnabled() }
    val steps = remember(devEnabled) { ManualSteps.all(ramGb, devEnabled) }
    val installed = remember(tick, steps) {
        steps.associate { step ->
            step.id to (step.requiresPackage?.let { Launcher.isInstalled(ctx, it) } ?: true)
        }
    }
    val detections = remember(tick, steps) {
        steps.associate { step -> step.id to step.detector?.let { Detectors.evaluate(ctx, repo, it) } }
    }
    val dnsCurrent = remember(tick) { repo.privateDnsState() }
    val dnsTweak = remember(dnsHost) { AutoTweaks.privateDns(dnsHost) }

    fun stateOf(step: ManualStep): StepState = when (detections[step.id]?.status) {
        TweakStatus.ACTIVE -> StepState.DETECTED_DONE
        TweakStatus.INACTIVE -> StepState.DETECTED_OPEN
        TweakStatus.UNKNOWN, null -> StepState.MANUAL
    }

    fun isInstalled(step: ManualStep): Boolean = installed[step.id] == true

    fun isDone(step: ManualStep): Boolean = isInstalled(step) && when (stateOf(step)) {
        StepState.DETECTED_DONE -> true
        StepState.DETECTED_OPEN -> false
        StepState.MANUAL -> step.id in done
    }

    fun toggleDone(id: String) {
        val nowDone = id !in done
        done = if (nowDone) done + id else done - id
        checklistPrefs.edit().putStringSet("done", HashSet(done)).apply()
        if (nowDone) haptics.confirm() else haptics.tick()
    }

    fun report(success: String, failed: List<String>) {
        onChanged()
        if (failed.isEmpty()) haptics.confirm() else haptics.reject()
        showMessage(if (failed.isEmpty()) success else S.notSet(failed.joinToString()).get(lang))
    }

    val recommended = steps.filter { isInstalled(it) && !it.optional }
    val doneCount = recommended.count { isDone(it) }
    val progress = if (recommended.isEmpty()) 1f else doneCount / recommended.size.toFloat()
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = topInset + 8.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "header") { header() }

        item(key = "overview") {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(progress = progress, label = S.percent(percentOf(progress)).str())
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            S.progress(doneCount, recommended.size).str(),
                            style = MaterialTheme.typography.titleMedium,
                            color = Glass.text,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(S.progressHint.str(), style = MaterialTheme.typography.bodySmall, color = Glass.textDim)
                    }
                }
                if (hasPermission) {
                    GlassButton(
                        text = S.autoApplyAll.str(),
                        onClick = {
                            report(S.allApplied.get(lang), AutoTweaks.standard.flatMap { repo.apply(it) })
                        },
                        primary = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                    )
                }
            }
        }

        item(key = "filters") {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item(key = "all") {
                    FilterPill(
                        label = S.filterAll.str(),
                        count = "$doneCount/${recommended.size}",
                        color = Glass.accent,
                        selected = filter == null,
                        onClick = { filter = null },
                    )
                }
                items(Category.entries, key = { it.name }) { category ->
                    val inCategory = recommended.filter { it.category == category }
                    FilterPill(
                        label = category.label.str(),
                        count = "${inCategory.count { isDone(it) }}/${inCategory.size}",
                        color = category.color,
                        selected = filter == category.name,
                        onClick = { filter = category.name },
                    )
                }
            }
        }

        val categories = if (filter == null) Category.entries else Category.entries.filter { it.name == filter }
        categories.forEach { category ->
            val inCategory = steps.filter { it.category == category }
            if (inCategory.isEmpty()) return@forEach
            val categoryRecommended = inCategory.filter { isInstalled(it) && !it.optional }

            item(key = "h_${category.name}") {
                CategoryHeader(
                    category = category,
                    done = categoryRecommended.count { isDone(it) },
                    total = categoryRecommended.size,
                    modifier = Modifier.animateItem(),
                )
            }
            items(inCategory, key = { it.id }) { step ->
                val state = stateOf(step)
                val stepInstalled = isInstalled(step)
                val detector = step.detector
                val isDns = detector == Detector.PrivateDns
                val tweak: AutoTweak? = when (detector) {
                    is Detector.Values -> detector.tweak
                    Detector.PrivateDns -> dnsTweak
                    else -> null
                }
                val canRestore = remember(tick, tweak) { tweak != null && repo.hasBackup(tweak) }
                val dnsAlreadySet = dnsCurrent.status == TweakStatus.ACTIVE && dnsCurrent.host == dnsHost

                StepCard(
                    step = step,
                    installed = stepInstalled,
                    state = state,
                    checked = !stepInstalled || isDone(step),
                    detection = detections[step.id],
                    expanded = step.id in expanded,
                    onToggleExpanded = {
                        haptics.tick()
                        expanded = if (step.id in expanded) expanded - step.id else expanded + step.id
                    },
                    onToggleDone = if (stepInstalled && state == StepState.MANUAL) {
                        { toggleDone(step.id) }
                    } else {
                        null
                    },
                    onOpen = {
                        if (!Launcher.open(ctx, step.jumps)) showMessage(S.openFailed.get(lang))
                    },
                    modifier = Modifier.animateItem(),
                    extra = {
                        if (isDns) {
                            DnsPicker(
                                selected = dnsHost,
                                onSelect = { host ->
                                    dnsHost = host
                                    uiPrefs.edit().putString("dns_host", host).apply()
                                },
                            )
                            GlassButton(
                                text = S.copyHost.str(),
                                onClick = {
                                    copyToClipboard(ctx, dnsHost)
                                    showMessage(S.copiedHost(dnsHost).get(lang))
                                },
                                enabled = dnsHost.isNotBlank(),
                            )
                        }
                    },
                    actions = {
                        if (hasPermission && tweak != null && stepInstalled) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlassButton(
                                    text = S.autoSet.str(),
                                    onClick = {
                                        report(S.applied(step.title.get(lang)).get(lang), repo.apply(tweak))
                                    },
                                    enabled = if (isDns) {
                                        !dnsAlreadySet && dnsHost.isNotBlank()
                                    } else {
                                        state != StepState.DETECTED_DONE
                                    },
                                )
                                if (canRestore) {
                                    GlassButton(
                                        text = S.restore.str(),
                                        onClick = {
                                            report(S.restored(step.title.get(lang)).get(lang), repo.restore(tweak))
                                        },
                                    )
                                }
                            }
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun CategoryHeader(category: Category, done: Int, total: Int, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 6.dp, end = 6.dp, top = 14.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(category.color)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            category.label.str(),
            style = MaterialTheme.typography.titleSmall,
            color = Glass.text,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        if (total > 0) {
            Text("$done/$total", style = MaterialTheme.typography.labelMedium, color = Glass.textDim)
        }
    }
}

@Composable
private fun StepCard(
    step: ManualStep,
    installed: Boolean,
    state: StepState,
    checked: Boolean,
    detection: Detection?,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onToggleDone: (() -> Unit)?,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
    extra: @Composable ColumnScope.() -> Unit = {},
    actions: @Composable ColumnScope.() -> Unit = {},
) {
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
    val pills = buildList {
        if (!installed) {
            add(S.pillNotInstalled to Glass.textDim)
        } else {
            if (state == StepState.DETECTED_DONE) add(S.pillDetected to Glass.accent)
            if (state == StepState.DETECTED_OPEN) add(S.pillOpen to Glass.warn)
        }
        if (step.optional) add(S.pillOptional to Glass.textDim)
    }

    GlassCard(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggleExpanded)
                .padding(start = 4.dp, end = 14.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CheckDot(checked = checked, dimmed = !installed, onClick = onToggleDone)
            Column(
                Modifier
                    .weight(1f)
                    .padding(vertical = 8.dp)
            ) {
                Text(
                    step.title.str(),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = if (installed) Glass.text else Glass.textDim,
                )
                if (pills.isNotEmpty()) {
                    Row(
                        Modifier.padding(top = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        pills.forEach { (text, color) -> Pill(text.str(), color) }
                    }
                }
            }
            Icon(
                Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = Glass.textDim,
                modifier = Modifier.rotate(chevron),
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 52.dp, end = 18.dp, bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (!installed) {
                    Text(S.notInstalled.str(), style = MaterialTheme.typography.bodyMedium, color = Glass.textDim)
                } else {
                    val statusText = detection?.info?.str() ?: when (state) {
                        StepState.DETECTED_DONE -> S.detectedDone.str()
                        StepState.DETECTED_OPEN -> S.detectedOpen.str()
                        StepState.MANUAL -> null
                    }
                    if (statusText != null && state != StepState.MANUAL) {
                        Text(
                            statusText,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (state == StepState.DETECTED_DONE) Glass.accent else Glass.warn,
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(S.where.str(), style = MaterialTheme.typography.labelSmall, color = Glass.textDim)
                        Text(step.path.str(), style = MaterialTheme.typography.bodyMedium, color = Glass.text)
                    }
                    step.why?.let {
                        Text(it.str(), style = MaterialTheme.typography.bodySmall, color = Glass.textDim)
                    }
                    extra()
                    if (step.jumps.isNotEmpty()) {
                        GlassButton(text = step.openLabel.str(), onClick = onOpen, primary = true)
                    }
                    actions()
                }
            }
        }
    }
}

@Composable
private fun DnsPicker(selected: String, onSelect: (String) -> Unit) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(14.dp)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        DnsPresets.list.forEach { preset ->
            val isSelected = selected == preset.host
            val border by animateColorAsState(
                if (isSelected) Glass.accent.copy(alpha = 0.8f) else Glass.hairline,
                label = "dnsBorder",
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(if (isSelected) Glass.accent.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.03f))
                    .border(1.dp, border, shape)
                    .selectable(
                        selected = isSelected,
                        role = Role.RadioButton,
                        onClick = {
                            haptics.tick()
                            onSelect(preset.host)
                        },
                    )
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioDot(isSelected)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(preset.name, style = MaterialTheme.typography.bodyLarge, color = Glass.text)
                    Text(preset.info.str(), style = MaterialTheme.typography.bodySmall, color = Glass.textDim)
                }
            }
        }
        OutlinedTextField(
            value = selected,
            onValueChange = { onSelect(it.trim()) },
            label = { Text(S.hostname.str()) },
            singleLine = true,
            shape = shape,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Glass.text,
                unfocusedTextColor = Glass.text,
                focusedBorderColor = Glass.accent,
                unfocusedBorderColor = Glass.hairline,
                focusedLabelColor = Glass.accent,
                unfocusedLabelColor = Glass.textDim,
                cursorColor = Glass.accent,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

// =============================================================================== PC (optional)

@Composable
private fun SetupScreen(
    hasPermission: Boolean,
    showMessage: (String) -> Unit,
    header: @Composable () -> Unit,
) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val pmCommand = "pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"
    val adbCommand = "adb shell $pmCommand"
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = topInset + 8.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "header") { header() }

        item(key = "status") {
            GlassCard(
                Modifier.fillMaxWidth(),
                tint = if (hasPermission) Glass.accent.copy(alpha = 0.12f) else Glass.surface,
            ) {
                Text(
                    (if (hasPermission) S.statusGranted else S.statusNotGranted).str(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Glass.text,
                    modifier = Modifier.padding(18.dp),
                )
            }
        }

        item(key = "prep") {
            SetupCard(S.prepTitle.str()) {
                S.prepSteps.forEachIndexed { index, step -> NumberedStep(index + 1, step.str()) }
            }
        }

        item(key = "command") {
            SetupCard(S.commandTitle.str()) {
                BodyText(S.commandText.str())
                CommandBox(adbCommand)
            }
        }

        item(key = "after") {
            SetupCard(S.afterTitle.str()) {
                BodyText(S.after1.str())
                BodyText(S.after2.str())
            }
        }

        item(key = "debloat") {
            SetupCard(S.debloatTitle.str()) {
                BodyText(S.debloatText.str())
            }
        }

        item(key = "no_pc") {
            SetupCard(S.noPcTitle.str()) {
                BodyText(S.noPcText.str())
                CommandBox(pmCommand)
                GlassButton(
                    text = S.copyCommand.str(),
                    onClick = {
                        copyToClipboard(ctx, pmCommand)
                        showMessage(S.copied.get(lang))
                    },
                )
            }
        }
    }
}

@Composable
private fun SetupCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Glass.text, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun BodyText(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = Glass.textDim)
}

@Composable
private fun NumberedStep(number: Int, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Glass.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "$number",
                style = MaterialTheme.typography.labelMedium,
                color = Glass.accent,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Glass.text, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun CommandBox(command: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Glass.inset)
            .border(1.dp, Glass.hairline, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        SelectionContainer {
            Text(
                command,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = Glass.text,
            )
        }
    }
}

private fun copyToClipboard(ctx: Context, text: String) {
    val clipboard = ctx.getSystemService(ClipboardManager::class.java)
    clipboard?.setPrimaryClip(ClipData.newPlainText("HyperOS Privacy Tuner", text))
}
