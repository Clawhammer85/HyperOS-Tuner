package de.hyperos.tuner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    /** Wird bei jeder Rückkehr in die App erhöht, damit Status und Checkliste neu gelesen werden. */
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = SettingsRepo(applicationContext)
        setContent {
            TunerTheme {
                TunerApp(repo = repo, resumeTick = resumeTick.intValue)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue += 1
    }
}

@Composable
private fun TunerTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

private val TABS = listOf("Checkliste", "PC (optional)")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TunerApp(repo: SettingsRepo, resumeTick: Int) {
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf(0) }
    var localTick by remember { mutableStateOf(0) }
    val tick = resumeTick + localTick
    val hasPermission = remember(tick) { repo.hasWritePermission() }
    val showMessage: (String) -> Unit = { msg -> scope.launch { snackbar.showSnackbar(msg) } }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(title = { Text("HyperOS Tuner") })
                TabRow(selectedTabIndex = tab) {
                    TABS.forEachIndexed { index, label ->
                        Tab(selected = tab == index, onClick = { tab = index }, text = { Text(label) })
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (tab) {
                0 -> ChecklistTab(
                    repo = repo,
                    tick = tick,
                    hasPermission = hasPermission,
                    onChanged = { localTick++ },
                    showMessage = showMessage,
                )
                else -> SetupTab(hasPermission = hasPermission, showMessage = showMessage)
            }
        }
    }
}

// =============================================================================== Checkliste

/** Erkannt = die App liest den Systemwert selbst; sonst hakt man von Hand ab. */
private enum class StepState { DETECTED_DONE, DETECTED_OPEN, MANUAL }

@Composable
private fun ChecklistTab(
    repo: SettingsRepo,
    tick: Int,
    hasPermission: Boolean,
    onChanged: () -> Unit,
    showMessage: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val checklistPrefs = remember { ctx.getSharedPreferences("checklist", Context.MODE_PRIVATE) }
    val uiPrefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var done by remember {
        mutableStateOf(checklistPrefs.getStringSet("done", emptySet())?.toSet() ?: emptySet())
    }
    var dnsHost by remember {
        mutableStateOf(
            uiPrefs.getString("dns_host", null)
                ?: repo.privateDnsState().host
                ?: DnsPresets.list.first().host
        )
    }

    val ramGb = remember { Device.ramGb(ctx) }
    val devEnabled = remember(tick) { repo.devOptionsEnabled() }
    val steps = remember(devEnabled) { ManualSteps.all(ramGb, devEnabled) }
    val installed = remember(tick, steps) {
        steps.associate { step ->
            step.id to (step.requiresPackage?.let { Launcher.isInstalled(ctx, it) } ?: true)
        }
    }
    val dnsState = remember(tick) { repo.privateDnsState() }
    val dnsTweak = remember(dnsHost) { AutoTweaks.privateDns(dnsHost) }
    val states = remember(tick, steps) {
        steps.associate { step ->
            val status = when {
                step.id == ManualSteps.PRIVATE_DNS_ID -> dnsState.status
                step.tweak != null -> repo.status(step.tweak)
                else -> null
            }
            step.id to when (status) {
                TweakStatus.ACTIVE -> StepState.DETECTED_DONE
                TweakStatus.INACTIVE -> StepState.DETECTED_OPEN
                TweakStatus.UNKNOWN, null -> StepState.MANUAL
            }
        }
    }

    fun isDone(step: ManualStep): Boolean {
        if (installed[step.id] != true) return false
        return when (states[step.id]) {
            StepState.DETECTED_DONE -> true
            StepState.DETECTED_OPEN -> false
            StepState.MANUAL, null -> step.id in done
        }
    }

    fun setDone(id: String, value: Boolean) {
        done = if (value) done + id else done - id
        checklistPrefs.edit().putStringSet("done", HashSet(done)).apply()
    }

    fun report(success: String, failed: List<String>) {
        onChanged()
        showMessage(if (failed.isEmpty()) success else "Nicht gesetzt: ${failed.joinToString()}")
    }

    val relevant = steps.filter { installed[it.id] == true }
    val doneCount = relevant.count { isDone(it) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "progress") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("$doneCount von ${relevant.size} erledigt", style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(
                    progress = { if (relevant.isEmpty()) 1f else doneCount / relevant.size.toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Der Knopf an jedem Punkt springt so nah wie möglich an die richtige Stelle. Systemwerte " +
                        "erkennt die App selbst, sobald du zurückkommst – alles andere hakst du ab. Menünamen " +
                        "können je nach HyperOS-Version leicht abweichen.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (hasPermission) {
                    Button(
                        onClick = {
                            report(
                                "Systemwerte automatisch gesetzt",
                                AutoTweaks.standard.flatMap { repo.apply(it) },
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Systemwerte automatisch setzen") }
                }
            }
        }

        Category.entries.forEach { category ->
            val inCategory = steps.filter { it.category == category }
            if (inCategory.isNotEmpty()) {
                item(key = "header_${category.name}") {
                    Text(
                        category.label,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                items(inCategory, key = { it.id }) { step ->
                    val isDns = step.id == ManualSteps.PRIVATE_DNS_ID
                    val tweak = if (isDns) dnsTweak else step.tweak
                    val state = states[step.id] ?: StepState.MANUAL
                    val canRestore = remember(tick, tweak) { tweak != null && repo.hasBackup(tweak) }
                    val dnsAlreadySet = isDns && dnsState.status == TweakStatus.ACTIVE && dnsState.host == dnsHost

                    StepCard(
                        step = step,
                        installed = installed[step.id] == true,
                        state = state,
                        manuallyDone = step.id in done,
                        detectedText = detectedText(state, if (isDns) dnsState.host else null),
                        onManualDoneChange = { setDone(step.id, it) },
                        onOpen = {
                            if (!Launcher.open(ctx, step.jumps)) {
                                showMessage("Konnte nichts öffnen – bitte über den angegebenen Pfad gehen.")
                            }
                        },
                        extra = {
                            if (isDns) {
                                DnsPicker(
                                    selected = dnsHost,
                                    onSelect = { host ->
                                        dnsHost = host
                                        uiPrefs.edit().putString("dns_host", host).apply()
                                    },
                                )
                                OutlinedButton(
                                    onClick = {
                                        copyToClipboard(ctx, dnsHost)
                                        showMessage("Hostname kopiert: $dnsHost")
                                    },
                                    enabled = dnsHost.isNotBlank(),
                                ) { Text("Hostname kopieren") }
                            }
                        },
                        actions = {
                            if (hasPermission && tweak != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { report("„${step.title}“ gesetzt", repo.apply(tweak)) },
                                        enabled = if (isDns) {
                                            !dnsAlreadySet && dnsHost.isNotBlank()
                                        } else {
                                            state != StepState.DETECTED_DONE
                                        },
                                    ) { Text("Automatisch setzen") }
                                    if (canRestore) {
                                        TextButton(
                                            onClick = { report("„${step.title}“ zurückgesetzt", repo.restore(tweak)) },
                                        ) { Text("Zurücksetzen") }
                                    }
                                }
                            }
                        },
                    )
                }
            }
        }
    }
}

private fun detectedText(state: StepState, dnsHost: String?): String? = when (state) {
    StepState.DETECTED_DONE -> if (dnsHost != null) "Eingestellt: $dnsHost" else "Eingestellt – von der App erkannt"
    StepState.DETECTED_OPEN -> "Noch nicht eingestellt. Die App prüft das erneut, sobald du zurückkommst."
    StepState.MANUAL -> null
}

@Composable
private fun StepCard(
    step: ManualStep,
    installed: Boolean,
    state: StepState,
    manuallyDone: Boolean,
    detectedText: String?,
    onManualDoneChange: (Boolean) -> Unit,
    onOpen: () -> Unit,
    extra: @Composable ColumnScope.() -> Unit = {},
    actions: @Composable ColumnScope.() -> Unit = {},
) {
    val checked = when {
        !installed -> true
        state == StepState.DETECTED_DONE -> true
        state == StepState.DETECTED_OPEN -> false
        else -> manuallyDone
    }
    val manual = installed && state == StepState.MANUAL

    OutlinedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(top = 4.dp, bottom = 12.dp, end = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = checked,
                    onCheckedChange = if (manual) onManualDoneChange else null,
                    enabled = installed,
                )
                Text(step.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            }
            Column(Modifier.padding(start = 48.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!installed) {
                    Text(
                        "App ist nicht installiert – hier gibt es nichts zu tun.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    if (detectedText != null) {
                        Text(
                            detectedText,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (state == StepState.DETECTED_DONE) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                        )
                    }
                    Text(step.path, style = MaterialTheme.typography.bodyMedium)
                    if (step.why.isNotBlank()) {
                        Text(
                            step.why,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    extra()
                    if (step.jumps.isNotEmpty()) {
                        FilledTonalButton(onClick = onOpen) { Text(step.openLabel) }
                    }
                    actions()
                }
            }
        }
    }
}

@Composable
private fun DnsPicker(selected: String, onSelect: (String) -> Unit) {
    Column {
        DnsPresets.list.forEach { preset ->
            val isSelected = selected == preset.host
            Row(
                Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = isSelected,
                        role = Role.RadioButton,
                        onClick = { onSelect(preset.host) },
                    )
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = isSelected, onClick = null)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(preset.name, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        preset.info,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        OutlinedTextField(
            value = selected,
            onValueChange = { onSelect(it.trim()) },
            label = { Text("Hostname") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

// =============================================================================== Einrichtung

@Composable
private fun SetupTab(hasPermission: Boolean, showMessage: (String) -> Unit) {
    val ctx = LocalContext.current
    val pmCommand = "pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"
    val adbCommand = "adb shell $pmCommand"
    val prepSteps = listOf(
        "Einstellungen › Über das Telefon: siebenmal auf „OS-Version“ tippen, bis die " +
            "Entwickleroptionen freigeschaltet sind.",
        "Einstellungen › Weitere Einstellungen › Entwickleroptionen: „USB-Debugging“ einschalten.",
        "Darunter „USB-Debugging (Sicherheitseinstellungen)“ einschalten. Dafür muss ein Xiaomi-Konto " +
            "angemeldet sein – ohne diesen Schalter lehnt HyperOS die Freischaltung ab.",
        "Damit das Skript die App gleich mit installiert: zusätzlich „Über USB installieren“ einschalten.",
        "Handy per USB mit dem PC verbinden und „USB-Debugging zulassen?“ bestätigen.",
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "status") {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (hasPermission) {
                        MaterialTheme.colorScheme.secondaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    },
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    if (hasPermission) {
                        "Freischaltung aktiv. In der Checkliste setzt die App die Systemwerte jetzt auf Knopfdruck " +
                            "selbst. Hier musst du nur noch etwas tun, wenn du per PC Apps entfernen willst."
                    } else {
                        "Nicht nötig – die Checkliste funktioniert komplett ohne. Eine einmalige Freischaltung am " +
                            "PC spart nur Handgriffe: Die App setzt dann Animationen, WLAN-/Bluetooth-Suche, " +
                            "Sperrbildschirm und Privates DNS selbst und kann sie zurücksetzen."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(16.dp),
                )
            }
        }

        item(key = "prep_title") {
            Text("Freischaltung: am Handy vorbereiten", style = MaterialTheme.typography.titleMedium)
        }
        prepSteps.forEachIndexed { index, text ->
            item(key = "prep_$index") { NumberedStep(index + 1, text) }
        }

        item(key = "command") {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Am PC freischalten (optional)", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Im Projektordner hyperos-setup.bat starten und Punkt 1 wählen. Das Skript " +
                            "installiert die App bei Bedarf und prüft, ob die Freischaltung geklappt hat. " +
                            "Von Hand geht es mit diesem Befehl:",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    CommandBox(adbCommand)
                }
            }
        }

        item(key = "afterwards") {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Danach", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "USB-Debugging darfst du wieder ausschalten, die Berechtigung bleibt. Die " +
                            "Entwickleroptionen selbst bitte eingeschaltet lassen – beim Abschalten setzt " +
                            "Android die Animationswerte zurück.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Der Scan der Sicherheits-App schaltet die Entwickleroptionen manchmal ab, und große " +
                            "HyperOS-Updates setzen einzelne Werte zurück. Die Checkliste zeigt den Punkt dann " +
                            "wieder als offen an.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }

        item(key = "debloat") {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Werbe- und Tracking-Dienste entfernen", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Dienste wie msa, Analytics oder das Hintergrund-Karussell lassen sich nur per ADB " +
                            "entfernen – eine App kann das ohne Root nicht. hyperos-setup.bat erledigt das " +
                            "unter Punkt 2 und 3. Entfernt wird nur für deinen Benutzer: Über Punkt 4 oder " +
                            "einen Werksreset ist alles wieder da.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }

        item(key = "no_pc") {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Ohne PC", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Über „Kabelloses Debugging“ geht es auch direkt am Handy: Shizuku einrichten und " +
                            "den Befehl unten in einem Shizuku-Terminal wie aShell ausführen. Die Schalter " +
                            "aus Schritt 1 bis 3 braucht es trotzdem. Zum Entfernen von Apps ohne PC eignet " +
                            "sich Canta, das ebenfalls über Shizuku läuft.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    CommandBox(pmCommand)
                    FilledTonalButton(onClick = {
                        copyToClipboard(ctx, pmCommand)
                        showMessage("Befehl kopiert")
                    }) { Text("Befehl kopieren") }
                }
            }
        }
    }
}

@Composable
private fun NumberedStep(number: Int, text: String) {
    Row {
        Text(
            "$number.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.width(28.dp),
        )
        Text(text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun CommandBox(command: String) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.small,
        modifier = Modifier.fillMaxWidth(),
    ) {
        SelectionContainer {
            Text(
                command,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(12.dp),
            )
        }
    }
}

private fun copyToClipboard(ctx: Context, text: String) {
    val clipboard = ctx.getSystemService(ClipboardManager::class.java)
    clipboard?.setPrimaryClip(ClipData.newPlainText("Befehl", text))
}
