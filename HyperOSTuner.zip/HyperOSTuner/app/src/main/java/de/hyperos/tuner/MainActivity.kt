package de.hyperos.tuner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    /** Wird bei jeder Rückkehr in die App erhöht, damit alle Erkennungen neu laufen. */
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val repo = SettingsRepo(applicationContext)
        setContent {
            TunerApp(repo = repo, resumeTick = resumeTick.intValue)
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue += 1
    }
}

// =============================================================================== Rahmen

@Composable
private fun TunerApp(repo: SettingsRepo, resumeTick: Int) {
    val ctx = LocalContext.current
    val uiPrefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    fun save(key: String, value: String) = uiPrefs.edit().putString(key, value).apply()

    var langPref by remember { mutableStateOf(uiPrefs.getString("lang", "system") ?: "system") }
    var paletteId by remember { mutableStateOf(uiPrefs.getString("palette", null) ?: Palettes.all.first().id) }
    var platformPref by remember { mutableStateOf(uiPrefs.getString("platform", "auto") ?: "auto") }
    var onboardingDone by remember { mutableStateOf(uiPrefs.getBoolean("onboarding_done", false)) }

    val detected = remember { Platforms.detect() }
    val platform = Platforms.fromPref(platformPref) ?: detected
    val systemLang = LocalConfiguration.current.locales[0].language
    val lang = when (langPref) {
        "de" -> Lang.DE
        "en" -> Lang.EN
        else -> if (systemLang == "de") Lang.DE else Lang.EN
    }
    val palette = Palettes.byId(paletteId)

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableStateOf(0) }
    var localTick by remember { mutableStateOf(0) }
    val tick = resumeTick + localTick
    val hasPermission = remember(tick) { repo.hasWritePermission() }
    val showMessage: (String) -> Unit = { msg ->
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }
    val header: @Composable () -> Unit = {
        AppHeader(
            platform = platform,
            detected = detected,
            platformPref = platformPref,
            onPlatformPref = { pref ->
                platformPref = pref
                save("platform", pref)
            },
            langPref = langPref,
            onLangPref = { pref ->
                langPref = pref
                save("lang", pref)
            },
            paletteId = paletteId,
            onPalette = { id ->
                paletteId = id
                save("palette", id)
            },
        )
    }

    TunerTheme(palette) {
        CompositionLocalProvider(LocalLang provides lang) {
            GlassBackground {
                if (!onboardingDone) {
                    Onboarding(
                        platform = platform,
                        onFinish = {
                            onboardingDone = true
                            uiPrefs.edit().putBoolean("onboarding_done", true).apply()
                        },
                    )
                } else {
                    when (tab) {
                        0 -> ChecklistScreen(
                            repo = repo,
                            platform = platform,
                            tick = tick,
                            hasPermission = hasPermission,
                            onChanged = { localTick++ },
                            showMessage = showMessage,
                            onReplayIntro = {
                                onboardingDone = false
                                uiPrefs.edit().putBoolean("onboarding_done", false).apply()
                            },
                            header = header,
                        )
                        else -> SetupScreen(
                            platform = platform,
                            tick = tick,
                            hasPermission = hasPermission,
                            showMessage = showMessage,
                            header = header,
                        )
                    }

                    // Abdeckung hinter der Statusleiste, damit gescrollter Inhalt nicht mit den Symbolen kollidiert.
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .windowInsetsTopHeight(WindowInsets.statusBars)
                            .background(Glass.bgTop.copy(alpha = 0.92f))
                    )

                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .padding(bottom = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        SnackbarHost(snackbar) { data ->
                            Snackbar(
                                data,
                                modifier = Modifier.padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(16.dp),
                                containerColor = Color(0xF21A2436),
                                contentColor = Glass.text,
                            )
                        }
                        BottomNav(selected = tab, onSelect = { tab = it })
                    }
                }
            }
        }
    }
}

// =============================================================================== Kopfzeile

@Composable
private fun BrandLogo(brand: Brand) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            brand.left,
            style = MaterialTheme.typography.labelLarge,
            color = Glass.accent,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Bolt()
        Text(
            brand.right,
            style = MaterialTheme.typography.labelLarge,
            color = Glass.accent,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun AppHeader(
    platform: Platform,
    detected: Platform,
    platformPref: String,
    onPlatformPref: (String) -> Unit,
    langPref: String,
    onLangPref: (String) -> Unit,
    paletteId: String,
    onPalette: (String) -> Unit,
) {
    val haptics = rememberHaptics()
    val lang = LocalLang.current
    val palette = LocalPalette.current
    var deviceMenuOpen by remember { mutableStateOf(false) }
    var themeMenuOpen by remember { mutableStateOf(false) }
    var langMenuOpen by remember { mutableStateOf(false) }
    val deviceLabel = S.device.str()
    val themeLabel = S.theme.str()
    val languageLabel = S.language.str()

    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            // Schriftzug je Hersteller – antippen, um die Oberfläche zu wechseln.
            Box {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClickLabel = deviceLabel) {
                            haptics.tick()
                            deviceMenuOpen = true
                        }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    BrandLogo(Platforms.brand(platform))
                    Icon(
                        Icons.Filled.ArrowDropDown,
                        contentDescription = null,
                        tint = Glass.textDim,
                        modifier = Modifier.size(18.dp),
                    )
                }
                DropdownMenu(expanded = deviceMenuOpen, onDismissRequest = { deviceMenuOpen = false }) {
                    val options = listOf("auto" to S.platformAuto(detected).str()) +
                        Platform.entries.map { Platforms.prefOf(it) to it.label.str() }
                    options.forEach { (key, label) ->
                        DropdownMenuItem(
                            text = { Text(label, color = Glass.text) },
                            onClick = {
                                haptics.confirm()
                                onPlatformPref(key)
                                deviceMenuOpen = false
                            },
                            trailingIcon = {
                                if (platformPref == key) {
                                    Icon(Icons.Filled.Check, contentDescription = null, tint = Glass.accent)
                                }
                            },
                        )
                    }
                }
            }
            Text(
                "Privacy Tuner",
                style = MaterialTheme.typography.headlineMedium,
                color = Glass.text,
                fontWeight = FontWeight.SemiBold,
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Farbdesign
            Box {
                HeaderButton(
                    onClickLabel = themeLabel,
                    onClick = {
                        haptics.tick()
                        themeMenuOpen = true
                    },
                ) {
                    Swatch(palette, size = 20)
                }
                DropdownMenu(expanded = themeMenuOpen, onDismissRequest = { themeMenuOpen = false }) {
                    Palettes.all.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.name.str(), color = Glass.text) },
                            onClick = {
                                haptics.confirm()
                                onPalette(option.id)
                                themeMenuOpen = false
                            },
                            leadingIcon = { Swatch(option) },
                            trailingIcon = {
                                if (option.id == paletteId) {
                                    Icon(Icons.Filled.Check, contentDescription = null, tint = Glass.accent)
                                }
                            },
                        )
                    }
                }
            }

            // Sprache
            Box {
                HeaderButton(
                    onClickLabel = languageLabel,
                    onClick = {
                        haptics.tick()
                        langMenuOpen = true
                    },
                ) {
                    Text(
                        if (lang == Lang.DE) "DE" else "EN",
                        style = MaterialTheme.typography.labelLarge,
                        color = Glass.text,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                DropdownMenu(expanded = langMenuOpen, onDismissRequest = { langMenuOpen = false }) {
                    listOf(
                        "system" to S.langSystem.str(),
                        "de" to "Deutsch",
                        "en" to "English",
                    ).forEach { (key, label) ->
                        DropdownMenuItem(
                            text = { Text(label, color = Glass.text) },
                            onClick = {
                                haptics.confirm()
                                onLangPref(key)
                                langMenuOpen = false
                            },
                            trailingIcon = {
                                if (langPref == key) {
                                    Icon(Icons.Filled.Check, contentDescription = null, tint = Glass.accent)
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

// =============================================================================== Einführung

@Composable
private fun Onboarding(platform: Platform, onFinish: () -> Unit) {
    val haptics = rememberHaptics()
    var page by rememberSaveable { mutableStateOf(0) }
    val lastPage = 2

    Column(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 24.dp, vertical = 16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            if (page < lastPage) {
                Text(
                    S.obSkip.str(),
                    style = MaterialTheme.typography.labelLarge,
                    color = Glass.textDim,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable {
                            haptics.tick()
                            onFinish()
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                )
            } else {
                Spacer(Modifier.height(40.dp))
            }
        }

        Spacer(Modifier.weight(1f))

        AnimatedContent(targetState = page, label = "onboarding") { current ->
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    when (current) {
                        0 -> {
                            BrandLogo(Platforms.brand(platform))
                            OnboardingTitle(S.ob1Title.str())
                            OnboardingText(S.ob1Text.str())
                        }
                        1 -> {
                            OnboardingTitle(S.ob2Title.str())
                            S.ob2Steps.forEachIndexed { index, step -> NumberedStep(index + 1, step.str()) }
                        }
                        else -> {
                            OnboardingTitle(S.ob3Title.str())
                            OnboardingText(S.ob3Text.str())
                            Pill(S.obDetected(platform).str(), Glass.accent)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        Row(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            repeat(lastPage + 1) { index ->
                val color by animateColorAsState(
                    if (index == page) Glass.accent else Color.White.copy(alpha = 0.2f),
                    label = "dot",
                )
                Box(
                    Modifier
                        .size(if (index == page) 10.dp else 8.dp)
                        .clip(CircleShape)
                        .background(color)
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (page > 0) {
                GlassButton(text = S.obBack.str(), onClick = { page-- })
            }
            GlassButton(
                text = if (page < lastPage) S.obNext.str() else S.obStart.str(),
                onClick = {
                    if (page < lastPage) {
                        page++
                    } else {
                        haptics.confirm()
                        onFinish()
                    }
                },
                primary = true,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun OnboardingTitle(text: String) {
    Text(text, style = MaterialTheme.typography.headlineSmall, color = Glass.text, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun OnboardingText(text: String) {
    Text(text, style = MaterialTheme.typography.bodyLarge, color = Glass.textDim)
}

// =============================================================================== Checkliste

/** Erkannt = die App liest den Wert selbst; sonst hakt man von Hand ab. */
private enum class StepState { DETECTED_DONE, DETECTED_OPEN, MANUAL }

private enum class ViewMode { ESSENTIALS, ALL }

@Composable
private fun ChecklistScreen(
    repo: SettingsRepo,
    platform: Platform,
    tick: Int,
    hasPermission: Boolean,
    onChanged: () -> Unit,
    showMessage: (String) -> Unit,
    onReplayIntro: () -> Unit,
    header: @Composable () -> Unit,
) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val haptics = rememberHaptics()
    val checklistPrefs = remember { ctx.getSharedPreferences("checklist", Context.MODE_PRIVATE) }
    val uiPrefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }

    var done by remember {
        mutableStateOf(checklistPrefs.getStringSet("done", emptySet())?.toSet() ?: emptySet())
    }
    var dnsHost by remember {
        mutableStateOf(
            uiPrefs.getString("dns_host", null)
                ?: repo.privateDnsState().host
                ?: DnsPresets.list.first().host
        )
    }
    var mode by remember {
        mutableStateOf(if (uiPrefs.getString("mode", "essentials") == "all") ViewMode.ALL else ViewMode.ESSENTIALS)
    }
    var filter by rememberSaveable { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(emptySet<String>()) }
    var skipped by remember { mutableStateOf(emptySet<String>()) }

    val ramGb = remember { Device.ramGb(ctx) }
    val devEnabled = remember(tick) { repo.devOptionsEnabled() }
    val steps = remember(devEnabled, platform) { ManualSteps.all(ramGb, devEnabled, platform) }
    val installed = remember(tick, steps) {
        steps.associate { step ->
            step.id to (step.requiresPackage?.let { Launcher.isInstalled(ctx, it) } ?: true)
        }
    }
    val detections = remember(tick, steps) {
        steps.associate { step -> step.id to step.detector?.let { Detectors.evaluate(ctx, repo, it) } }
    }
    val dnsCurrent = remember(tick) { repo.privateDnsState() }
    val dnsTweak = remember(dnsHost) { AutoTweaks.privateDns(dnsHost) }

    fun stateOf(step: ManualStep): StepState = when (detections[step.id]?.status) {
        TweakStatus.ACTIVE -> StepState.DETECTED_DONE
        TweakStatus.INACTIVE -> StepState.DETECTED_OPEN
        TweakStatus.UNKNOWN, null -> StepState.MANUAL
    }

    fun isInstalled(step: ManualStep): Boolean = installed[step.id] == true

    fun isDone(step: ManualStep): Boolean = isInstalled(step) && when (stateOf(step)) {
        StepState.DETECTED_DONE -> true
        StepState.DETECTED_OPEN -> false
        StepState.MANUAL -> step.id in done
    }

    fun toggleDone(id: String) {
        val nowDone = id !in done
        done = if (nowDone) done + id else done - id
        checklistPrefs.edit().putStringSet("done", HashSet(done)).apply()
        if (nowDone) haptics.confirm() else haptics.tick()
    }

    fun report(success: String, failed: List<String>) {
        onChanged()
        if (failed.isEmpty()) haptics.confirm() else haptics.reject()
        showMessage(if (failed.isEmpty()) success else S.notSet(failed.joinToString()).get(lang))
    }

    fun setMode(newMode: ViewMode) {
        mode = newMode
        uiPrefs.edit().putString("mode", if (newMode == ViewMode.ALL) "all" else "essentials").apply()
    }

    val recommended = steps.filter { isInstalled(it) && !it.optional }
    val essentials = recommended
        .filter { it.essential }
        .sortedBy { ManualSteps.ESSENTIAL_ORDER.indexOf(it.id) }
    val scope = if (mode == ViewMode.ESSENTIALS) essentials else recommended
    val doneCount = scope.count { isDone(it) }
    val progress = if (scope.isEmpty()) 1f else doneCount / scope.size.toFloat()
    val nextStep = scope.firstOrNull { !isDone(it) && it.id !in skipped }
    val hasSkipped = scope.any { !isDone(it) && it.id in skipped }
    val activeCategories = Category.entries.filter { c -> steps.any { it.category == c } }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    @Composable
    fun Card(step: ManualStep, showCategory: Boolean, modifier: Modifier) {
        val state = stateOf(step)
        val stepInstalled = isInstalled(step)
        val detector = step.detector
        val isDns = detector == Detector.PrivateDns
        val tweak: AutoTweak? = when (detector) {
            is Detector.Values -> detector.tweak
            Detector.PrivateDns -> dnsTweak
            else -> null
        }
        val canRestore = remember(tick, tweak) { tweak != null && repo.hasBackup(tweak) }
        val dnsAlreadySet = dnsCurrent.status == TweakStatus.ACTIVE && dnsCurrent.host == dnsHost

        StepCard(
            step = step,
            installed = stepInstalled,
            state = state,
            checked = !stepInstalled || isDone(step),
            detection = detections[step.id],
            expanded = step.id in expanded,
            onToggleExpanded = {
                haptics.tick()
                expanded = if (step.id in expanded) expanded - step.id else expanded + step.id
            },
            onToggleDone = if (stepInstalled && state == StepState.MANUAL) {
                { toggleDone(step.id) }
            } else {
                null
            },
            onOpen = {
                if (!Launcher.open(ctx, step.jumps)) showMessage(S.openFailed.get(lang))
            },
            modifier = modifier,
            showCategory = showCategory,
            extra = {
                if (isDns) {
                    DnsPicker(
                        selected = dnsHost,
                        onSelect = { host ->
                            dnsHost = host
                            uiPrefs.edit().putString("dns_host", host).apply()
                        },
                    )
                    GlassButton(
                        text = S.copyHost.str(),
                        onClick = {
                            copyToClipboard(ctx, dnsHost)
                            showMessage(S.copiedHost(dnsHost).get(lang))
                        },
                        enabled = dnsHost.isNotBlank(),
                    )
                }
            },
            actions = {
                if (hasPermission && tweak != null && stepInstalled) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton(
                            text = S.autoSet.str(),
                            onClick = {
                                report(S.applied(step.title.get(lang)).get(lang), repo.apply(tweak))
                            },
                            enabled = if (isDns) {
                                !dnsAlreadySet && dnsHost.isNotBlank()
                            } else {
                                state != StepState.DETECTED_DONE
                            },
                        )
                        if (canRestore) {
                            GlassButton(
                                text = S.restore.str(),
                                onClick = {
                                    report(S.restored(step.title.get(lang)).get(lang), repo.restore(tweak))
                                },
                            )
                        }
                    }
                }
            },
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = topInset + 8.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "header") { header() }

        item(key = "overview") {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(progress = progress, label = S.percent(percentOf(progress)).str())
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            S.progress(doneCount, scope.size).str(),
                            style = MaterialTheme.typography.titleMedium,
                            color = Glass.text,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(S.progressHint.str(), style = MaterialTheme.typography.bodySmall, color = Glass.textDim)
                    }
                }
                if (hasPermission) {
                    GlassButton(
                        text = S.autoApplyAll.str(),
                        onClick = {
                            report(S.allApplied.get(lang), AutoTweaks.standard.flatMap { repo.apply(it) })
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                    )
                }
            }
        }

        item(key = "mode") {
            ModeToggle(
                mode = mode,
                essentialsLabel = "${S.modeEssentials.str()}  ${essentials.count { isDone(it) }}/${essentials.size}",
                allLabel = "${S.modeAll.str()}  ${recommended.count { isDone(it) }}/${recommended.size}",
                onSelect = { setMode(it) },
            )
        }

        item(key = "next") {
            NextStepCard(
                step = nextStep,
                state = nextStep?.let { stateOf(it) },
                hasSkipped = hasSkipped,
                mode = mode,
                onOpen = {
                    val step = nextStep ?: return@NextStepCard
                    if (!Launcher.open(ctx, step.jumps)) showMessage(S.openFailed.get(lang))
                },
                onDone = { nextStep?.let { toggleDone(it.id) } },
                onSkip = {
                    haptics.tick()
                    nextStep?.let { skipped = skipped + it.id }
                },
                onShowSkipped = {
                    haptics.tick()
                    skipped = emptySet()
                },
                onShowAll = {
                    haptics.tick()
                    setMode(ViewMode.ALL)
                },
                modifier = Modifier.animateItem(),
            )
        }

        if (mode == ViewMode.ESSENTIALS) {
            item(key = "essentials_title") {
                Text(
                    S.listEssentials.str(),
                    style = MaterialTheme.typography.titleSmall,
                    color = Glass.text,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .padding(start = 6.dp, top = 14.dp, bottom = 2.dp)
                        .animateItem(),
                )
            }
            items(essentials, key = { it.id }) { step ->
                Card(step, showCategory = true, modifier = Modifier.animateItem())
            }
        } else {
            item(key = "filters") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item(key = "all") {
                        FilterPill(
                            label = S.filterAll.str(),
                            count = "${recommended.count { isDone(it) }}/${recommended.size}",
                            color = Glass.accent,
                            selected = filter == null,
                            onClick = { filter = null },
                        )
                    }
                    items(activeCategories, key = { it.name }) { category ->
                        val inCategory = recommended.filter { it.category == category }
                        FilterPill(
                            label = category.label.str(),
                            count = "${inCategory.count { isDone(it) }}/${inCategory.size}",
                            color = category.color,
                            selected = filter == category.name,
                            onClick = { filter = category.name },
                        )
                    }
                }
            }

            val shown = activeCategories.filter { filter == null || it.name == filter }.ifEmpty { activeCategories }
            shown.forEach { category ->
                val inCategory = steps.filter { it.category == category }
                val categoryRecommended = inCategory.filter { isInstalled(it) && !it.optional }
                item(key = "h_${category.name}") {
                    CategoryHeader(
                        category = category,
                        done = categoryRecommended.count { isDone(it) },
                        total = categoryRecommended.size,
                        modifier = Modifier.animateItem(),
                    )
                }
                items(inCategory, key = { it.id }) { step ->
                    Card(step, showCategory = false, modifier = Modifier.animateItem())
                }
            }
        }

        item(key = "help") {
            GlassCard(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        S.helpTitle.str(),
                        style = MaterialTheme.typography.titleSmall,
                        color = Glass.text,
                        fontWeight = FontWeight.SemiBold,
                    )
                    BodyText(S.helpText.str())
                    GlassButton(text = S.replayIntro.str(), onClick = onReplayIntro)
                }
            }
        }
    }
}

@Composable
private fun ModeToggle(mode: ViewMode, essentialsLabel: String, allLabel: String, onSelect: (ViewMode) -> Unit) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Glass.surface)
            .border(1.dp, Glass.hairline, shape)
            .padding(4.dp),
    ) {
        listOf(ViewMode.ESSENTIALS to essentialsLabel, ViewMode.ALL to allLabel).forEach { (option, label) ->
            val selected = option == mode
            val background by animateColorAsState(if (selected) Glass.accent else Color.Transparent, label = "modeBg")
            val foreground by animateColorAsState(if (selected) Glass.onAccent else Glass.textDim, label = "modeFg")
            Box(
                Modifier
                    .weight(1f)
                    .clip(shape)
                    .background(background)
                    .clickable {
                        if (!selected) {
                            haptics.tick()
                            onSelect(option)
                        }
                    }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = foreground, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private data class NextView(
    val step: ManualStep?,
    val state: StepState?,
    val hasSkipped: Boolean,
    val mode: ViewMode,
)

/** Führt Schritt für Schritt durch die offenen Punkte – der Einstieg für alle, die nicht selbst suchen wollen. */
@Composable
private fun NextStepCard(
    step: ManualStep?,
    state: StepState?,
    hasSkipped: Boolean,
    mode: ViewMode,
    onOpen: () -> Unit,
    onDone: () -> Unit,
    onSkip: () -> Unit,
    onShowSkipped: () -> Unit,
    onShowAll: () -> Unit,
    modifier: Modifier = Modifier,
) {
    GlassCard(modifier.fillMaxWidth(), tint = Glass.accent.copy(alpha = 0.10f)) {
        AnimatedContent(
            targetState = NextView(step, state, hasSkipped, mode),
            contentKey = { it.step?.id ?: "empty-${it.hasSkipped}-${it.mode}" },
            label = "nextStep",
        ) { view ->
            val step = view.step
            val state = view.state
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when {
                    step != null -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                S.nextTitle.str(),
                                style = MaterialTheme.typography.labelMedium,
                                color = Glass.accent,
                                letterSpacing = 1.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f),
                            )
                            Pill(step.category.label.str(), step.category.color)
                        }
                        Text(
                            step.title.str(),
                            style = MaterialTheme.typography.titleLarge,
                            color = Glass.text,
                            fontWeight = FontWeight.SemiBold,
                        )
                        step.why?.let { BodyText(it.str()) }
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(S.howTo.str(), style = MaterialTheme.typography.labelSmall, color = Glass.textDim)
                            Text(step.path.str(), style = MaterialTheme.typography.bodyMedium, color = Glass.text)
                        }
                        if (step.jumps.isNotEmpty()) {
                            GlassButton(
                                text = S.nextDo.str(),
                                onClick = onOpen,
                                primary = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        if (state != StepState.MANUAL) {
                            Text(S.nextAuto.str(), style = MaterialTheme.typography.bodySmall, color = Glass.textDim)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (state == StepState.MANUAL) {
                                GlassButton(text = S.nextDone.str(), onClick = onDone)
                            }
                            GlassButton(text = S.nextSkip.str(), onClick = onSkip)
                        }
                    }
                    view.hasSkipped -> {
                        BodyText(S.skippedText.str())
                        GlassButton(text = S.skippedShow.str(), onClick = onShowSkipped, primary = true)
                    }
                    view.mode == ViewMode.ESSENTIALS -> {
                        Text(
                            S.essentialsDone.str(),
                            style = MaterialTheme.typography.titleMedium,
                            color = Glass.text,
                            fontWeight = FontWeight.SemiBold,
                        )
                        BodyText(S.essentialsDoneHint.str())
                        GlassButton(text = S.showAll.str(), onClick = onShowAll, primary = true)
                    }
                    else -> {
                        Text(
                            S.allDone.str(),
                            style = MaterialTheme.typography.titleMedium,
                            color = Glass.text,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
        }
    }
}

// =============================================================================== PC (optional)

@Composable
private fun SetupScreen(
    platform: Platform,
    tick: Int,
    hasPermission: Boolean,
    showMessage: (String) -> Unit,
    header: @Composable () -> Unit,
) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val grant = "pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS"
    val pcCommands = "adb devices\nadb shell $grant"
    val packages = remember(platform) { Debloat.list(platform) }
    val found = remember(platform, tick) { packages.filter { Launcher.isInstalled(ctx, it.name) } }
    val removeCommands = found.joinToString("\n") { "adb shell pm uninstall -k --user 0 ${it.name}" }
    val restoreCommands = packages.joinToString("\n") { "adb shell cmd package install-existing ${it.name}" }
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    fun copy(text: String) {
        copyToClipboard(ctx, text)
        showMessage(S.copied.get(lang))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = topInset + 8.dp, bottom = 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "header") { header() }

        item(key = "status") {
            GlassCard(
                Modifier.fillMaxWidth(),
                tint = if (hasPermission) Glass.accent.copy(alpha = 0.12f) else Glass.surface,
            ) {
                Text(
                    (if (hasPermission) S.statusGranted else S.statusNotGranted).str(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Glass.text,
                    modifier = Modifier.padding(18.dp),
                )
            }
        }

        item(key = "prep") {
            SetupCard(S.prepTitle.str()) {
                Setup.prepSteps(platform).forEachIndexed { index, step -> NumberedStep(index + 1, step.str()) }
            }
        }

        item(key = "command") {
            SetupCard(S.commandTitle.str()) {
                BodyText(S.commandText.str())
                CommandBox(pcCommands)
                GlassButton(text = S.copyCommands.str(), onClick = { copy(pcCommands) })
            }
        }

        item(key = "after") {
            SetupCard(S.afterTitle.str()) {
                Setup.after(platform).forEach { BodyText(it.str()) }
            }
        }

        item(key = "debloat") {
            SetupCard(S.debloatTitle.str()) {
                BodyText(Setup.debloatIntro(platform).str())
                if (found.isEmpty()) {
                    BodyText(S.debloatNone.str())
                } else {
                    found.forEach { PackageRow(it) }
                    CommandBox(removeCommands)
                    GlassButton(text = S.copyRemove.str(), onClick = { copy(removeCommands) }, primary = true)
                }
                GlassButton(text = S.copyRestore.str(), onClick = { copy(restoreCommands) })
                BodyText(S.debloatTools.str())
            }
        }

        item(key = "no_pc") {
            SetupCard(S.noPcTitle.str()) {
                BodyText(S.noPcText.str())
                CommandBox(grant)
                GlassButton(text = S.copyCommands.str(), onClick = { copy(grant) })
            }
        }
    }
}

@Composable
private fun PackageRow(pkg: Debloat.Pkg) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(Glass.warn)
        )
        Column(Modifier.padding(start = 10.dp)) {
            Text(pkg.label.str(), style = MaterialTheme.typography.bodyMedium, color = Glass.text)
            Text(
                pkg.name,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = Glass.textDim,
            )
        }
    }
}

// =============================================================================== Bausteine

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val haptics = rememberHaptics()
    val labels = listOf(S.tabChecklist.str(), S.tabPc.str())
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(Color(0xE60F1828))
            .border(1.dp, Glass.hairline, shape)
            .padding(5.dp),
    ) {
        labels.forEachIndexed { index, label ->
            val isSelected = index == selected
            val background by animateColorAsState(if (isSelected) Glass.accent else Color.Transparent, label = "tabBg")
            val foreground by animateColorAsState(if (isSelected) Glass.onAccent else Glass.textDim, label = "tabFg")
            Box(
                Modifier
                    .clip(shape)
                    .background(background)
                    .clickable {
                        if (!isSelected) {
                            haptics.tick()
                            onSelect(index)
                        }
                    }
                    .padding(horizontal = 22.dp, vertical = 12.dp),
            ) {
                Text(label, color = foreground, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}


@Composable
private fun HeaderButton(
    onClickLabel: String,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Glass.surface)
            .border(1.dp, Glass.hairline, CircleShape)
            .clickable(onClickLabel = onClickLabel, onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content,
    )
}


@Composable
private fun CategoryHeader(category: Category, done: Int, total: Int, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 6.dp, end = 6.dp, top = 14.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(category.color)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            category.label.str(),
            style = MaterialTheme.typography.titleSmall,
            color = Glass.text,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        if (total > 0) {
            Text("$done/$total", style = MaterialTheme.typography.labelMedium, color = Glass.textDim)
        }
    }
}


@Composable
private fun StepCard(
    step: ManualStep,
    installed: Boolean,
    state: StepState,
    checked: Boolean,
    detection: Detection?,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onToggleDone: (() -> Unit)?,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
    showCategory: Boolean = false,
    extra: @Composable ColumnScope.() -> Unit = {},
    actions: @Composable ColumnScope.() -> Unit = {},
) {
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
    val pills = buildList {
        if (!installed) {
            add(S.pillNotInstalled to Glass.textDim)
        } else {
            if (state == StepState.DETECTED_DONE) add(S.pillDetected to Glass.accent)
            if (state == StepState.DETECTED_OPEN) add(S.pillOpen to Glass.warn)
        }
        if (step.optional) add(S.pillOptional to Glass.textDim)
    }

    GlassCard(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggleExpanded)
                .padding(start = 4.dp, end = 14.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CheckDot(checked = checked, dimmed = !installed, onClick = onToggleDone)
            Column(
                Modifier
                    .weight(1f)
                    .padding(vertical = 8.dp)
            ) {
                if (showCategory) {
                    Text(
                        step.category.label.str(),
                        style = MaterialTheme.typography.labelSmall,
                        color = step.category.color,
                        modifier = Modifier.padding(bottom = 2.dp),
                    )
                }
                Text(
                    step.title.str(),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = if (installed) Glass.text else Glass.textDim,
                )
                if (pills.isNotEmpty()) {
                    Row(
                        Modifier.padding(top = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        pills.forEach { (text, color) -> Pill(text.str(), color) }
                    }
                }
            }
            Icon(
                Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = Glass.textDim,
                modifier = Modifier.rotate(chevron),
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 52.dp, end = 18.dp, bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (!installed) {
                    Text(S.notInstalled.str(), style = MaterialTheme.typography.bodyMedium, color = Glass.textDim)
                } else {
                    val statusText = detection?.info?.str() ?: when (state) {
                        StepState.DETECTED_DONE -> S.detectedDone.str()
                        StepState.DETECTED_OPEN -> S.detectedOpen.str()
                        StepState.MANUAL -> null
                    }
                    if (statusText != null && state != StepState.MANUAL) {
                        Text(
                            statusText,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (state == StepState.DETECTED_DONE) Glass.accent else Glass.warn,
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(S.howTo.str(), style = MaterialTheme.typography.labelSmall, color = Glass.textDim)
                        Text(step.path.str(), style = MaterialTheme.typography.bodyMedium, color = Glass.text)
                    }
                    step.why?.let {
                        Text(it.str(), style = MaterialTheme.typography.bodySmall, color = Glass.textDim)
                    }
                    extra()
                    if (step.jumps.isNotEmpty()) {
                        GlassButton(text = step.openLabel.str(), onClick = onOpen, primary = true)
                    }
                    actions()
                }
            }
        }
    }
}


@Composable
private fun DnsPicker(selected: String, onSelect: (String) -> Unit) {
    val haptics = rememberHaptics()
    val shape = RoundedCornerShape(14.dp)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        DnsPresets.list.forEach { preset ->
            val isSelected = selected == preset.host
            val border by animateColorAsState(
                if (isSelected) Glass.accent.copy(alpha = 0.8f) else Glass.hairline,
                label = "dnsBorder",
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(if (isSelected) Glass.accent.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.03f))
                    .border(1.dp, border, shape)
                    .selectable(
                        selected = isSelected,
                        role = Role.RadioButton,
                        onClick = {
                            haptics.tick()
                            onSelect(preset.host)
                        },
                    )
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioDot(isSelected)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(preset.name, style = MaterialTheme.typography.bodyLarge, color = Glass.text)
                    Text(preset.info.str(), style = MaterialTheme.typography.bodySmall, color = Glass.textDim)
                }
            }
        }
        OutlinedTextField(
            value = selected,
            onValueChange = { onSelect(it.trim()) },
            label = { Text(S.hostname.str()) },
            singleLine = true,
            shape = shape,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Glass.text,
                unfocusedTextColor = Glass.text,
                focusedBorderColor = Glass.accent,
                unfocusedBorderColor = Glass.hairline,
                focusedLabelColor = Glass.accent,
                unfocusedLabelColor = Glass.textDim,
                cursorColor = Glass.accent,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}


@Composable
private fun SetupCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Glass.text, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun BodyText(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = Glass.textDim)
}

@Composable
private fun NumberedStep(number: Int, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Glass.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "$number",
                style = MaterialTheme.typography.labelMedium,
                color = Glass.accent,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Glass.text, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun CommandBox(command: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Glass.inset)
            .border(1.dp, Glass.hairline, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        SelectionContainer {
            Text(
                command,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = Glass.text,
            )
        }
    }
}

private fun copyToClipboard(ctx: Context, text: String) {
    val clipboard = ctx.getSystemService(ClipboardManager::class.java)
    clipboard?.setPrimaryClip(ClipData.newPlainText("HyperOS Privacy Tuner", text))
}
