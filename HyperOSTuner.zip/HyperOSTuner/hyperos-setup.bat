@echo off
setlocal EnableExtensions EnableDelayedExpansion
title HyperOS Privacy Tuner - Einrichtung per ADB
cd /d "%~dp0"

set "APP_ID=de.hyperos.tuner"
set "LOG=%~dp0entfernte-apps.txt"

rem Werbung und Telemetrie - in mehreren aktuellen Debloat-Listen als sicher eingestuft
set "CORE_PKGS=com.miui.msa.global com.miui.analytics com.miui.daemon com.miui.bugreport com.miui.miservice com.miui.hybrid com.miui.hybrid.accessory com.miui.android.fashiongallery com.facebook.appmanager com.facebook.services com.facebook.system"
rem Nutzer-Apps - werden einzeln abgefragt
set "OPT_PKGS=com.miui.player com.miui.videoplayer com.mi.globalbrowser com.mi.globalminusscreen com.xiaomi.glgm com.miui.yellowpage com.xiaomi.mipicks com.xiaomi.joyose"

set "APK="
if exist "%~dp0HyperOSTuner.apk" set "APK=%~dp0HyperOSTuner.apk"
if not defined APK if exist "%~dp0app\build\outputs\apk\debug\app-debug.apk" set "APK=%~dp0app\build\outputs\apk\debug\app-debug.apk"

rem ---- ADB finden -------------------------------------------------------------
where adb >nul 2>&1
if not errorlevel 1 goto adb_ok
if exist "%~dp0platform-tools\adb.exe" (
    set "PATH=%~dp0platform-tools;!PATH!"
    goto adb_ok
)
echo.
echo ADB wurde nicht gefunden.
echo Lade die "SDK Platform-Tools" fuer Windows herunter und entpacke den Ordner
echo "platform-tools" direkt neben dieses Skript:
echo https://developer.android.com/tools/releases/platform-tools
echo.
pause
exit /b 1

:adb_ok
adb start-server >nul 2>&1

rem ---- Geraet pruefen ---------------------------------------------------------
:device
set "STATE="
for /f "delims=" %%s in ('adb get-state 2^>nul') do set "STATE=%%s"
if /i "%STATE%"=="device" goto device_ok
echo.
echo Kein freigegebenes Handy gefunden.
echo  - USB-Kabel verbunden und Handy entsperrt?
echo  - Entwickleroptionen: USB-Debugging eingeschaltet?
echo  - Abfrage "USB-Debugging zulassen?" am Handy bestaetigt?
echo.
pause
goto device

:device_ok
set "MODEL=unbekannt"
for /f "delims=" %%m in ('adb shell getprop ro.product.model') do set "MODEL=%%m"

rem ---- Menue ------------------------------------------------------------------
:menu
echo.
echo ==============================================================
echo   HyperOS Privacy Tuner - Einrichtung   Geraet: %MODEL%
echo ==============================================================
echo   [1] App installieren und freischalten
echo   [2] Werbe- und Tracking-Dienste entfernen   (empfohlen)
echo   [3] Xiaomi-Apps entfernen                    (einzeln abgefragt)
echo   [4] Entfernte Apps wiederherstellen
echo   [5] Beenden
echo.
choice /c 12345 /n /m "Auswahl [1-5]: "
if errorlevel 5 goto end
if errorlevel 4 goto restore
if errorlevel 3 goto optional
if errorlevel 2 goto core
goto grant

rem ---- [1] Installieren und freischalten --------------------------------------
:grant
adb shell pm path %APP_ID% | find "package:" >nul
if not errorlevel 1 goto grant_now
if not defined APK goto no_apk
echo.
echo Installiere HyperOS Privacy Tuner ...
adb install -r "%APK%"
if errorlevel 1 goto install_failed

:grant_now
echo.
echo Erteile WRITE_SECURE_SETTINGS ...
adb shell pm grant %APP_ID% android.permission.WRITE_SECURE_SETTINGS
adb shell dumpsys package %APP_ID% | find "WRITE_SECURE_SETTINGS: granted=true" >nul
if errorlevel 1 goto grant_failed
echo.
echo Fertig - die Freischaltung ist aktiv. HyperOS Privacy Tuner am Handy oeffnen.
echo USB-Debugging darfst du wieder ausschalten, die Entwickleroptionen bitte nicht.
pause
goto menu

:no_apk
echo.
echo HyperOS Privacy Tuner ist nicht installiert und es wurde keine APK gefunden.
echo In Android Studio "Build - Build APK(s)" ausfuehren oder die APK
echo als HyperOSTuner.apk neben dieses Skript legen.
pause
goto menu

:install_failed
echo.
echo Installation fehlgeschlagen.
echo In den Entwickleroptionen "Ueber USB installieren" einschalten und den Hinweis
echo am Handy bestaetigen. Alternativ die APK aufs Handy kopieren und antippen.
pause
goto menu

:grant_failed
echo.
echo Die Berechtigung wurde NICHT erteilt.
echo Haeufigste Ursache: In den Entwickleroptionen ist
echo "USB-Debugging (Sicherheitseinstellungen)" aus. Einschalten - dafuer muss ein
echo Xiaomi-Konto angemeldet sein -, die App schliessen und Punkt 1 wiederholen.
pause
goto menu

rem ---- [2] Werbung und Telemetrie ---------------------------------------------
:core
echo.
echo Entfernt nur fuer deinen Benutzer, mit Punkt 4 umkehrbar:
echo.
call :remove com.miui.msa.global             "msa - zentraler Werbedienst"
call :remove com.miui.analytics              "Analytics - Telemetrie"
call :remove com.miui.daemon                 "MIUI Daemon - Datensammlung im Hintergrund"
call :remove com.miui.bugreport              "Fehlerberichte"
call :remove com.miui.miservice              "Dienste und Feedback"
call :remove com.miui.hybrid                 "Quick Apps"
call :remove com.miui.hybrid.accessory       "Quick Apps Zubehoer"
call :remove com.miui.android.fashiongallery "Hintergrund-Karussell"
call :remove com.facebook.appmanager         "Facebook App Manager"
call :remove com.facebook.services           "Facebook Services"
call :remove com.facebook.system             "Facebook App Installer"
echo.
echo Fertig. Ein Neustart des Handys wird empfohlen.
pause
goto menu

rem ---- [3] Optionale Apps -----------------------------------------------------
:optional
echo.
echo Jede gefundene App wird einzeln abgefragt. Nur entfernen, was du nicht nutzt.
echo.
call :ask com.miui.player          "Mi Musik"
call :ask com.miui.videoplayer     "Mi Video"
call :ask com.mi.globalbrowser     "Mi Browser - vorher anderen Standardbrowser setzen"
call :ask com.mi.globalminusscreen "App Vault - linke Startbildschirmseite"
call :ask com.xiaomi.glgm          "Spiele"
call :ask com.miui.yellowpage      "Gelbe Seiten"
call :ask com.xiaomi.mipicks       "GetApps - liefert teils Updates fuer Xiaomi-Apps"
call :ask com.xiaomi.joyose        "Joyose - Leistungsprofile, kann Spieleleistung und Waerme veraendern"
echo.
echo Fertig.
pause
goto menu

rem ---- [4] Wiederherstellen ---------------------------------------------------
:restore
echo.
if exist "%LOG%" goto restore_log
echo Kein Protokoll gefunden - stelle alle Pakete aus diesem Skript wieder her.
for %%p in (%CORE_PKGS% %OPT_PKGS%) do (
    adb shell cmd package install-existing %%p >nul 2>&1
)
echo Fertig.
pause
goto menu

:restore_log
for /f "usebackq delims=" %%p in ("%LOG%") do (
    echo   Stelle wieder her: %%p
    adb shell cmd package install-existing %%p >nul 2>&1
)
del "%LOG%"
echo Fertig.
pause
goto menu

rem ---- Unterprogramme ---------------------------------------------------------
:remove
adb shell pm path %1 2>nul | find "package:" >nul
if errorlevel 1 (
    echo   [ ] %~2 - nicht vorhanden
    goto :eof
)
adb shell pm uninstall -k --user 0 %1 | find "Success" >nul
if errorlevel 1 (
    echo   [-] %~2 - FEHLGESCHLAGEN
) else (
    echo   [x] %~2 - entfernt
    >>"%LOG%" echo %~1
)
goto :eof

:ask
adb shell pm path %1 2>nul | find "package:" >nul
if errorlevel 1 goto :eof
choice /c jn /n /m "  %~2 entfernen? [J/N] "
if errorlevel 2 goto :eof
call :remove %1 %2
goto :eof

:end
endlocal
exit /b 0
