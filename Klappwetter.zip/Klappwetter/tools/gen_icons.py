#!/usr/bin/env python3
"""Erzeugt die glänzenden Wettersymbole als Android-Vector-Drawables.

Alle Formen werden als Polygone berechnet (gleiche Umlaufrichtung),
damit sich überlappende Teilflächen sauber vereinigen.
Aufruf:  python3 tools/gen_icons.py  (aus dem Projektordner)
"""
import math
import os
import sys

OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable")
PREVIEW = "--preview" in sys.argv

# ---------------------------------------------------------------- Geometrie

def circle(cx, cy, r, n=72):
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def ellipse(cx, cy, rx, ry, n=60):
    return [(cx + rx * math.cos(2 * math.pi * i / n), cy + ry * math.sin(2 * math.pi * i / n)) for i in range(n)]


def rect(x1, y1, x2, y2):
    return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]


def pill(x1, y1, x2, y2):
    r = (y2 - y1) / 2.0
    return [rect(x1 + r, y1, x2 - r, y2), circle(x1 + r, y1 + r, r, 40), circle(x2 - r, y1 + r, r, 40)]


def star(cx, cy, r_out, r_in, points, rot=-90.0):
    pts = []
    for i in range(points * 2):
        r = r_out if i % 2 == 0 else r_in
        a = math.radians(rot + 180.0 * i / points)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def crescent(c1, r1, c2, r2, n=90):
    """Fläche von Kreis 1 ohne Kreis 2."""
    (x1, y1), (x2, y2) = c1, c2
    d = math.hypot(x2 - x1, y2 - y1)
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(r1 * r1 - a * a)
    mx, my = x1 + a * (x2 - x1) / d, y1 + a * (y2 - y1) / d
    p1 = (mx + h * (y2 - y1) / d, my - h * (x2 - x1) / d)
    p2 = (mx - h * (y2 - y1) / d, my + h * (x2 - x1) / d)

    def ang(c, p):
        return math.atan2(p[1] - c[1], p[0] - c[0])

    # äußerer Bogen auf Kreis 1 – der Teil außerhalb von Kreis 2
    a1, a2 = ang(c1, p1), ang(c1, p2)
    pts = []
    for sweep in (1, -1):
        cand = []
        span = (a2 - a1) % (2 * math.pi) if sweep == 1 else -((a1 - a2) % (2 * math.pi))
        for i in range(n + 1):
            t = a1 + span * i / n
            cand.append((x1 + r1 * math.cos(t), y1 + r1 * math.sin(t)))
        mid = cand[n // 2]
        if math.hypot(mid[0] - x2, mid[1] - y2) > r2:
            pts = cand
            break
    # innerer Bogen auf Kreis 2 – der Teil innerhalb von Kreis 1, zurück zu p1
    b1, b2 = ang(c2, p2), ang(c2, p1)
    for sweep in (1, -1):
        span = (b2 - b1) % (2 * math.pi) if sweep == 1 else -((b1 - b2) % (2 * math.pi))
        cand = [(x2 + r2 * math.cos(b1 + span * i / n), y2 + r2 * math.sin(b1 + span * i / n)) for i in range(1, n)]
        mid = cand[len(cand) // 2]
        if math.hypot(mid[0] - x1, mid[1] - y1) < r1:
            return pts + cand
    return pts


def path(*polys):
    out = []
    for poly in polys:
        if poly and isinstance(poly[0], list):  # verschachtelt (z. B. pill)
            out.append(path(*poly))
            continue
        out.append("M" + " L".join(f"{x:.2f},{y:.2f}" for x, y in poly) + "Z")
    return " ".join(out)

# ---------------------------------------------------------------- Füllungen

def radial(cx, cy, r, stops):
    items = "".join(f'\n                <item android:offset="{o}" android:color="{c}" />' for o, c in stops)
    return (f'\n        <aapt:attr name="android:fillColor">\n            <gradient android:type="radial" '
            f'android:centerX="{cx}" android:centerY="{cy}" android:gradientRadius="{r}">{items}\n'
            f'            </gradient>\n        </aapt:attr>')


def linear(x1, y1, x2, y2, stops):
    items = "".join(f'\n                <item android:offset="{o}" android:color="{c}" />' for o, c in stops)
    return (f'\n        <aapt:attr name="android:fillColor">\n            <gradient android:type="linear" '
            f'android:startX="{x1}" android:startY="{y1}" android:endX="{x2}" android:endY="{y2}">{items}\n'
            f'            </gradient>\n        </aapt:attr>')


def p(data, fill, stroke=None, stroke_w=None, preview_color=None):
    """fill: entweder '#AARRGGBB' oder ein Gradient-Block."""
    attrs = f'android:pathData="{data}"'
    body = ""
    if fill.startswith("#"):
        attrs += f' android:fillColor="{fill}"'
    else:
        body = fill
    if stroke:
        attrs += f' android:strokeColor="{stroke}" android:strokeWidth="{stroke_w}"'
    if body:
        return f"    <path {attrs}>{body}\n    </path>"
    return f"    <path {attrs} />"


def group(content, sx=1.0, tx=0.0, ty=0.0):
    return (f'    <group android:scaleX="{sx}" android:scaleY="{sx}" android:translateX="{tx}" android:translateY="{ty}">\n'
            + "\n".join("    " + line for line in content.split("\n")) + "\n    </group>")


def vector(body, size=96, vp=100):
    return (f'<?xml version="1.0" encoding="utf-8"?>\n'
            f'<!-- generiert von tools/gen_icons.py -->\n'
            f'<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
            f'    xmlns:aapt="http://schemas.android.com/aapt"\n'
            f'    android:width="{size}dp"\n    android:height="{size}dp"\n'
            f'    android:viewportWidth="{vp}"\n    android:viewportHeight="{vp}">\n{body}\n</vector>\n')

# ---------------------------------------------------------------- Bausteine

PREVIEW_SHAPES = {}  # name -> list of (polys, color, transform)


def sun_parts():
    glow = circle(50, 50, 47)
    corona = star(50, 50, 34, 30.5, 36)
    sphere = circle(50, 50, 28)
    shine = ellipse(42, 37, 14, 8)
    parts = [
        p(path(glow), radial(50, 50, 47, [(0.5, "#CCFFD54F"), (0.72, "#55FFB300"), (1.0, "#00FFB300")])),
        p(path(corona), radial(50, 50, 34, [(0.8, "#FFFFC107"), (1.0, "#80FF9800")])),
        p(path(sphere), radial(41, 38, 40, [(0.0, "#FFFFF8C4"), (0.35, "#FFFFD54F"), (0.75, "#FFFFA726"), (1.0, "#FFF57C00")])),
        p(path(shine), linear(42, 29, 42, 45, [(0.0, "#E6FFFFFF"), (1.0, "#00FFFFFF")])),
    ]
    prev = [([glow], (255, 213, 79, 90)), ([corona], (255, 179, 0, 255)), ([sphere], (255, 193, 7, 255)), ([shine], (255, 255, 255, 160))]
    return "\n".join(parts), prev


def moon_parts(with_stars=True):
    glow = circle(50, 50, 44)
    body = crescent((50, 50), 30, (64, 40), 26)
    parts = [
        p(path(glow), radial(50, 50, 44, [(0.45, "#55FFF59D"), (1.0, "#00FFF59D")])),
        p(path(body), radial(40, 58, 36, [(0.0, "#FFFFFDE7"), (0.5, "#FFFFF176"), (1.0, "#FFFFCA28")])),
    ]
    prev = [([glow], (255, 245, 157, 60)), ([body], (255, 241, 118, 255))]
    if with_stars:
        s1, s2 = star(80, 22, 6, 1.6, 4), star(70, 76, 4, 1.1, 4)
        parts.append(p(path(s1, s2), "#E6FFFFFF"))
        prev.append(([s1, s2], (255, 255, 255, 230)))
    return "\n".join(parts), prev


def cloud_polys():
    return [circle(30, 60, 14), circle(51, 47, 20), circle(70, 57, 16)] + pill(16, 52, 86, 76)


def cloud_parts(dark=False):
    polys = cloud_polys()
    shadow = [[(x, y + 3) for x, y in poly] for poly in polys]
    if dark:
        fill = linear(50, 27, 50, 76, [(0.0, "#FFF5F7F8"), (0.55, "#FFB0BEC5"), (1.0, "#FF78909C")])
        prev_col = (176, 190, 197, 255)
    else:
        fill = linear(50, 27, 50, 76, [(0.0, "#FFFFFFFF"), (0.6, "#FFF1F4F6"), (1.0, "#FFC5D0D6")])
        prev_col = (240, 244, 246, 255)
    shine = ellipse(46, 38, 11, 5)
    parts = [
        p(path(*shadow), "#33000000"),
        p(path(*polys), fill),
        p(path(shine), linear(46, 33, 46, 43, [(0.0, "#CCFFFFFF"), (1.0, "#00FFFFFF")])),
    ]
    prev = [(shadow, (0, 0, 0, 50)), (polys, prev_col), ([shine], (255, 255, 255, 120))]
    return "\n".join(parts), prev


def drop(x, y):
    return [circle(x, y, 4.6, 36), [(x + 2.6, y - 12), (x + 4.4, y - 1.2), (x - 4.4, y - 1.2)]]


def flake(x, y):
    return star(x, y, 6.5, 2.3, 6)


# ---------------------------------------------------------------- Symbole

def write(name, body, prev, size=96, vp=100):
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(vector(body, size, vp))
    PREVIEW_SHAPES[name] = (prev, vp)


def tr(prev, s, tx, ty):
    return [([[(x * s + tx, y * s + ty) for x, y in poly] for poly in polys], col) for polys, col in prev]


def build():
    sun, sun_prev = sun_parts()
    moon, moon_prev = moon_parts()
    moon_small, moon_small_prev = moon_parts(with_stars=False)
    cloud, cloud_prev = cloud_parts()
    dcloud, dcloud_prev = cloud_parts(dark=True)

    write("ic_w_sun", sun, sun_prev)
    write("ic_w_moon", moon, moon_prev)
    write("ic_w_cloud", group(cloud, 1.0, -1, 2), tr(cloud_prev, 1.0, -1, 2))

    write("ic_w_partly_day", group(sun, 0.62, 5, 5) + "\n" + group(cloud, 0.82, 16.18, 21.36),
          tr(sun_prev, 0.62, 5, 5) + tr(cloud_prev, 0.82, 16.18, 21.36))
    write("ic_w_partly_night", group(moon_small, 0.66, 3, 3) + "\n" + group(cloud, 0.82, 16.18, 21.36),
          tr(moon_small_prev, 0.66, 3, 3) + tr(cloud_prev, 0.82, 16.18, 21.36))

    drops = drop(34, 82) + drop(52, 90) + drop(70, 82)
    rain = p(path(*drops), linear(50, 68, 50, 95, [(0.0, "#FF90CAF9"), (1.0, "#FF1E88E5")]))
    write("ic_w_rain", group(dcloud, 0.9, 4.1, -4) + "\n" + rain,
          tr(dcloud_prev, 0.9, 4.1, -4) + [(drops, (66, 165, 245, 255))])

    flakes = [flake(32, 80), flake(52, 89), flake(71, 80)]
    snow = p(path(*flakes), "#FFFFFFFF", stroke="#FF64B5F6", stroke_w=1.2)
    write("ic_w_snow", group(cloud, 0.9, 4.1, -4) + "\n" + snow,
          tr(cloud_prev, 0.9, 4.1, -4) + [(flakes, (255, 255, 255, 255))])

    bolt = [(55, 58), (40, 80), (50, 80), (44, 97), (65, 72), (54, 72), (61, 58)]
    thunder = p(path(bolt), linear(50, 58, 50, 97, [(0.0, "#FFFFF59D"), (0.5, "#FFFFCA28"), (1.0, "#FFFF8F00")]),
                stroke="#80E65100", stroke_w=1.0)
    write("ic_w_thunder", group(dcloud, 0.9, 4.1, -6) + "\n" + thunder,
          tr(dcloud_prev, 0.9, 4.1, -6) + [([bolt], (255, 202, 40, 255))])

    bars = pill(18, 70, 74, 76) + pill(28, 80, 86, 86) + pill(14, 90, 66, 96)
    fog = p(path(*bars), linear(50, 70, 50, 96, [(0.0, "#F2ECEFF1"), (1.0, "#D9B0BEC5")]))
    write("ic_w_fog", group(cloud, 0.85, 6.65, -6) + "\n" + fog,
          tr(cloud_prev, 0.85, 6.65, -6) + [(bars, (220, 225, 230, 240))])

    # ------------------------------------------------ App-Icon (adaptiv, 108er Raster)
    shadow = [[(x, y + 2.5) for x, y in poly] for poly in [rect(39, 30, 69, 74)] + [circle(39, 37, 7, 30), circle(69, 37, 7, 30), circle(39, 67, 7, 30), circle(69, 67, 7, 30)] + [rect(32, 37, 76, 67)]]
    card = [rect(39, 30, 69, 74), circle(39, 37, 7, 30), circle(69, 37, 7, 30), circle(39, 67, 7, 30), circle(69, 67, 7, 30), rect(32, 37, 76, 67)]
    ring_outer, ring_inner = circle(54, 46, 10, 60), list(reversed(circle(54, 46, 5, 60)))
    split = rect(32, 51.4, 76, 52.6)
    fg = "\n".join([
        p(path(*shadow), "#55000000"),
        p(path(*card), linear(54, 30, 54, 74, [(0.0, "#FFFFFFFF"), (0.5, "#FFF3F3F3"), (1.0, "#FFD6D9DC")])),
        p(path(ring_outer, ring_inner), "#FF263238"),
        p(path(split), "#66000000"),
        group(sun_parts()[0], 0.30, 58, 57),
    ])
    write("ic_launcher_foreground", fg,
          [(shadow, (0, 0, 0, 80)), (card, (245, 245, 245, 255)), ([ring_outer], (38, 50, 56, 255)),
           ([ring_inner], (245, 245, 245, 255)), ([split], (0, 0, 0, 100))] + tr(sun_prev, 0.30, 58, 57),
          size=108, vp=108)


def preview():
    from PIL import Image, ImageDraw
    names = list(PREVIEW_SHAPES)
    cell = 220
    img = Image.new("RGBA", (cell * len(names), cell + 30), (24, 35, 58, 255))
    d = ImageDraw.Draw(img)
    for i, name in enumerate(names):
        prev, vp = PREVIEW_SHAPES[name]
        layer = Image.new("RGBA", (cell, cell), (0, 0, 0, 0))
        for polys, col in prev:
            sub = Image.new("RGBA", (cell, cell), (0, 0, 0, 0))
            sd = ImageDraw.Draw(sub)
            for poly in polys:
                sd.polygon([(x * cell / vp, y * cell / vp) for x, y in poly], fill=col)
            layer = Image.alpha_composite(layer, sub)
        img.alpha_composite(layer, (i * cell, 0))
        d.text((i * cell + 6, cell + 8), name, fill=(230, 230, 230, 255))
    img.save("/home/claude/icon_preview.png")


if __name__ == "__main__":
    build()
    if PREVIEW:
        preview()
    print("Symbole geschrieben:", ", ".join(PREVIEW_SHAPES))
