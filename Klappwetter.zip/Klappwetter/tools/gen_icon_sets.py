#!/usr/bin/env python3
"""Erzeugt die zusätzlichen Icon-Sets als Vector-Drawables.

  ic_flat_*   Flach    – volle Farbflächen, weicher Schlagschatten
  ic_duo_*    Zweiton  – jede Form in heller und dunkler Hälfte
  ic_paper_*  Papier   – gestapelte Lagen wie ausgeschnittenes Papier
  ic_line_*   Linie    – weiße Konturen mit dunklem Saum

Aufruf aus dem Projektordner:  python3 tools/gen_icon_sets.py [--preview]
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from gen_icons import OUT, circle, crescent, pill, rect, star  # noqa: E402

PREVIEW = "--preview" in sys.argv
CONDS = ["sun", "moon", "partly_day", "partly_night", "cloud", "fog", "rain", "snow", "thunder"]

# ------------------------------------------------------------------ Geometrie


def area(poly):
    return sum(poly[i][0] * poly[(i + 1) % len(poly)][1] - poly[(i + 1) % len(poly)][0] * poly[i][1]
               for i in range(len(poly))) / 2.0


def orient(poly):
    """Einheitliche Umlaufrichtung, damit sich Teilflächen vereinigen."""
    return poly if area(poly) >= 0 else list(reversed(poly))


def T(pts, s, tx, ty):
    return [(x * s + tx, y * s + ty) for x, y in pts]


def capsule(x1, y1, x2, y2, w, n=14):
    r = w / 2.0
    a = math.atan2(y2 - y1, x2 - x1)
    pts = []
    for i in range(n + 1):  # Kappe am Ende
        t = a - math.pi / 2 + math.pi * i / n
        pts.append((x2 + r * math.cos(t), y2 + r * math.sin(t)))
    for i in range(n + 1):  # Kappe am Anfang
        t = a + math.pi / 2 + math.pi * i / n
        pts.append((x1 + r * math.cos(t), y1 + r * math.sin(t)))
    return orient(pts)


def clip(poly, a, b, c):
    """Behält den Teil mit a*x + b*y <= c (Sutherland-Hodgman an einer Halbebene)."""
    def side(p):
        return a * p[0] + b * p[1] - c

    def cut(p, q):
        dp, dq = side(p), side(q)
        t = dp / (dp - dq)
        return (p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1]))

    out = []
    for i in range(len(poly)):
        cur, prev = poly[i], poly[i - 1]
        if side(cur) <= 0:
            if side(prev) > 0:
                out.append(cut(prev, cur))
            out.append(cur)
        elif side(prev) <= 0:
            out.append(cut(prev, cur))
    return out


def teardrop(x, y):
    return [orient(circle(x, y, 4.6, 36)), orient([(x + 2.6, y - 12), (x + 4.4, y - 1.2), (x - 4.4, y - 1.2)])]


# Wolke als Grundformen – für Füllung, Umriss und Verdeckung
CLOUD_PRIMS = [("c", 30, 60, 14), ("c", 51, 47, 20), ("c", 70, 57, 16),
               ("r", 28, 52, 74, 76), ("c", 28, 64, 12), ("c", 74, 64, 12)]


def prim_T(pr, s, tx, ty):
    if pr[0] == "c":
        return ("c", pr[1] * s + tx, pr[2] * s + ty, pr[3] * s)
    return ("r", pr[1] * s + tx, pr[2] * s + ty, pr[3] * s + tx, pr[4] * s + ty)


def prim_poly(pr):
    if pr[0] == "c":
        return orient(circle(pr[1], pr[2], pr[3], 72))
    return orient(rect(pr[1], pr[2], pr[3], pr[4]))


def inside(pt, pr, margin=0.0):
    x, y = pt
    if pr[0] == "c":
        return math.hypot(x - pr[1], y - pr[2]) < pr[3] + margin
    return pr[1] - margin < x < pr[3] + margin and pr[2] - margin < y < pr[4] + margin


def boundary(pr):
    if pr[0] == "c":
        return circle(pr[1], pr[2], pr[3], 240)
    x1, y1, x2, y2 = pr[1:]
    pts = []
    for i in range(80):
        t = i / 80
        pts += [(x1 + (x2 - x1) * t, y1), (x2, y1 + (y2 - y1) * t), (x2 - (x2 - x1) * t, y2), (x1, y2 - (y2 - y1) * t)]
    return pts


def cloud_outline(prims):
    pts = []
    for pr in prims:
        for q in boundary(pr):
            if not any(inside(q, o, -0.05) for o in prims if o is not pr):
                pts.append(q)
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    pts.sort(key=lambda q: math.atan2(q[1] - cy, q[0] - cx))
    # Ausdünnen: nahe beieinanderliegende Punkte zusammenfassen
    thin = [pts[0]]
    for q in pts[1:]:
        if math.hypot(q[0] - thin[-1][0], q[1] - thin[-1][1]) > 0.9:
            thin.append(q)
    return thin


def densify(pts, closed, step=0.8):
    seq = pts + ([pts[0]] if closed else [])
    out = [seq[0]]
    for a, b in zip(seq, seq[1:]):
        n = max(1, int(math.hypot(b[0] - a[0], b[1] - a[1]) / step))
        out += [(a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n) for i in range(1, n + 1)]
    return out


def occlude(lines, prims, margin):
    """Entfernt Linienstücke, die hinter der Wolke liegen."""
    result = []
    for pts, closed in lines:
        dense = densify(pts, closed)
        vis = [not any(inside(p, pr, margin) for pr in prims) for p in dense]
        if all(vis):
            result.append((pts, closed))
            continue
        run = []
        for p, v in zip(dense, vis):
            if v:
                run.append(p)
            elif run:
                if len(run) > 1:
                    result.append((run, False))
                run = []
        if len(run) > 1:
            result.append((run, False))
    return result

# ------------------------------------------------------------------ Elemente
# ("f", polys, farbe) – Fläche      ("s", [(punkte, geschlossen)], farbe, breite) – Linie


def tf(elements, s, tx, ty):
    out = []
    for e in elements:
        if e[0] == "f":
            out.append(("f", [T(p, s, tx, ty) for p in e[1]], e[2]))
        else:
            out.append(("s", [(T(p, s, tx, ty), c) for p, c in e[1]], e[2], e[3]))
    return out


def shadow(polys, dx, dy, color):
    return ("f", [T(p, 1, dx, dy) for p in polys], color)


CLOUD_POLYS = [prim_poly(p) for p in CLOUD_PRIMS]
LINE_W, HALO_W, LINE_C, HALO_C = 4.2, 7.6, "#FFFFFFFF", "#59000000"


def strokes(lines):
    return [("s", lines, HALO_C, HALO_W), ("s", lines, LINE_C, LINE_W)]


def sun(style):
    if style == "flat":
        rays = [capsule(50 + 23 * math.cos(a), 50 + 23 * math.sin(a), 50 + 34 * math.cos(a), 50 + 34 * math.sin(a), 6.5)
                for a in [math.radians(45 * i) for i in range(8)]]
        core = [orient(circle(50, 50, 19))]
        return [shadow(rays + core, 1.5, 2.5, "#2E000000"), ("f", rays, "#FFFFA000"), ("f", core, "#FFFFCA28")]
    if style == "duo":
        c = orient(circle(50, 50, 28))
        return [shadow([c], 1.5, 2.5, "#2E000000"), ("f", [c], "#FFF9A825"), ("f", [clip(c, 1, 1, 100)], "#FFFFD54F")]
    if style == "paper":
        out = []
        for r, col in ((30, "#FFEF6C00"), (24, "#FFFFA000"), (17, "#FFFFCA28")):
            c = [orient(circle(50, 50, r))]
            out += [shadow(c, 1.2, 1.8, "#3D000000"), ("f", c, col)]
        return out
    # Linie
    lines = [(circle(50, 50, 13, 60), True)]
    for i in range(8):
        a = math.radians(45 * i)
        lines.append(([(50 + 19 * math.cos(a), 50 + 19 * math.sin(a)), (50 + 28 * math.cos(a), 50 + 28 * math.sin(a))], False))
    return strokes(lines)


def moon(style):
    body = orient(crescent((50, 50), 30, (64, 40), 26))
    if style == "flat":
        return [shadow([body], 1.5, 2.5, "#2E000000"), ("f", [body], "#FFFFE082")]
    if style == "duo":
        return [shadow([body], 1.5, 2.5, "#2E000000"), ("f", [body], "#FFFBC02D"), ("f", [clip(body, 1, 1, 100)], "#FFFFF59D")]
    if style == "paper":
        craters = [orient(circle(32, 58, 3.5, 30)), orient(circle(40, 71, 2.5, 30)), orient(circle(29, 43, 2.2, 30))]
        return [shadow([body], 1.2, 1.8, "#3D000000"), ("f", [body], "#FFFFE082"), ("f", craters, "#FFFFCA28")]
    return strokes([(body, True)])


TONES = {
    "flat": {"light": "#FFFFFFFF", "mid": "#FFCFD8DC", "dark": "#FF90A4AE"},
    "duo": {"light": ("#FFD5DDE2", "#FFFFFFFF"), "mid": ("#FFA7B4BC", "#FFC9D3D9"), "dark": ("#FF78909C", "#FF9EB0BA")},
    "paper": {"light": ("#FFB0BEC5", "#FFFAFAFA"), "mid": ("#FF78909C", "#FFCFD8DC"), "dark": ("#FF546E7A", "#FF90A4AE")},
}


def cloud(style, tone):
    if style == "flat":
        return [shadow(CLOUD_POLYS, 0, 3, "#33000000"), ("f", CLOUD_POLYS, TONES["flat"][tone])]
    if style == "duo":
        base, top = TONES["duo"][tone]
        upper = [q for q in (clip(p, 0, 1, 54) for p in CLOUD_POLYS) if len(q) > 2]
        return [shadow(CLOUD_POLYS, 0, 3, "#33000000"), ("f", CLOUD_POLYS, base), ("f", upper, top)]
    if style == "paper":
        back_c, front_c = TONES["paper"][tone]
        back = [T(p, 0.7, 30, 0) for p in CLOUD_POLYS]
        return [shadow(back, 1.2, 1.8, "#3D000000"), ("f", back, back_c),
                shadow(CLOUD_POLYS, 1.2, 2.2, "#3D000000"), ("f", CLOUD_POLYS, front_c)]
    return strokes([(cloud_outline(CLOUD_PRIMS), True)])


RAIN_LINES = [((36, 74), (32, 86)), ((54, 80), (50, 92)), ((72, 74), (68, 86))]
FLAKES = [(32, 80), (52, 89), (71, 80)]
BOLT = [(55, 58), (40, 80), (50, 80), (44, 97), (65, 72), (54, 72), (61, 58)]
FOG = [(18, 70, 74, 76), (28, 80, 86, 86), (14, 90, 66, 96)]


def rain(style):
    if style == "line":
        return strokes([([a, b], False) for a, b in RAIN_LINES])
    if style == "paper":
        drops = [q for x, y in ((34, 84), (52, 91), (70, 84)) for q in teardrop(x, y)]
        return [shadow(drops, 1.2, 1.8, "#3D000000"), ("f", drops, "#FF29B6F6")]
    caps = [capsule(a[0], a[1], b[0], b[1], 5) for a, b in RAIN_LINES]
    return [("f", caps, "#FF42A5F5" if style == "flat" else "#FF29B6F6")]


def snow(style):
    if style == "line":
        lines = []
        for x, y in FLAKES:
            for k in range(3):
                a = math.radians(90 + 60 * k)
                lines.append(([(x - 7 * math.cos(a), y - 7 * math.sin(a)), (x + 7 * math.cos(a), y + 7 * math.sin(a))], False))
        return strokes(lines)
    flakes = [orient(star(x, y, 6.5, 2.3, 6)) for x, y in FLAKES]
    return [shadow(flakes, 1, 1.5, "#4D000000"), ("f", flakes, "#FFFFFFFF")]


def bolt(style):
    b = orient(BOLT)
    if style == "line":
        return strokes([(BOLT, True)])
    if style == "duo":
        return [shadow([b], 1.2, 2, "#33000000"), ("f", [b], "#FFFFA000"), ("f", [clip(b, 1, 0, 52)], "#FFFFE082")]
    return [shadow([b], 1.2, 2, "#3D000000"), ("f", [b], "#FFFFCA28" if style == "flat" else "#FFFFC400")]


def fog(style):
    if style == "line":
        return strokes([([(20, 73), (72, 73)], False), ([(30, 83), (84, 83)], False), ([(16, 93), (64, 93)], False)])
    bars = [orient(q) for b in FOG for q in pill(*b)]
    color = {"flat": "#FFCFD8DC", "duo": "#FFDCE3E8", "paper": "#FFECEFF1"}[style]
    out = [("f", bars, color)]
    if style == "paper":
        out.insert(0, shadow(bars, 1.2, 1.8, "#3D000000"))
    return out

# ------------------------------------------------------------------ Zusammensetzen


def compose(style, cond):
    line = style == "line"
    if cond == "sun":
        return sun(style)
    if cond == "moon":
        return moon(style)
    if cond == "cloud":
        return tf(cloud(style, "light"), 1, -1, 2)
    if cond in ("partly_day", "partly_night"):
        back = sun(style) if cond == "partly_day" else moon(style)
        if line:
            cs, ctx, cty = 0.8, 18, 24
            back = tf(back, 0.75, 0, 0)
            prims = [prim_T(p, cs, ctx, cty) for p in CLOUD_PRIMS]
            back = [("s", occlude(e[1], prims, 4.5), e[2], e[3]) for e in back]
        else:
            cs, ctx, cty = 0.82, 16.18, 21.36
            back = tf(back, 0.62, 5, 5) if cond == "partly_day" else tf(back, 0.66, 3, 3)
        return back + tf(cloud(style, "light"), cs, ctx, cty)
    if cond == "rain":
        return tf(cloud(style, "mid"), 0.9, 4.1, -4) + rain(style)
    if cond == "snow":
        return tf(cloud(style, "light"), 0.9, 4.1, -4) + snow(style)
    if cond == "thunder":
        front = bolt(style)
        if line:
            prims = [prim_T(p, 0.9, 4.1, -6) for p in CLOUD_PRIMS]
            front = [("s", occlude(e[1], prims, 3.0), e[2], e[3]) for e in front]
        return tf(cloud(style, "dark"), 0.9, 4.1, -6) + front
    if cond == "fog":
        return tf(cloud(style, "light"), 0.85, 6.65, -6) + fog(style)
    raise ValueError(cond)


def fmt_path(polys):
    return " ".join("M" + " L".join(f"{x:.2f},{y:.2f}" for x, y in p) + "Z" for p in polys if len(p) > 2)


def fmt_lines(lines):
    out = []
    for pts, closed in lines:
        out.append("M" + " L".join(f"{x:.2f},{y:.2f}" for x, y in pts) + ("Z" if closed else ""))
    return " ".join(out)


def to_xml(elements):
    body = []
    for e in elements:
        if e[0] == "f":
            data = fmt_path(e[1])
            if data:
                body.append(f'    <path android:fillColor="{e[2]}" android:pathData="{data}" />')
        else:
            data = fmt_lines(e[1])
            if data:
                body.append(f'    <path android:pathData="{data}" android:strokeColor="{e[2]}" '
                            f'android:strokeWidth="{e[3]}" android:strokeLineCap="round" android:strokeLineJoin="round" />')
    return ('<?xml version="1.0" encoding="utf-8"?>\n<!-- generiert von tools/gen_icon_sets.py -->\n'
            '<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
            '    android:width="96dp"\n    android:height="96dp"\n'
            '    android:viewportWidth="100"\n    android:viewportHeight="100">\n'
            + "\n".join(body) + "\n</vector>\n")


SETS = {"flat": "ic_flat", "duo": "ic_duo", "paper": "ic_paper", "line": "ic_line"}


def rgba(c):
    v = int(c[1:], 16)
    return ((v >> 16) & 255, (v >> 8) & 255, v & 255, (v >> 24) & 255)


def preview(all_icons):
    from PIL import Image, ImageDraw
    cell, sc = 120, 1.2
    bgs = {"flat": (45, 80, 140), "duo": (110, 70, 110), "paper": (60, 120, 115), "line": (30, 40, 70)}
    img = Image.new("RGBA", (cell * len(CONDS), cell * len(SETS)), (0, 0, 0, 255))
    for r, style in enumerate(SETS):
        for c, cond in enumerate(CONDS):
            tile = Image.new("RGBA", (cell, cell), bgs[style] + (255,))
            for e in all_icons[(style, cond)]:
                layer = Image.new("RGBA", (cell, cell), (0, 0, 0, 0))
                d = ImageDraw.Draw(layer)
                if e[0] == "f":
                    for p in e[1]:
                        if len(p) > 2:
                            d.polygon([(x * sc, y * sc) for x, y in p], fill=rgba(e[2]))
                else:
                    for pts, closed in e[1]:
                        seq = pts + ([pts[0]] if closed else [])
                        d.line([(x * sc, y * sc) for x, y in seq], fill=rgba(e[2]), width=max(1, int(e[3] * sc)), joint="curve")
                tile = Image.alpha_composite(tile, layer)
            img.paste(tile, (c * cell, r * cell))
    img.save("/home/claude/iconsets_preview.png")


def main():
    os.makedirs(OUT, exist_ok=True)
    all_icons = {}
    for style, prefix in SETS.items():
        for cond in CONDS:
            elements = compose(style, cond)
            all_icons[(style, cond)] = elements
            with open(os.path.join(OUT, f"{prefix}_{cond}.xml"), "w", encoding="utf-8") as f:
                f.write(to_xml(elements))
    if PREVIEW:
        preview(all_icons)
    print(f"{len(all_icons)} Symbole geschrieben")


if __name__ == "__main__":
    main()
