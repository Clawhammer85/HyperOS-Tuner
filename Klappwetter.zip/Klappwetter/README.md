# Klappwetter

Klappuhr-Widgets mit Wetter für Android (ab Android 8), im Stil der klassischen Flip-Clock.
Ohne Werbung, ohne Konto, ohne Google-Dienste.

## Wetterdienste

| Anbieter | Kosten | Hinweis |
|---|---|---|
| Open-Meteo | frei | Standard, weltweit, mit UV-Index |
| MET Norway / Yr | frei | weltweit, sehr gut für Europa |
| Deutscher Wetterdienst (über Bright Sky) | frei | Deutschland und Umgebung, DWD-Stationen und MOSMIX |
| OpenWeatherMap | frei mit eigenem Schlüssel | Schlüssel unter openweathermap.org holen und in den Einstellungen eintragen |

Foreca und AccuWeather sind nicht dabei: beide bieten keinen dauerhaft freien Zugang
(AccuWeather nur eine 14-Tage-Testphase, danach kostenpflichtig).

## Regenradar

Karte mit Zeitleiste und Abspielfunktion. In Deutschland und den Nachbarländern kommen die Bilder vom
DWD-Radar (1 km, mit bis zu 2 Stunden Vorhersage), sonst von RainViewer (gröber, nur Vergangenheit).
Kartengrundlage: OpenStreetMap / CARTO. Die Kartenbibliothek Leaflet wird beim Öffnen von cdnjs geladen.

## Darstellung

- **Wetterhintergrund** der App: Einfarbig, Klassisch, Himmel, Stadt, Berge oder Halloween – animiert und passend zum aktuellen Wetter
- **Wetter-Icons**: Glanz, Flach, Zweiton, Papier, Linie – gelten für App und Widgets
- **Klappkarten** weiß oder schwarz, **Wetterleiste** grau, schwarz oder ohne

## Widgets

| Widget | Größe | Inhalt |
|---|---|---|
| Klappuhr mit Wetter | 4×2 | Stunden- und Minutenkarte, Wettersymbol, Ort, Zustand, Datum, Temperatur mit Max./Min. |
| Klappuhr mit Vorhersage | 4×3 | wie oben, dazu fünf Tage Vorhersage |
| Klappuhr mittel | 3×2 | wie 4×2, schmaler |
| Klappuhr kompakt | 4×1 | Klappkarten, Symbol, Temperatur, Ort, Datum |
| Wetter 5 Tage | 4×1 | Tagesvorhersage mit Symbol und Max./Min. |

Alle Widgets lassen sich in der Größe ändern. Tippen auf die Uhr öffnet den Wecker, Tippen aufs Wetter öffnet die App.

## Einstellungen

Ort (Suche oder ungefährer Standort), Temperatur °C/°F, Wind (km/h, m/s, mph, Knoten, Beaufort),
12/24 Stunden, Datum ein/aus, Deckkraft der Wetterleiste, Aktion beim Tippen auf die Uhr,
Aktualisierungsintervall (30 min bis 3 h), nur im WLAN aktualisieren.

## APK über GitHub bauen

1. Projekt in ein GitHub-Repository hochladen (Branch `main`).
2. Der Workflow **APK bauen** startet automatisch. Unter *Actions → letzter Lauf → Artifacts* liegt `Klappwetter-APK`.
3. ZIP entpacken, APK aufs Handy, installieren.

### Einmalig: eigener Signaturschlüssel (empfohlen)

Ohne eigenen Schlüssel bekommt jede APK einen anderen Debug-Schlüssel – ein Update geht dann nur nach
Deinstallation, und die Widgets müssen neu angelegt werden. So richtest du es einmal ein:

1. *Actions → Signaturschlüssel erzeugen (einmalig) → Run workflow*.
2. Im fertigen Lauf das Artifact herunterladen und entpacken. Es enthält zwei Textdateien.
3. *Settings → Secrets and variables → Actions → New repository secret*:
   - `SIGNING_KEYSTORE` = Inhalt von `SIGNING_KEYSTORE.txt`
   - `SIGNING_PASSWORD` = Inhalt von `SIGNING_PASSWORD.txt`
4. Beide Dateien sicher aufbewahren (z. B. Passwort-Manager) und das Artifact im Lauf löschen.

Ab dann sind alle Builds gleich signiert und lassen sich direkt drüberinstallieren.

## Version erhöhen

In `app/build.gradle.kts` `versionName` anpassen (kleine Änderungen als 1.0.x) und `versionCode` um 1 erhöhen.

## Tipps für Xiaomi / HyperOS

Damit die Widgets auch im Hintergrund aktuell bleiben: *Einstellungen der App → Aktualisierung im Hintergrund absichern*.
Dort Akku-Sparmodus auf **Keine Einschränkungen** und **Autostart** erlauben.

## Symbole anpassen

Die Wettersymbole werden erzeugt von `tools/gen_icons.py` (Set „Glanz“ und App-Icon)
und `tools/gen_icon_sets.py` (Flach, Zweiton, Papier, Linie).
