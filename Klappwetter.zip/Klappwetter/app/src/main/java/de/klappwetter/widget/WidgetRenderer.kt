package de.klappwetter.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.view.View
import android.widget.RemoteViews
import de.klappwetter.R
import de.klappwetter.data.AppSettings
import de.klappwetter.data.WeatherRepository
import de.klappwetter.data.WeatherSnapshot
import de.klappwetter.ui.MainActivity
import de.klappwetter.util.Units
import de.klappwetter.util.WeatherCodes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WidgetRenderer {

    enum class Kind(val layout: Int, val hasClock: Boolean, val hasForecast: Boolean) {
        LARGE(R.layout.widget_flip_large, true, false),
        MEDIUM(R.layout.widget_flip_medium, true, false),
        COMPACT(R.layout.widget_flip_compact, true, false),
        FORECAST(R.layout.widget_forecast, false, true),
        FORECAST_CLOCK(R.layout.widget_flip_forecast, true, true)
    }

    private val providers: List<Pair<Kind, Class<*>>> = listOf(
        Kind.LARGE to FlipWeatherWidget::class.java,
        Kind.MEDIUM to FlipMediumWidget::class.java,
        Kind.COMPACT to FlipCompactWidget::class.java,
        Kind.FORECAST to ForecastWidget::class.java,
        Kind.FORECAST_CLOCK to FlipForecastWidget::class.java
    )

    fun providerClass(kind: Kind): Class<*> = providers.first { it.first == kind }.second

    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context) ?: return
        val settings = AppSettings(context)
        val snapshot = WeatherRepository(context).cached()
        for ((kind, cls) in providers) {
            val ids = manager.getAppWidgetIds(ComponentName(context, cls))
            if (ids.isEmpty()) continue
            val views = build(context, kind, settings, snapshot)
            for (id in ids) manager.updateAppWidget(id, views)
        }
    }

    fun hasAnyWidget(context: Context): Boolean {
        val manager = AppWidgetManager.getInstance(context) ?: return false
        return providers.any { manager.getAppWidgetIds(ComponentName(context, it.second)).isNotEmpty() }
    }

    fun update(context: Context, manager: AppWidgetManager, ids: IntArray, kind: Kind) {
        val views = build(context, kind)
        for (id in ids) manager.updateAppWidget(id, views)
    }

    /** Auch für die Vorschau in der Widget-Übersicht der App */
    fun build(context: Context, kind: Kind): RemoteViews =
        build(context, kind, AppSettings(context), WeatherRepository(context).cached())

    private fun build(context: Context, kind: Kind, s: AppSettings, snap: WeatherSnapshot?): RemoteViews {
        val v = RemoteViews(context.packageName, kind.layout)
        applyBar(v, s)
        if (kind.hasClock) {
            applyClock(v, s)
            applyCards(v, s)
            v.setViewVisibility(R.id.date, if (s.showDate) View.VISIBLE else View.GONE)
            fillCurrent(v, s, snap)
            if (kind != Kind.COMPACT) {
                v.setTextViewText(
                    R.id.condition,
                    if (snap == null) context.getString(R.string.widget_tap_to_load)
                    else WeatherCodes.text(snap.current.weatherCode)
                )
            }
            val clock = clockIntent(context, s)
            v.setOnClickPendingIntent(R.id.card_hours, clock)
            v.setOnClickPendingIntent(R.id.card_minutes, clock)
        }
        if (kind.hasForecast) fillForecast(context, v, s, snap, kind == Kind.FORECAST)
        v.setOnClickPendingIntent(R.id.bar_area, appIntent(context))
        return v
    }

    // ------------------------------------------------------------------ Stil

    private fun applyBar(v: RemoteViews, s: AppSettings) {
        if (s.barStyle == "none") {
            v.setViewVisibility(R.id.bar_bg, View.GONE)
            return
        }
        v.setViewVisibility(R.id.bar_bg, View.VISIBLE)
        v.setImageViewResource(R.id.bar_bg, if (s.barStyle == "dark") R.drawable.bar_dark else R.drawable.bar_glass)
        v.setInt(R.id.bar_bg, "setImageAlpha", s.barAlpha)
    }

    private fun applyCards(v: RemoteViews, s: AppSettings) {
        val dark = s.cardStyle == "dark"
        val card = if (dark) R.drawable.flip_card_dark else R.drawable.flip_card
        val split = if (dark) R.drawable.flip_split_dark else R.drawable.flip_split
        val color = if (dark) 0xFFF2F2F2.toInt() else 0xFF1C1D1F.toInt()
        v.setInt(R.id.card_hours, "setBackgroundResource", card)
        v.setInt(R.id.card_minutes, "setBackgroundResource", card)
        v.setInt(R.id.split_hours, "setBackgroundResource", split)
        v.setInt(R.id.split_minutes, "setBackgroundResource", split)
        v.setTextColor(R.id.clock_hours, color)
        v.setTextColor(R.id.clock_minutes, color)
    }

    /** 12/24 h je nach Einstellung oder System */
    private fun applyClock(v: RemoteViews, s: AppSettings) {
        val hour24 = if (s.clockFormat == "12") "hh" else "HH"
        val hour12 = if (s.clockFormat == "24") "HH" else "hh"
        v.setCharSequence(R.id.clock_hours, "setFormat24Hour", hour24)
        v.setCharSequence(R.id.clock_hours, "setFormat12Hour", hour12)
    }

    // ------------------------------------------------------------------ Inhalte

    private fun fillCurrent(v: RemoteViews, s: AppSettings, snap: WeatherSnapshot?) {
        if (snap == null) {
            v.setTextViewText(R.id.location, s.location?.name?.takeIf { it.isNotBlank() } ?: "Ort wählen")
            v.setTextViewText(R.id.temp, "–°")
            v.setTextViewText(R.id.temp_max, "")
            v.setTextViewText(R.id.temp_min, "")
            v.setImageViewResource(R.id.icon, WeatherCodes.icon(2, true, s.iconSet))
            return
        }
        val now = System.currentTimeMillis()
        val today = snap.today(now)
        v.setTextViewText(R.id.location, snap.locationName)
        v.setTextViewText(R.id.temp, Units.temp(snap.current.temperature, s.tempUnit))
        v.setTextViewText(R.id.temp_max, today?.let { Units.temp(it.max, s.tempUnit) } ?: "")
        v.setTextViewText(R.id.temp_min, today?.let { Units.temp(it.min, s.tempUnit) } ?: "")
        v.setImageViewResource(R.id.icon, WeatherCodes.icon(snap.current.weatherCode, snap.isDayAt(now), s.iconSet))
    }

    private val colIds = intArrayOf(R.id.f_col_0, R.id.f_col_1, R.id.f_col_2, R.id.f_col_3, R.id.f_col_4)
    private val dayIds = intArrayOf(R.id.f_day_0, R.id.f_day_1, R.id.f_day_2, R.id.f_day_3, R.id.f_day_4)
    private val iconIds = intArrayOf(R.id.f_icon_0, R.id.f_icon_1, R.id.f_icon_2, R.id.f_icon_3, R.id.f_icon_4)
    private val maxIds = intArrayOf(R.id.f_max_0, R.id.f_max_1, R.id.f_max_2, R.id.f_max_3, R.id.f_max_4)
    private val minIds = intArrayOf(R.id.f_min_0, R.id.f_min_1, R.id.f_min_2, R.id.f_min_3, R.id.f_min_4)

    private fun fillForecast(context: Context, v: RemoteViews, s: AppSettings, snap: WeatherSnapshot?, hasEmpty: Boolean) {
        val now = System.currentTimeMillis()
        val days = snap?.forecastDays(now, 5).orEmpty()
        if (hasEmpty) v.setViewVisibility(R.id.empty, if (days.isEmpty()) View.VISIBLE else View.GONE)
        val dayFormat = SimpleDateFormat("EE", Locale.GERMANY).apply { snap?.let { timeZone = it.tz } }
        for (i in colIds.indices) {
            val d = days.getOrNull(i)
            if (d == null) {
                v.setViewVisibility(colIds[i], if (hasEmpty) View.GONE else View.INVISIBLE)
                continue
            }
            v.setViewVisibility(colIds[i], View.VISIBLE)
            v.setTextViewText(dayIds[i], if (i == 0) context.getString(R.string.today) else dayFormat.format(Date(d.time)))
            v.setImageViewResource(iconIds[i], WeatherCodes.icon(d.weatherCode, true, s.iconSet))
            v.setTextViewText(maxIds[i], Units.temp(d.max, s.tempUnit))
            v.setTextViewText(minIds[i], Units.temp(d.min, s.tempUnit))
        }
    }

    // ------------------------------------------------------------------ Tippen

    private fun clockIntent(context: Context, s: AppSettings): PendingIntent {
        if (s.clockTapOpensAlarm) {
            val alarm = Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (alarm.resolveActivity(context.packageManager) != null) {
                return PendingIntent.getActivity(
                    context, 10, alarm, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }
        }
        return appIntent(context)
    }

    private fun appIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            context, 11, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
