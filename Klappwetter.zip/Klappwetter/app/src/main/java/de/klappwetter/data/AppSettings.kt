package de.klappwetter.data

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

data class SavedLocation(val name: String, val lat: Double, val lon: Double)

/**
 * Zugriff auf alle Einstellungen.
 * Benutzer-Einstellungen liegen in den Standard-Preferences (Einstellungsseite),
 * Wetter-Cache und interne Merker in einer eigenen Datei.
 */
class AppSettings(context: Context) {

    private val app = context.applicationContext
    private val user: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(app)
    private val data: SharedPreferences = app.getSharedPreferences("klappwetter_data", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- Benutzer
    var useGps: Boolean
        get() = user.getBoolean(KEY_USE_GPS, false)
        set(value) {
            user.edit().putBoolean(KEY_USE_GPS, value).apply()
        }

    val tempUnit: String get() = user.getString(KEY_TEMP_UNIT, "c") ?: "c"
    val windUnit: String get() = user.getString(KEY_WIND_UNIT, "kmh") ?: "kmh"
    val clockFormat: String get() = user.getString(KEY_CLOCK_FORMAT, "system") ?: "system"
    val showDate: Boolean get() = user.getBoolean(KEY_SHOW_DATE, true)

    /** Deckkraft der Wetterleiste als Alpha-Wert 0..255 */
    val barAlpha: Int get() = user.getInt(KEY_BAR_OPACITY, 80).coerceIn(0, 100) * 255 / 100

    val clockTapOpensAlarm: Boolean get() = user.getString(KEY_CLOCK_TAP, "alarm") == "alarm"
    val intervalMinutes: Int get() = user.getString(KEY_INTERVAL, "60")?.toIntOrNull() ?: 60
    val wifiOnly: Boolean get() = user.getBoolean(KEY_WIFI_ONLY, false)

    /** "light" = weiße Klappkarten, "dark" = schwarze Klappkarten */
    val cardStyle: String get() = user.getString(KEY_CARD_STYLE, "light") ?: "light"

    /** "grey", "dark" oder "none" */
    val barStyle: String get() = user.getString(KEY_BAR_STYLE, "grey") ?: "grey"

    var iconSet: String
        get() = user.getString(KEY_ICON_SET, "glanz") ?: "glanz"
        set(value) {
            user.edit().putString(KEY_ICON_SET, value).apply()
        }

    val provider: String get() = user.getString(KEY_PROVIDER, "openmeteo") ?: "openmeteo"
    val owmKey: String get() = user.getString(KEY_OWM_KEY, "") ?: ""

    var background: String
        get() = user.getString(KEY_BACKGROUND, "animated") ?: "animated"
        set(value) {
            user.edit().putString(KEY_BACKGROUND, value).apply()
        }

    // ---------------------------------------------------------------- Intern
    var location: SavedLocation?
        get() {
            val lat = data.getString(KEY_LAT, null)?.toDoubleOrNull() ?: return null
            val lon = data.getString(KEY_LON, null)?.toDoubleOrNull() ?: return null
            return SavedLocation(data.getString(KEY_NAME, null) ?: "", lat, lon)
        }
        set(value) {
            val e = data.edit()
            if (value == null) {
                e.remove(KEY_LAT).remove(KEY_LON).remove(KEY_NAME)
            } else {
                e.putString(KEY_LAT, value.lat.toString())
                    .putString(KEY_LON, value.lon.toString())
                    .putString(KEY_NAME, value.name)
            }
            e.apply()
        }

    var cacheJson: String?
        get() = data.getString(KEY_CACHE, null)
        set(value) {
            data.edit().putString(KEY_CACHE, value).apply()
        }

    /** Wird gesetzt, wenn sich der Ort geändert hat und neu geladen werden muss. */
    var needsRefresh: Boolean
        get() = data.getBoolean(KEY_NEEDS_REFRESH, false)
        set(value) {
            data.edit().putBoolean(KEY_NEEDS_REFRESH, value).apply()
        }

    var lastRefreshRequest: Long
        get() = data.getLong(KEY_LAST_REQUEST, 0L)
        set(value) {
            data.edit().putLong(KEY_LAST_REQUEST, value).apply()
        }

    companion object {
        const val KEY_USE_GPS = "use_gps"
        const val KEY_TEMP_UNIT = "temp_unit"
        const val KEY_WIND_UNIT = "wind_unit"
        const val KEY_CLOCK_FORMAT = "clock_format"
        const val KEY_SHOW_DATE = "show_date"
        const val KEY_BAR_OPACITY = "bar_opacity"
        const val KEY_CLOCK_TAP = "clock_tap"
        const val KEY_INTERVAL = "update_interval"
        const val KEY_WIFI_ONLY = "wifi_only"
        const val KEY_CARD_STYLE = "card_style"
        const val KEY_BAR_STYLE = "bar_style"
        const val KEY_ICON_SET = "icon_set"
        const val KEY_BACKGROUND = "background"
        const val KEY_PROVIDER = "provider"
        const val KEY_OWM_KEY = "owm_key"

        private const val KEY_LAT = "loc_lat"
        private const val KEY_LON = "loc_lon"
        private const val KEY_NAME = "loc_name"
        private const val KEY_CACHE = "weather_cache"
        private const val KEY_NEEDS_REFRESH = "needs_refresh"
        private const val KEY_LAST_REQUEST = "last_refresh_request"
    }
}
