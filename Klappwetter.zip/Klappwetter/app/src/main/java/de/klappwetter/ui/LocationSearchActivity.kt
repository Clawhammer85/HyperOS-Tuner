package de.klappwetter.ui

import android.Manifest
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.klappwetter.R
import de.klappwetter.data.AppSettings
import de.klappwetter.data.Place
import de.klappwetter.data.SavedLocation
import de.klappwetter.data.WeatherApi
import de.klappwetter.util.LocationHelper
import de.klappwetter.widget.WidgetRenderer
import de.klappwetter.work.RefreshWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LocationSearchActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var adapter: ArrayAdapter<Place>
    private val places = mutableListOf<Place>()
    private var searchJob: Job? = null

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) useCurrentLocation()
            else Toast.makeText(this, R.string.gps_denied, Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_search)

        input = findViewById(R.id.search_input)
        status = findViewById(R.id.search_status)
        val list = findViewById<ListView>(R.id.search_results)

        adapter = object : ArrayAdapter<Place>(this, R.layout.item_place, R.id.place_name, places) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val place = getItem(position) ?: return view
                view.findViewById<TextView>(R.id.place_name).text = place.name
                view.findViewById<TextView>(R.id.place_detail).text = place.detail
                return view
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> select(places[position]) }

        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<Button>(R.id.btn_search).setOnClickListener { search() }
        findViewById<Button>(R.id.btn_gps).setOnClickListener {
            if (LocationHelper.hasPermission(this)) useCurrentLocation()
            else locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                search()
                true
            } else {
                false
            }
        }
    }

    private fun search() {
        val query = input.text.toString().trim()
        if (query.length < 2) {
            status.setText(R.string.search_too_short)
            return
        }
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(input.windowToken, 0)
        status.setText(R.string.searching)
        searchJob?.cancel()
        searchJob = lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { WeatherApi.searchPlaces(query) } }
            result.onSuccess { found ->
                places.clear()
                places.addAll(found)
                adapter.notifyDataSetChanged()
                status.text = if (found.isEmpty()) getString(R.string.search_empty) else ""
            }.onFailure {
                status.setText(R.string.search_failed)
            }
        }
    }

    private fun select(place: Place) {
        val settings = AppSettings(this)
        settings.location = SavedLocation(place.name, place.lat, place.lon)
        settings.useGps = false
        settings.needsRefresh = true
        WidgetRenderer.updateAll(this)
        RefreshWorker.refreshNow(this)
        finish()
    }

    private fun useCurrentLocation() {
        val settings = AppSettings(this)
        settings.useGps = true
        settings.needsRefresh = true
        RefreshWorker.refreshNow(this)
        finish()
    }
}
