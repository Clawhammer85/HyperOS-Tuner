package de.klappwetter.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.TimeZone
import kotlin.math.roundToInt

data class CurrentWeather(
    val time: Long,
    val temperature: Double,
    val apparent: Double,
    val humidity: Int,
    val dewPoint: Double,
    val weatherCode: Int,
    val isDay: Boolean,
    val pressure: Double,
    val windSpeed: Double,
    val windDirection: Int,
    val visibility: Double,
    val uvIndex: Double,
    val cloudCover: Int
)

data class HourlyEntry(
    val time: Long,
    val temperature: Double,
    val weatherCode: Int,
    val precipProb: Int,
    val isDay: Boolean
)

data class DailyEntry(
    val time: Long,
    val weatherCode: Int,
    val max: Double,
    val min: Double,
    val precipProb: Int,
    val sunrise: Long,
    val sunset: Long,
    val uvMax: Double
)

data class WeatherSnapshot(
    val locationName: String,
    val provider: String,
    val fetchedAt: Long,
    val timezone: String,
    val current: CurrentWeather,
    val hourly: List<HourlyEntry>,
    val daily: List<DailyEntry>
) {
    val tz: TimeZone get() = TimeZone.getTimeZone(timezone.ifBlank { "GMT" })

    private fun todayIndex(now: Long): Int = daily.indexOfLast { it.time <= now }.coerceAtLeast(0)

    fun today(now: Long): DailyEntry? = daily.getOrNull(todayIndex(now))

    /** Tag/Nacht anhand von Sonnenauf- und -untergang – stimmt auch zwischen zwei Abrufen. */
    fun isDayAt(now: Long): Boolean {
        val d = today(now) ?: return current.isDay
        if (d.sunrise <= 0L || d.sunset <= 0L) return current.isDay
        return now in d.sunrise until d.sunset
    }

    private fun hourIndex(now: Long): Int = hourly.indexOfLast { it.time <= now }

    fun precipProbNow(now: Long): Int? =
        hourly.getOrNull(hourIndex(now))?.precipProb?.takeIf { it >= 0 }

    fun nextHours(now: Long, count: Int): List<HourlyEntry> =
        hourly.drop(hourIndex(now).coerceAtLeast(0)).take(count)

    fun forecastDays(now: Long, count: Int): List<DailyEntry> =
        daily.drop(todayIndex(now)).take(count)
}

object WeatherParser {

    /** Liest den Cache-Eintrag {name, fetchedAt, raw} – raw ist die Open-Meteo-Antwort. */
    fun parse(cache: JSONObject): WeatherSnapshot? = try {
        val raw = cache.getJSONObject("raw")
        val cur = raw.getJSONObject("current")
        val current = CurrentWeather(
            time = cur.optLong("time") * 1000L,
            temperature = cur.optDouble("temperature_2m"),
            apparent = cur.optDouble("apparent_temperature"),
            humidity = cur.optDouble("relative_humidity_2m").let { if (it.isNaN()) -1 else it.roundToInt() },
            dewPoint = cur.optDouble("dew_point_2m"),
            weatherCode = cur.optInt("weather_code", -1),
            isDay = cur.optInt("is_day", 1) == 1,
            pressure = cur.optDouble("pressure_msl"),
            windSpeed = cur.optDouble("wind_speed_10m"),
            windDirection = cur.optDouble("wind_direction_10m").let { if (it.isNaN()) 0 else it.roundToInt() },
            visibility = cur.optDouble("visibility"),
            uvIndex = cur.optDouble("uv_index"),
            cloudCover = cur.optDouble("cloud_cover").let { if (it.isNaN()) -1 else it.roundToInt() }
        )

        val hourly = mutableListOf<HourlyEntry>()
        raw.optJSONObject("hourly")?.let { h ->
            val time = h.optJSONArray("time") ?: JSONArray()
            val temp = h.optJSONArray("temperature_2m")
            val code = h.optJSONArray("weather_code")
            val prob = h.optJSONArray("precipitation_probability")
            val day = h.optJSONArray("is_day")
            for (i in 0 until time.length()) {
                hourly += HourlyEntry(
                    time = time.optLong(i) * 1000L,
                    temperature = temp?.optDouble(i) ?: Double.NaN,
                    weatherCode = code?.optInt(i, -1) ?: -1,
                    precipProb = prob?.optInt(i, -1) ?: -1,
                    isDay = (day?.optInt(i, 1) ?: 1) == 1
                )
            }
        }

        val daily = mutableListOf<DailyEntry>()
        raw.optJSONObject("daily")?.let { d ->
            val time = d.optJSONArray("time") ?: JSONArray()
            val code = d.optJSONArray("weather_code")
            val max = d.optJSONArray("temperature_2m_max")
            val min = d.optJSONArray("temperature_2m_min")
            val prob = d.optJSONArray("precipitation_probability_max")
            val rise = d.optJSONArray("sunrise")
            val set = d.optJSONArray("sunset")
            val uv = d.optJSONArray("uv_index_max")
            for (i in 0 until time.length()) {
                daily += DailyEntry(
                    time = time.optLong(i) * 1000L,
                    weatherCode = code?.optInt(i, -1) ?: -1,
                    max = max?.optDouble(i) ?: Double.NaN,
                    min = min?.optDouble(i) ?: Double.NaN,
                    precipProb = prob?.optInt(i, -1) ?: -1,
                    sunrise = (rise?.optLong(i) ?: 0L) * 1000L,
                    sunset = (set?.optLong(i) ?: 0L) * 1000L,
                    uvMax = uv?.optDouble(i) ?: Double.NaN
                )
            }
        }

        WeatherSnapshot(
            locationName = cache.optString("name"),
            provider = cache.optString("provider", "openmeteo"),
            fetchedAt = cache.optLong("fetchedAt"),
            timezone = raw.optString("timezone"),
            current = current,
            hourly = hourly,
            daily = daily
        )
    } catch (e: Exception) {
        null
    }
}
