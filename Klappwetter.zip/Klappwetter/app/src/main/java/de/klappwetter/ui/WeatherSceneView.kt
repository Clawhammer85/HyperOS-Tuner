package de.klappwetter.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import de.klappwetter.util.Sky
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Wetterhintergrund, komplett gezeichnet – keine Bilddateien.
 * Themen: plain (einfarbig), classic (Standbild), animated (Himmel),
 * city (Stadt), landscape (Berge), halloween.
 */
class WeatherSceneView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        val THEMES = listOf("plain", "classic", "animated", "city", "landscape", "halloween")

        fun title(theme: String): String = when (theme) {
            "plain" -> "Einfarbig"
            "classic" -> "Klassisch"
            "city" -> "Stadt, animiert"
            "landscape" -> "Berge, animiert"
            "halloween" -> "Halloween, animiert"
            else -> "Himmel, animiert"
        }

        /** Beispielwetter für die Vorschau in der Auswahl */
        fun sample(theme: String): Triple<Sky, Boolean, String> = when (theme) {
            "classic" -> Triple(Sky.CLEAR, true, "")
            "city" -> Triple(Sky.RAIN, true, "")
            "landscape" -> Triple(Sky.SNOW, true, "")
            "halloween" -> Triple(Sky.PARTLY, false, "")
            "plain" -> Triple(Sky.CLEAR, true, "")
            else -> Triple(Sky.PARTLY, true, "")
        }

        private const val WIND = 0.18f
    }

    private var themeKey = "animated"
    private var sky = Sky.CLEAR
    private var day = true
    private var built = false

    /** false = nur ein Standbild */
    var live: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    /** Abdunkeln, damit Text darüber lesbar bleibt */
    var scrim: Boolean = false
        set(value) {
            field = value
            rebuild()
        }

    fun show(theme: String, sky: Sky, isDay: Boolean) {
        if (built && theme == themeKey && sky == this.sky && isDay == day) return
        themeKey = theme
        this.sky = sky
        day = isDay
        rebuild()
    }

    private val dp = resources.displayMetrics.density
    private var rnd = Random(7)
    private var t = 0f
    private var lastNanos = 0L

    // Farben und Pinsel
    private val skyPaint = Paint()
    private val scrimPaint = Paint()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x14FFFFFF }
    private val lampGlow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mistPaint = Paint()
    private val tmp = RectF()

    // Himmelskörper
    private var orb = 0 // 0 keiner, 1 Sonne, 2 Mond, 3 großer Mond
    private var sunX = 0f
    private var sunY = 0f
    private var sunR = 0f
    private val rays = Path()
    private val craters = floatArrayOf(-0.3f, -0.2f, 0.18f, 0.25f, 0.1f, 0.12f, -0.05f, 0.38f, 0.1f, 0.35f, -0.35f, 0.08f)

    // Teilchen
    private var stars = FloatArray(0)   // x, y, r, phase
    private var drops = FloatArray(0)   // x, y, länge, tempo
    private var lines = FloatArray(0)
    private var flakes = FloatArray(0)  // x, y, r, tempo, phase
    private val fogs = ArrayList<FloatArray>() // x, y, b, h, tempo, alpha

    private class Cloud(var x: Float, val y: Float, val puffs: FloatArray, val width: Float, val speed: Float)
    private val clouds = ArrayList<Cloud>()

    // Gewitter
    private var flash = 0f
    private var nextFlash = 3f
    private val bolt = Path()

    // Klassisch
    private val hill = Path()
    private val hillFar = Path()

    // Landschaft
    private val far = Path()
    private val mid = Path()
    private val near = Path()
    private val snowFar = Path()
    private val snowMid = Path()
    private val pines = Path()

    // Stadt
    private val buildingsFar = ArrayList<RectF>()
    private val buildingsNear = ArrayList<RectF>()
    private val windows = ArrayList<RectF>()
    private var lit = BooleanArray(0)
    private var horizon = 0f
    private var carX = 0f
    private var carW = 0f
    private var carH = 0f
    private var carY = 0f
    private val carCabin = Path()
    private val carWindows = Path()
    private val carBeam = Path()

    // Halloween
    private val ground = Path()
    private val branches = ArrayList<FloatArray>() // x1, y1, x2, y2, breite
    private val graves = ArrayList<FloatArray>()   // typ, x, breite, höhe, boden
    private val pumpkins = ArrayList<FloatArray>() // x, y, r
    private val batPath = Path()
    private val facePath = Path()

    private fun c(v: Long): Int = v.toInt()

    // ================================================================= Aufbau

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            lastNanos = 0L
            invalidate()
        }
    }

    private fun rebuild() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) {
            built = false
            return
        }
        rnd = Random(themeKey.hashCode() * 31 + sky.ordinal * 7 + (if (day) 1 else 0))
        t = 0f
        lastNanos = 0L

        if (themeKey == "plain") {
            skyPaint.shader = null
            skyPaint.color = c(0xFF0E1726)
        } else {
            skyPaint.shader = LinearGradient(0f, 0f, 0f, h, skyColors(), null, Shader.TileMode.CLAMP)
        }
        scrimPaint.shader = if (scrim) {
            LinearGradient(0f, 0f, 0f, h, c(0x40000000), c(0xB3000000), Shader.TileMode.CLAMP)
        } else {
            null
        }

        val heavy = sky == Sky.CLOUDY || sky == Sky.RAIN || sky == Sky.THUNDER || sky == Sky.SNOW
        buildOrb(w, h)
        buildStars(w, h)
        buildClouds(w, h, heavy)
        buildPrecipitation(w, h)
        buildFog(w, h)
        when (themeKey) {
            "classic" -> buildClassic(w, h)
            "landscape" -> buildLandscape(w, h)
            "city" -> buildCity(w, h)
            "halloween" -> buildHalloween(w, h)
        }
        flash = 0f
        nextFlash = 2f + rnd.nextFloat() * 4f
        built = true
        invalidate()
    }

    private fun skyColors(): IntArray = when {
        themeKey == "halloween" -> intArrayOf(c(0xFF1E0F33), c(0xFF46285E), c(0xFF7A4E86))
        !day -> when (sky) {
            Sky.CLEAR, Sky.PARTLY -> intArrayOf(c(0xFF060B1F), c(0xFF132048), c(0xFF2A3A6E))
            Sky.FOG -> intArrayOf(c(0xFF1E2430), c(0xFF3A414E), c(0xFF555C68))
            else -> intArrayOf(c(0xFF0F141E), c(0xFF222A38), c(0xFF384150))
        }
        else -> when (sky) {
            Sky.CLEAR -> intArrayOf(c(0xFF1565C0), c(0xFF3E8EDE), c(0xFF9BCCF4))
            Sky.PARTLY -> intArrayOf(c(0xFF2668B0), c(0xFF5596D6), c(0xFFAACDEB))
            Sky.CLOUDY -> intArrayOf(c(0xFF5D6D82), c(0xFF8494A8), c(0xFFB4C0CC))
            Sky.FOG -> intArrayOf(c(0xFF939CA7), c(0xFFB5BCC4), c(0xFFD5DADF))
            Sky.RAIN -> intArrayOf(c(0xFF3B4859), c(0xFF5C697B), c(0xFF8692A1))
            Sky.SNOW -> intArrayOf(c(0xFF76869A), c(0xFFA0ADBC), c(0xFFD3DAE2))
            Sky.THUNDER -> intArrayOf(c(0xFF20262F), c(0xFF394252), c(0xFF5A6475))
        }
    }

    private fun buildOrb(w: Float, h: Float) {
        val m = min(w, h)
        val clear = sky == Sky.CLEAR || sky == Sky.PARTLY
        orb = when {
            themeKey == "plain" -> 0
            themeKey == "halloween" -> 3
            !clear -> 0
            day -> 1
            else -> 2
        }
        if (orb == 3) {
            sunX = w * 0.62f
            sunY = h * 0.62f
            sunR = m * 0.3f
        } else {
            sunX = w * 0.78f
            sunY = h * 0.17f
            sunR = (m * 0.075f).coerceIn(12f * dp, 46f * dp)
        }
        when (orb) {
            1 -> {
                glowPaint.shader = RadialGradient(
                    sunX, sunY, sunR * 3.2f,
                    intArrayOf(c(0x99FFE082), c(0x33FFC107), 0), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
                )
                orbPaint.shader = RadialGradient(
                    sunX - sunR * 0.3f, sunY - sunR * 0.35f, sunR * 1.4f,
                    intArrayOf(c(0xFFFFF8C4), c(0xFFFFCA28), c(0xFFF57C00)), floatArrayOf(0f, 0.55f, 1f),
                    Shader.TileMode.CLAMP
                )
                rays.reset()
                val len = max(w, h)
                for (i in 0 until 12) {
                    val a = i * PI.toFloat() / 6f
                    rays.moveTo(sunX, sunY)
                    rays.lineTo(sunX + cos(a - 0.05f) * len, sunY + sin(a - 0.05f) * len)
                    rays.lineTo(sunX + cos(a + 0.05f) * len, sunY + sin(a + 0.05f) * len)
                    rays.close()
                }
            }
            2, 3 -> {
                glowPaint.shader = RadialGradient(
                    sunX, sunY, sunR * (if (orb == 3) 1.7f else 3f),
                    intArrayOf(c(0x66FFF8E1), c(0x22FFF8E1), 0), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                )
                orbPaint.shader = RadialGradient(
                    sunX - sunR * 0.25f, sunY - sunR * 0.3f, sunR * 1.3f,
                    intArrayOf(c(0xFFFFFDF2), c(0xFFF1EBCF), c(0xFFD6CDA8)), floatArrayOf(0f, 0.6f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }
    }

    private fun buildStars(w: Float, h: Float) {
        val visible = when {
            themeKey == "plain" -> false
            themeKey == "halloween" -> sky == Sky.CLEAR || sky == Sky.PARTLY || sky == Sky.CLOUDY
            else -> !day && (sky == Sky.CLEAR || sky == Sky.PARTLY)
        }
        val n = if (visible) (w * h / (dp * dp) / 2200f).toInt().coerceIn(12, 180) else 0
        stars = FloatArray(n * 4)
        for (i in 0 until n) {
            stars[i * 4] = rnd.nextFloat() * w
            stars[i * 4 + 1] = rnd.nextFloat() * h * 0.7f
            stars[i * 4 + 2] = (0.5f + rnd.nextFloat() * 1.1f) * dp
            stars[i * 4 + 3] = rnd.nextFloat() * 6.28f
        }
    }

    private fun buildClouds(w: Float, h: Float, heavy: Boolean) {
        clouds.clear()
        if (themeKey == "plain") return
        val count = when (sky) {
            Sky.CLEAR -> 2
            Sky.PARTLY -> 4
            Sky.FOG -> 3
            Sky.CLOUDY, Sky.SNOW -> 7
            Sky.RAIN -> 8
            Sky.THUNDER -> 9
        }
        for (i in 0 until count) {
            val cw = w * (if (heavy) 0.35f + rnd.nextFloat() * 0.35f else 0.18f + rnd.nextFloat() * 0.2f)
            val y = h * (if (heavy) 0.03f + rnd.nextFloat() * 0.3f else 0.07f + rnd.nextFloat() * 0.27f)
            val speed = (5f + rnd.nextFloat() * 12f) * dp * (if (sky == Sky.THUNDER) 2f else 1f)
            clouds += Cloud(rnd.nextFloat() * (w + cw) - cw, y, puffs(cw), cw, speed)
        }
        clouds.sortBy { it.width }
    }

    private fun puffs(cw: Float): FloatArray {
        val n = 5 + rnd.nextInt(3)
        val out = FloatArray(n * 3)
        for (i in 0 until n) {
            val fx = 0.12f + 0.76f * i / (n - 1)
            val hump = sin(fx * PI.toFloat())
            out[i * 3] = fx * cw
            out[i * 3 + 1] = -hump * cw * (0.08f + rnd.nextFloat() * 0.1f)
            out[i * 3 + 2] = cw * (0.1f + hump * 0.1f + rnd.nextFloat() * 0.05f)
        }
        return out
    }

    private fun buildPrecipitation(w: Float, h: Float) {
        val area = w * h / (dp * dp)
        drops = FloatArray(0)
        flakes = FloatArray(0)
        if (themeKey == "plain") return
        if (sky == Sky.RAIN || sky == Sky.THUNDER) {
            val n = (area / (if (sky == Sky.THUNDER) 650f else 850f)).toInt().coerceIn(20, 320)
            drops = FloatArray(n * 4)
            for (i in 0 until n) {
                drops[i * 4] = rnd.nextFloat() * w
                drops[i * 4 + 1] = rnd.nextFloat() * h
                drops[i * 4 + 2] = (10f + rnd.nextFloat() * 14f) * dp
                drops[i * 4 + 3] = (650f + rnd.nextFloat() * 350f) * dp
            }
        }
        lines = FloatArray(drops.size)
        if (sky == Sky.SNOW) {
            val n = (area / 1300f).toInt().coerceIn(18, 200)
            flakes = FloatArray(n * 5)
            for (i in 0 until n) {
                flakes[i * 5] = rnd.nextFloat() * w
                flakes[i * 5 + 1] = rnd.nextFloat() * h
                flakes[i * 5 + 2] = (1.2f + rnd.nextFloat() * 2.4f) * dp
                flakes[i * 5 + 3] = (25f + rnd.nextFloat() * 45f) * dp
                flakes[i * 5 + 4] = rnd.nextFloat() * 6.28f
            }
        }
    }

    private fun buildFog(w: Float, h: Float) {
        fogs.clear()
        if (sky != Sky.FOG || themeKey == "plain") return
        for (i in 0 until 6) {
            fogs += floatArrayOf(
                rnd.nextFloat() * w, h * (0.35f + rnd.nextFloat() * 0.6f),
                w * (0.7f + rnd.nextFloat() * 0.5f), h * (0.08f + rnd.nextFloat() * 0.08f),
                (8f + rnd.nextFloat() * 10f) * dp, 40f + rnd.nextFloat() * 35f
            )
        }
    }

    private fun buildClassic(w: Float, h: Float) {
        hillFar.reset()
        hillFar.moveTo(0f, h * 0.8f)
        hillFar.quadTo(w * 0.3f, h * 0.74f, w * 0.65f, h * 0.8f)
        hillFar.quadTo(w * 0.85f, h * 0.83f, w, h * 0.78f)
        hillFar.lineTo(w, h)
        hillFar.lineTo(0f, h)
        hillFar.close()
        hill.reset()
        hill.moveTo(0f, h * 0.88f)
        hill.quadTo(w * 0.45f, h * 0.79f, w, h * 0.87f)
        hill.lineTo(w, h)
        hill.lineTo(0f, h)
        hill.close()
    }

    /** Bergkamm aus überlagerten Sinuswellen – spitze Gipfel, breite Täler */
    private fun ridge(path: Path, baseY: Float, amp: Float, peaks: Float, w: Float, h: Float) {
        val p1 = rnd.nextFloat() * 6.28f
        val p2 = rnd.nextFloat() * 6.28f
        val p3 = rnd.nextFloat() * 6.28f
        val tau = 2f * PI.toFloat()
        path.reset()
        path.moveTo(0f, h)
        val steps = 60
        for (i in 0..steps) {
            val x = i / steps.toFloat()
            val n = 0.55f * sin(x * peaks * tau + p1) + 0.3f * sin(x * peaks * 2.3f * tau + p2) +
                0.15f * sin(x * peaks * 5.1f * tau + p3)
            val v = ((n + 1f) / 2f).coerceIn(0f, 1f)
            path.lineTo(x * w, baseY - amp * Math.pow(v.toDouble(), 1.6).toFloat())
        }
        path.lineTo(w, h)
        path.close()
    }

    private fun snowLine(path: Path, y: Float, w: Float, h: Float) {
        path.reset()
        path.moveTo(0f, 0f)
        path.lineTo(w, 0f)
        val steps = 16
        for (i in steps downTo 0) {
            path.lineTo(i * w / steps, y + (rnd.nextFloat() - 0.5f) * h * 0.05f)
        }
        path.close()
    }

    private fun buildLandscape(w: Float, h: Float) {
        ridge(far, h * 0.6f, h * 0.32f, 1.3f, w, h)
        ridge(mid, h * 0.76f, h * 0.22f, 2f, w, h)
        ridge(near, h * 0.9f, h * 0.12f, 3.2f, w, h)
        snowLine(snowFar, h * 0.45f, w, h)
        snowLine(snowMid, h * 0.62f, w, h)
        pines.reset()
        val n = (w / (26f * dp)).toInt().coerceIn(6, 30)
        for (i in 0 until n) {
            val x = rnd.nextFloat() * w
            val ph = h * (0.1f + rnd.nextFloat() * 0.1f)
            val pw = ph * 0.42f
            val top = h - ph
            for ((dy, spread, depth) in listOf(Triple(0f, 0.35f, 0.38f), Triple(0.18f, 0.42f, 0.62f), Triple(0.38f, 0.5f, 0.86f))) {
                pines.moveTo(x, top + ph * dy)
                pines.lineTo(x + pw * spread, top + ph * depth)
                pines.lineTo(x - pw * spread, top + ph * depth)
                pines.close()
            }
            pines.addRect(x - pw * 0.06f, top + ph * 0.84f, x + pw * 0.06f, h, Path.Direction.CW)
        }
    }

    private fun buildCity(w: Float, h: Float) {
        horizon = h * 0.72f
        buildingsFar.clear()
        buildingsNear.clear()
        windows.clear()
        var x = -rnd.nextFloat() * w * 0.05f
        while (x < w) {
            val bw = w * (0.05f + rnd.nextFloat() * 0.06f)
            val bh = h * (0.16f + rnd.nextFloat() * 0.24f)
            buildingsFar += RectF(x, horizon - bh, x + bw, horizon)
            x += bw + w * 0.004f
        }
        x = -rnd.nextFloat() * w * 0.05f
        while (x < w) {
            val bw = w * (0.07f + rnd.nextFloat() * 0.07f)
            val bh = h * (0.08f + rnd.nextFloat() * 0.2f)
            val b = RectF(x, horizon - bh, x + bw, horizon)
            buildingsNear += b
            val ww = max(1.5f * dp, bw * 0.12f)
            val wh = ww * 1.3f
            val cols = ((bw - ww) / (ww * 2f)).toInt()
            val rows = ((bh - wh * 2f) / (wh * 2f)).toInt()
            for (cIdx in 0 until cols) {
                for (r in 0 until rows) {
                    val l = b.left + ww * 0.75f + cIdx * ww * 2f
                    val tp = b.top + wh + r * wh * 2f
                    windows += RectF(l, tp, l + ww, tp + wh)
                }
            }
            x += bw + w * 0.012f
        }
        lit = BooleanArray(windows.size) { rnd.nextFloat() < 0.4f }

        carW = min(w * 0.26f, 160f * dp)
        carH = carW * 0.36f
        carY = horizon + (h - horizon) * 0.58f
        carX = rnd.nextFloat() * w
        carCabin.reset()
        carCabin.moveTo(carW * 0.2f, -carH * 0.6f)
        carCabin.lineTo(carW * 0.33f, -carH)
        carCabin.lineTo(carW * 0.7f, -carH)
        carCabin.lineTo(carW * 0.85f, -carH * 0.6f)
        carCabin.close()
        carWindows.reset()
        carWindows.moveTo(carW * 0.26f, -carH * 0.62f)
        carWindows.lineTo(carW * 0.36f, -carH * 0.92f)
        carWindows.lineTo(carW * 0.51f, -carH * 0.92f)
        carWindows.lineTo(carW * 0.51f, -carH * 0.62f)
        carWindows.close()
        carWindows.moveTo(carW * 0.54f, -carH * 0.62f)
        carWindows.lineTo(carW * 0.54f, -carH * 0.92f)
        carWindows.lineTo(carW * 0.68f, -carH * 0.92f)
        carWindows.lineTo(carW * 0.79f, -carH * 0.62f)
        carWindows.close()
        carBeam.reset()
        carBeam.moveTo(carW * 0.98f, -carH * 0.42f)
        carBeam.lineTo(carW * 1.9f, -carH * 0.7f)
        carBeam.lineTo(carW * 1.9f, carH * 0.1f)
        carBeam.close()
        lampGlow.shader = RadialGradient(
            0f, 0f, w * 0.1f, intArrayOf(c(0x88FFD27F), 0), null, Shader.TileMode.CLAMP
        )
    }

    private fun buildHalloween(w: Float, h: Float) {
        ground.reset()
        ground.moveTo(0f, h * 0.87f)
        ground.quadTo(w * 0.3f, h * 0.82f, w * 0.6f, h * 0.86f)
        ground.quadTo(w * 0.85f, h * 0.9f, w, h * 0.85f)
        ground.lineTo(w, h)
        ground.lineTo(0f, h)
        ground.close()
        graves.clear()
        for (k in 0 until 7) {
            graves += floatArrayOf(
                rnd.nextInt(2).toFloat(), w * (0.3f + k * 0.1f + rnd.nextFloat() * 0.03f),
                w * (0.035f + rnd.nextFloat() * 0.02f), h * (0.06f + rnd.nextFloat() * 0.04f), h * 0.875f
            )
        }
        branches.clear()
        branch(w * 0.16f, h * 0.92f, -PI.toFloat() / 2f - 0.08f, h * 0.2f, max(w * 0.045f, 6f * dp), 6)
        pumpkins.clear()
        pumpkins += floatArrayOf(w * 0.6f, h * 0.885f, w * 0.04f)
        pumpkins += floatArrayOf(w * 0.86f, h * 0.9f, w * 0.032f)
        batPath.reset()
        batPath.moveTo(0f, -0.15f)
        val wing = floatArrayOf(0.25f, -0.25f, 0.55f, -0.45f, 1f, -0.3f, 0.8f, -0.05f, 0.62f, 0.02f, 0.45f, -0.05f, 0.3f, 0.05f, 0.12f, 0.2f)
        var i = 0
        while (i < wing.size) {
            batPath.lineTo(wing[i], wing[i + 1])
            i += 2
        }
        batPath.lineTo(0f, 0.12f)
        i = wing.size - 2
        while (i >= 0) {
            batPath.lineTo(-wing[i], wing[i + 1])
            i -= 2
        }
        batPath.close()
        mistPaint.shader = LinearGradient(0f, h * 0.7f, 0f, h, 0, c(0x557A4A9A), Shader.TileMode.CLAMP)
    }

    private fun branch(x: Float, y: Float, angle: Float, len: Float, width: Float, depth: Int) {
        val x2 = x + cos(angle) * len
        val y2 = y + sin(angle) * len
        branches += floatArrayOf(x, y, x2, y2, width)
        if (depth == 0) return
        val n = if (depth > 3) 2 else 2 + rnd.nextInt(2)
        for (k in 0 until n) {
            val spread = (0.3f + rnd.nextFloat() * 0.5f) * (if (k % 2 == 0) -1f else 1f)
            branch(x2, y2, angle + spread, len * (0.62f + rnd.nextFloat() * 0.18f), width * 0.62f, depth - 1)
        }
    }

    private fun makeBolt(w: Float, h: Float) {
        bolt.reset()
        var x = w * (0.2f + rnd.nextFloat() * 0.6f)
        var y = h * 0.12f
        bolt.moveTo(x, y)
        for (i in 0 until 9) {
            x += (rnd.nextFloat() - 0.5f) * w * 0.12f
            y += h * 0.07f
            bolt.lineTo(x, y)
        }
    }

    // ================================================================= Bewegung

    private fun step(dt: Float) {
        t += dt
        val w = width.toFloat()
        val h = height.toFloat()
        for (cl in clouds) {
            cl.x += cl.speed * dt
            if (cl.x > w + cl.width * 0.1f) cl.x = -cl.width
        }
        var i = 0
        while (i < drops.size) {
            drops[i + 1] += drops[i + 3] * dt
            drops[i] += drops[i + 3] * dt * WIND
            if (drops[i + 1] > h) {
                drops[i + 1] = -drops[i + 2] - rnd.nextFloat() * h * 0.2f
                drops[i] = rnd.nextFloat() * (w + h * WIND) - h * WIND
            }
            i += 4
        }
        i = 0
        while (i < flakes.size) {
            flakes[i + 1] += flakes[i + 3] * dt
            if (flakes[i + 1] > h + flakes[i + 2]) {
                flakes[i + 1] = -flakes[i + 2]
                flakes[i] = rnd.nextFloat() * w
            }
            i += 5
        }
        for (f in fogs) {
            f[0] += f[4] * dt
            if (f[0] > w) f[0] = -f[2]
        }
        if (sky == Sky.THUNDER) {
            nextFlash -= dt
            if (nextFlash <= 0f) {
                flash = 1f
                makeBolt(w, h)
                nextFlash = 3f + rnd.nextFloat() * 6f
            }
        }
        flash = max(0f, flash - dt * 2.5f)
        if (themeKey == "city") {
            carX += w * 0.16f * dt
            if (carX > w) carX = -carW * 1.9f
            if (lit.isNotEmpty() && rnd.nextFloat() < dt * 0.8f) {
                val k = rnd.nextInt(lit.size)
                lit[k] = !lit[k]
            }
        }
    }

    // ================================================================= Zeichnen

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!built) rebuild()
        if (!built) return
        val animating = live && themeKey != "plain" && themeKey != "classic" && ValueAnimator.areAnimatorsEnabled()
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L || !animating) 0f else min((now - lastNanos) / 1e9f, 0.05f)
        lastNanos = now
        if (animating) step(dt)

        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, skyPaint)
        if (themeKey != "plain") {
            drawStars(canvas)
            drawOrb(canvas)
            drawClouds(canvas)
            when (themeKey) {
                "classic" -> drawClassic(canvas, w, h)
                "landscape" -> drawLandscape(canvas, w, h)
                "city" -> drawCity(canvas, w, h)
                "halloween" -> drawHalloween(canvas, w, h)
            }
            drawFog(canvas)
            drawRain(canvas)
            drawSnow(canvas)
            drawLightning(canvas, w, h)
        }
        if (scrim) canvas.drawRect(0f, 0f, w, h, scrimPaint)
        if (animating) postInvalidateDelayed(33)
    }

    private fun drawStars(canvas: Canvas) {
        fill.color = c(0xFFFFFFFF)
        var i = 0
        while (i < stars.size) {
            fill.alpha = (150 + 100 * sin(t * 2f + stars[i + 3])).toInt().coerceIn(40, 255)
            canvas.drawCircle(stars[i], stars[i + 1], stars[i + 2], fill)
            i += 4
        }
    }

    private fun drawOrb(canvas: Canvas) {
        if (orb == 0) return
        canvas.drawCircle(sunX, sunY, sunR * (if (orb == 3) 1.7f else if (orb == 1) 3.2f else 3f), glowPaint)
        if (orb == 1 && themeKey == "animated") {
            canvas.save()
            canvas.rotate(t * 4f, sunX, sunY)
            canvas.drawPath(rays, rayPaint)
            canvas.restore()
        }
        canvas.drawCircle(sunX, sunY, sunR, orbPaint)
        if (orb >= 2) {
            fill.color = c(0x26806A40)
            var i = 0
            while (i < craters.size) {
                canvas.drawCircle(sunX + sunR * craters[i], sunY + sunR * craters[i + 1], sunR * craters[i + 2], fill)
                i += 3
            }
        }
    }

    private fun cloudColors(): Pair<Int, Int> = when {
        themeKey == "halloween" -> c(0xFF6A5A80) to c(0xFF45375C)
        !day -> if (sky == Sky.CLEAR || sky == Sky.PARTLY) c(0xFF5A6478) to c(0xFF3A4254) else c(0xFF4A5468) to c(0xFF2E3546)
        sky == Sky.CLEAR || sky == Sky.PARTLY -> c(0xFFFFFFFF) to c(0xFFD3DEE8)
        sky == Sky.RAIN -> c(0xFFB3BDC8) to c(0xFF87929F)
        sky == Sky.THUNDER -> c(0xFF8F99A6) to c(0xFF5F6977)
        else -> c(0xFFEDF0F3) to c(0xFFBAC4CE)
    }

    private fun drawClouds(canvas: Canvas) {
        val (top, shade) = cloudColors()
        for (cl in clouds) {
            val p = cl.puffs
            fill.color = top
            fill.alpha = 45
            var i = 0
            while (i < p.size) {
                canvas.drawCircle(cl.x + p[i], cl.y + p[i + 1], p[i + 2] * 1.14f, fill)
                i += 3
            }
            fill.color = shade
            i = 0
            while (i < p.size) {
                canvas.drawCircle(cl.x + p[i], cl.y + p[i + 1] + p[i + 2] * 0.14f, p[i + 2], fill)
                i += 3
            }
            fill.color = top
            i = 0
            while (i < p.size) {
                canvas.drawCircle(cl.x + p[i], cl.y + p[i + 1] - p[i + 2] * 0.05f, p[i + 2] * 0.9f, fill)
                i += 3
            }
        }
    }

    private fun drawClassic(canvas: Canvas, w: Float, h: Float) {
        fill.color = if (day) c(0xFF7FAE5E) else c(0xFF1E3220)
        canvas.drawPath(hillFar, fill)
        fill.color = if (day) c(0xFF4F8A33) else c(0xFF14241A)
        canvas.drawPath(hill, fill)
        val tx = w * 0.7f
        val ty = h * 0.825f
        fill.color = if (day) c(0xFF4E3B2C) else c(0xFF1A140F)
        canvas.drawRect(tx - w * 0.008f, ty - h * 0.07f, tx + w * 0.008f, ty + h * 0.01f, fill)
        fill.color = if (day) c(0xFF2F5E22) else c(0xFF0F1E10)
        canvas.drawCircle(tx, ty - h * 0.09f, w * 0.035f, fill)
        canvas.drawCircle(tx - w * 0.03f, ty - h * 0.07f, w * 0.028f, fill)
        canvas.drawCircle(tx + w * 0.03f, ty - h * 0.07f, w * 0.028f, fill)
        canvas.drawCircle(tx, ty - h * 0.125f, w * 0.026f, fill)
    }

    private fun drawLandscape(canvas: Canvas, w: Float, h: Float) {
        fill.color = if (day) c(0xFF9FB0C4) else c(0xFF2B3550)
        canvas.drawPath(far, fill)
        canvas.save()
        canvas.clipPath(far)
        fill.color = if (day) c(0xF2FFFFFF) else c(0xFFB8C2D6)
        canvas.drawPath(snowFar, fill)
        canvas.restore()
        fill.color = if (day) c(0xFF6F8299) else c(0xFF1E2639)
        canvas.drawPath(mid, fill)
        canvas.save()
        canvas.clipPath(mid)
        fill.color = if (day) c(0xE6F4F7FA) else c(0xFF8E99AD)
        canvas.drawPath(snowMid, fill)
        canvas.restore()
        fill.color = if (day) c(0xFF3E4E62) else c(0xFF121826)
        canvas.drawPath(near, fill)
        fill.color = if (day) c(0xFF243B2E) else c(0xFF0B140F)
        canvas.drawPath(pines, fill)
    }

    private fun drawCity(canvas: Canvas, w: Float, h: Float) {
        fill.color = if (day) c(0xFF9AA8BC) else c(0xFF242C3E)
        for (b in buildingsFar) canvas.drawRect(b, fill)
        fill.color = if (day) c(0xFF66758C) else c(0xFF161C2A)
        for (b in buildingsNear) canvas.drawRect(b, fill)
        for (k in windows.indices) {
            fill.color = when {
                day -> c(0x40FFFFFF)
                lit[k] -> c(0xFFFFD27F)
                else -> c(0xFF232B3B)
            }
            canvas.drawRect(windows[k], fill)
        }
        val walk = horizon + (h - horizon) * 0.18f
        fill.color = if (day) c(0xFF7A8494) else c(0xFF2A303B)
        canvas.drawRect(0f, horizon, w, walk, fill)
        fill.color = if (day) c(0xFF4A4F58) else c(0xFF1C2026)
        canvas.drawRect(0f, walk, w, h, fill)
        // Mittellinie
        fill.color = c(0xB3FFFFFF)
        val dashY = horizon + (h - horizon) * 0.78f
        var dx = 0f
        while (dx < w) {
            canvas.drawRect(dx, dashY, dx + w * 0.06f, dashY + max(1.5f * dp, h * 0.006f), fill)
            dx += w * 0.11f
        }
        // Laternen
        stroke.color = if (day) c(0xFF3A3F47) else c(0xFF0C0E12)
        stroke.strokeWidth = max(1.5f * dp, w * 0.006f)
        for (lx in floatArrayOf(0.12f, 0.45f, 0.78f)) {
            val x = lx * w
            val top = horizon - (h - horizon) * 0.45f
            canvas.drawLine(x, walk, x, top, stroke)
            fill.color = if (day) c(0xFFE0E4EA) else c(0xFFFFE6A8)
            canvas.drawCircle(x, top, stroke.strokeWidth * 1.6f, fill)
            if (!day) {
                canvas.save()
                canvas.translate(x, top)
                canvas.drawCircle(0f, 0f, w * 0.1f, lampGlow)
                canvas.restore()
            }
        }
        // Auto
        canvas.save()
        canvas.translate(carX, carY)
        if (!day) {
            fill.color = c(0x55FFE9A8)
            canvas.drawPath(carBeam, fill)
        }
        fill.color = c(0xFFCFD5DC)
        tmp.set(0f, -carH * 0.64f, carW, -carH * 0.16f)
        canvas.drawRoundRect(tmp, carH * 0.18f, carH * 0.18f, fill)
        canvas.drawPath(carCabin, fill)
        fill.color = c(0xFF5D7894)
        canvas.drawPath(carWindows, fill)
        fill.color = c(0xFFFFE082)
        canvas.drawRect(carW * 0.94f, -carH * 0.5f, carW, -carH * 0.38f, fill)
        fill.color = c(0xFFE53935)
        canvas.drawRect(0f, -carH * 0.5f, carW * 0.04f, -carH * 0.38f, fill)
        for (wx in floatArrayOf(0.22f, 0.76f)) {
            fill.color = c(0xFF1C1E22)
            canvas.drawCircle(carW * wx, -carH * 0.16f, carH * 0.2f, fill)
            fill.color = c(0xFFAEB4BB)
            canvas.drawCircle(carW * wx, -carH * 0.16f, carH * 0.09f, fill)
        }
        canvas.restore()
    }

    private fun drawHalloween(canvas: Canvas, w: Float, h: Float) {
        // Fledermäuse
        fill.color = c(0xFF120818)
        for (b in 0 until 3) {
            val size = w * (0.05f + b * 0.012f)
            val x = (((t * (0.05f + b * 0.02f) + b * 0.37f) % 1.4f) - 0.2f) * w
            val y = h * (0.18f + b * 0.1f) + sin(t * 1.7f + b) * h * 0.03f
            val flap = 0.35f + 0.65f * abs(sin(t * 9f + b * 1.3f))
            canvas.save()
            canvas.translate(x, y)
            canvas.scale(size, size * flap)
            canvas.drawPath(batPath, fill)
            canvas.restore()
        }
        // Baum
        stroke.color = c(0xFF0A0410)
        for (br in branches) {
            stroke.strokeWidth = max(br[4], 0.8f * dp)
            canvas.drawLine(br[0], br[1], br[2], br[3], stroke)
        }
        // Gräber
        fill.color = c(0xFF2A1742)
        for (g in graves) {
            val x = g[1]
            val gw = g[2]
            val gh = g[3]
            val base = g[4]
            if (g[0] < 0.5f) {
                tmp.set(x - gw / 2f, base - gh, x + gw / 2f, base + gh * 0.2f)
                canvas.drawRoundRect(tmp, gw / 2f, gw / 2f, fill)
            } else {
                canvas.drawRect(x - gw * 0.12f, base - gh * 1.2f, x + gw * 0.12f, base + gh * 0.2f, fill)
                canvas.drawRect(x - gw * 0.45f, base - gh * 0.95f, x + gw * 0.45f, base - gh * 0.72f, fill)
            }
        }
        fill.color = c(0xFF1A0D2B)
        canvas.drawPath(ground, fill)
        canvas.drawRect(0f, h * 0.7f, w, h, mistPaint)
        // Kürbisse
        for ((idx, p) in pumpkins.withIndex()) {
            val x = p[0]
            val y = p[1]
            val r = p[2]
            fill.color = c(0xFFD9650B)
            tmp.set(x - r * 1.15f, y - r, x + r * 1.15f, y + r * 0.85f)
            canvas.drawOval(tmp, fill)
            fill.color = c(0xFFF08A1C)
            tmp.set(x - r * 0.45f, y - r, x + r * 0.45f, y + r * 0.85f)
            canvas.drawOval(tmp, fill)
            fill.color = c(0xFF4E6B2B)
            canvas.drawRect(x - r * 0.1f, y - r * 1.25f, x + r * 0.1f, y - r * 0.9f, fill)
            fill.color = c(0xFFFFE066)
            fill.alpha = (180 + 60 * sin(t * 7f + idx * 2f)).toInt().coerceIn(0, 255)
            facePath.reset()
            facePath.moveTo(x - r * 0.55f, y - r * 0.12f)
            facePath.lineTo(x - r * 0.2f, y - r * 0.12f)
            facePath.lineTo(x - r * 0.38f, y - r * 0.45f)
            facePath.close()
            facePath.moveTo(x + r * 0.55f, y - r * 0.12f)
            facePath.lineTo(x + r * 0.2f, y - r * 0.12f)
            facePath.lineTo(x + r * 0.38f, y - r * 0.45f)
            facePath.close()
            facePath.moveTo(x - r * 0.6f, y + r * 0.15f)
            facePath.lineTo(x + r * 0.6f, y + r * 0.15f)
            facePath.lineTo(x + r * 0.35f, y + r * 0.5f)
            facePath.lineTo(x, y + r * 0.35f)
            facePath.lineTo(x - r * 0.35f, y + r * 0.5f)
            facePath.close()
            canvas.drawPath(facePath, fill)
        }
    }

    private fun drawFog(canvas: Canvas) {
        for (f in fogs) {
            fill.color = if (day) c(0xFFFFFFFF) else c(0xFF9AA4B5)
            fill.alpha = f[5].toInt()
            tmp.set(f[0], f[1] - f[3] / 2f, f[0] + f[2], f[1] + f[3] / 2f)
            canvas.drawOval(tmp, fill)
        }
    }

    private fun drawRain(canvas: Canvas) {
        if (drops.isEmpty()) return
        stroke.color = if (day && themeKey != "halloween") c(0xB3FFFFFF) else c(0x99B4C8E6)
        stroke.strokeWidth = 1.3f * dp
        var i = 0
        while (i < drops.size) {
            val len = drops[i + 2]
            lines[i] = drops[i]
            lines[i + 1] = drops[i + 1]
            lines[i + 2] = drops[i] + len * WIND
            lines[i + 3] = drops[i + 1] + len
            i += 4
        }
        canvas.drawLines(lines, stroke)
    }

    private fun drawSnow(canvas: Canvas) {
        if (flakes.isEmpty()) return
        fill.color = c(0xE6FFFFFF)
        var i = 0
        while (i < flakes.size) {
            val x = flakes[i] + sin(t * 1.2f + flakes[i + 4]) * 10f * dp
            canvas.drawCircle(x, flakes[i + 1], flakes[i + 2], fill)
            i += 5
        }
    }

    private fun drawLightning(canvas: Canvas, w: Float, h: Float) {
        if (flash <= 0f) return
        fill.color = c(0xFFFFFFFF)
        fill.alpha = (flash * 110f).toInt().coerceIn(0, 255)
        canvas.drawRect(0f, 0f, w, h, fill)
        if (flash > 0.55f) {
            stroke.color = c(0x66FFFFFF)
            stroke.strokeWidth = 7f * dp
            canvas.drawPath(bolt, stroke)
            stroke.color = c(0xFFFFFFFF)
            stroke.strokeWidth = 2.5f * dp
            canvas.drawPath(bolt, stroke)
        }
    }
}
