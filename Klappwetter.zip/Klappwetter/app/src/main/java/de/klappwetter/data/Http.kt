package de.klappwetter.data

import de.klappwetter.BuildConfig
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** HTTP-Fehler mit Statuscode, damit die Oberfläche passende Hinweise geben kann */
class HttpException(val code: Int) : IOException("HTTP $code")

object Http {

    /** Met.no verlangt eine eindeutige Kennung mit Kontaktadresse; die Repo-Adresse kommt aus dem Build. */
    val userAgent: String = "Klappwetter/${BuildConfig.VERSION_NAME} (+${BuildConfig.CONTACT_URL})"

    fun get(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.setRequestProperty("Accept", "application/json, text/xml")
        conn.setRequestProperty("User-Agent", userAgent)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw HttpException(code)
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
