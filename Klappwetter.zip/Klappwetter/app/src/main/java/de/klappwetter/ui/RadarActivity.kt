package de.klappwetter.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import de.klappwetter.R
import de.klappwetter.data.AppSettings
import de.klappwetter.data.RadarSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Regenradar: Karte mit Zeitleiste in einer WebView (Leaflet). */
class RadarActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private var config: String? = null
    private var pageReady = false
    private var started = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_radar)
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        status = findViewById(R.id.radar_status)
        web = findViewById(R.id.radar_web)
        web.setBackgroundColor(0xFF111418.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                push()
            }
        }
        web.loadUrl("file:///android_asset/radar.html")

        val loc = AppSettings(this).location
        val lat = loc?.lat ?: 51.0
        val lon = loc?.lon ?: 10.4
        loc?.name?.takeIf { it.isNotBlank() }?.let {
            findViewById<TextView>(R.id.radar_title).text = getString(R.string.radar_at, it)
        }

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { RadarSource.build(lat, lon).toString() } }
            result.onSuccess {
                config = it
                push()
            }.onFailure {
                status.setText(R.string.radar_failed)
            }
        }
    }

    private fun push() {
        val c = config ?: return
        if (!pageReady || started) return
        started = true
        status.visibility = View.GONE
        web.evaluateJavascript("start($c)", null)
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
