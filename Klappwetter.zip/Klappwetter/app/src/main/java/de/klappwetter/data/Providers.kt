package de.klappwetter.data

import de.klappwetter.util.Sky
import de.klappwetter.util.WeatherCodes
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

class MissingKeyException : Exception("API-Schlüssel fehlt")

/** Anzeigename und Quellenangabe je Anbieter */
object Providers {
    const val OPEN_METEO = "openmeteo"
    const val MET_NO = "metno"
    const val DWD = "dwd"
    const val OWM = "owm"

    fun name(key: String): String = when (key) {
        MET_NO -> "MET Norway (Yr)"
        DWD -> "Deutscher Wetterdienst"
        OWM -> "OpenWeatherMap"
        else -> "Open-Meteo"
    }

    fun attribution(key: String): String = when (key) {
        MET_NO -> "Wetterdaten: MET Norway / Yr (CC BY 4.0)"
        DWD -> "Wetterdaten: Deutscher Wetterdienst, abgerufen über Bright Sky"
        OWM -> "Wetterdaten: OpenWeather (CC BY-SA 4.0)"
        else -> "Wetterdaten: Open-Meteo.com (CC BY 4.0)"
    }

    /** Liefert immer das Open-Meteo-Format, damit der Rest der App nur eines kennen muss. */
    fun fetch(provider: String, lat: Double, lon: Double, owmKey: String): JSONObject = when (provider) {
        MET_NO -> MetNo.fetch(lat, lon)
        DWD -> BrightSky.fetch(lat, lon)
        OWM -> OpenWeather.fetch(lat, lon, owmKey)
        else -> OpenMeteo.fetch(lat, lon)
    }
}

// ====================================================================== Open-Meteo

object OpenMeteo {
    fun fetch(lat: Double, lon: Double): JSONObject {
        val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=${c4(lat)}&longitude=${c4(lon)}" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,dew_point_2m,is_day," +
            "weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,visibility,uv_index,cloud_cover" +
            "&hourly=temperature_2m,weather_code,precipitation_probability,is_day" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max," +
            "sunrise,sunset,uv_index_max" +
            "&timezone=auto&timeformat=unixtime&forecast_days=8"
        return JSONObject(Http.get(url))
    }
}

// ====================================================================== Gemeinsames Format

class HourPoint(
    val time: Long,                  // Sekunden UTC
    val temp: Double,
    val code: Int,
    val pop: Int,                    // Regenwahrscheinlichkeit, -1 = unbekannt
    val tMax: Double = Double.NaN,   // nur bei 6-Stunden-Blöcken
    val tMin: Double = Double.NaN
)

class CurrentPoint(
    val time: Long,
    val temp: Double,
    val apparent: Double,
    val humidity: Double,
    val dew: Double,
    val code: Int,
    val isDay: Boolean?,
    val pressure: Double,
    val windKmh: Double,
    val windDir: Double,
    val visibility: Double,
    val uv: Double,
    val cloud: Double
)

object Normalizer {

    private const val DAY = 86_400_000L

    fun build(lat: Double, lon: Double, tz: TimeZone, cur: CurrentPoint, input: List<HourPoint>): JSONObject {
        val hours = input.sortedBy { it.time }
        val sunCache = HashMap<Long, SunCalc.Times>()
        fun dayStartOf(ms: Long): Long = Calendar.getInstance(tz).apply {
            timeInMillis = ms
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        fun sun(dayStart: Long) = sunCache.getOrPut(dayStart) { SunCalc.times(dayStart, lat, lon) }
        fun isDay(ms: Long): Boolean = sun(dayStartOf(ms)).let { ms >= it.rise && ms < it.set }

        val now = System.currentTimeMillis()
        val today = dayStartOf(now)

        // Stündlich
        val hTime = JSONArray(); val hTemp = JSONArray(); val hCode = JSONArray(); val hPop = JSONArray(); val hDay = JSONArray()
        for (h in hours) {
            hTime.put(h.time)
            hTemp.put(num(h.temp))
            hCode.put(h.code)
            hPop.put(if (h.pop >= 0) h.pop else JSONObject.NULL)
            hDay.put(if (isDay(h.time * 1000)) 1 else 0)
        }

        // Täglich
        val dTime = JSONArray(); val dCode = JSONArray(); val dMax = JSONArray(); val dMin = JSONArray()
        val dPop = JSONArray(); val dRise = JSONArray(); val dSet = JSONArray()
        val byDay = hours.groupBy { dayStartOf(it.time * 1000) }.toSortedMap()
        for ((dayStart, pts) in byDay) {
            if (dayStart < today) continue
            if (pts.size < 2 && dayStart != today) continue
            val temps = pts.flatMap { listOf(it.temp, it.tMax, it.tMin) }.filter { !it.isNaN() }
            if (temps.isEmpty()) continue
            val s = sun(dayStart)
            dTime.put(dayStart / 1000)
            dCode.put(dayCode(pts, s))
            dMax.put(temps.maxOrNull() ?: 0.0)
            dMin.put(temps.minOrNull() ?: 0.0)
            val pop = pts.maxOf { it.pop }
            dPop.put(if (pop >= 0) pop else JSONObject.NULL)
            dRise.put(s.rise / 1000)
            dSet.put(s.set / 1000)
            if (dTime.length() >= 8) break
        }

        val current = JSONObject()
            .put("time", cur.time)
            .put("temperature_2m", num(cur.temp))
            .put("apparent_temperature", num(cur.apparent))
            .put("relative_humidity_2m", num(cur.humidity))
            .put("dew_point_2m", num(cur.dew))
            .put("is_day", if (cur.isDay ?: isDay(cur.time * 1000)) 1 else 0)
            .put("weather_code", cur.code)
            .put("pressure_msl", num(cur.pressure))
            .put("wind_speed_10m", num(cur.windKmh))
            .put("wind_direction_10m", num(cur.windDir))
            .put("visibility", num(cur.visibility))
            .put("uv_index", num(cur.uv))
            .put("cloud_cover", num(cur.cloud))

        return JSONObject()
            .put("timezone", tz.id)
            .put("utc_offset_seconds", tz.getOffset(now) / 1000)
            .put("current", current)
            .put("hourly", JSONObject().put("time", hTime).put("temperature_2m", hTemp)
                .put("weather_code", hCode).put("precipitation_probability", hPop).put("is_day", hDay))
            .put("daily", JSONObject().put("time", dTime).put("weather_code", dCode)
                .put("temperature_2m_max", dMax).put("temperature_2m_min", dMin)
                .put("precipitation_probability_max", dPop).put("sunrise", dRise).put("sunset", dSet))
    }

    /** Ein typisches Symbol für den Tag – bevorzugt die Stunden mit Tageslicht. */
    private fun dayCode(points: List<HourPoint>, sun: SunCalc.Times): Int {
        val day = points.filter { it.time * 1000 in sun.rise..sun.set }.ifEmpty { points }
        val bySky = day.groupBy { WeatherCodes.sky(it.code) }
        fun count(s: Sky) = bySky[s]?.size ?: 0
        val enough = max(1, day.size / 4)
        return when {
            count(Sky.THUNDER) >= 1 -> bySky.getValue(Sky.THUNDER).maxOf { it.code }
            count(Sky.SNOW) >= enough -> bySky.getValue(Sky.SNOW).maxOf { it.code }
            count(Sky.RAIN) >= enough -> bySky.getValue(Sky.RAIN).maxOf { it.code }
            count(Sky.FOG) * 2 > day.size -> 45
            else -> {
                val cloudy = count(Sky.CLOUDY) + count(Sky.FOG) + count(Sky.RAIN) + count(Sky.SNOW)
                val partly = count(Sky.PARTLY)
                val clear = count(Sky.CLEAR)
                when {
                    cloudy >= partly + clear -> 3
                    clear > partly + cloudy -> 0
                    clear >= partly -> 1
                    else -> 2
                }
            }
        }
    }

    fun num(v: Double): Any = if (v.isNaN() || v.isInfinite()) JSONObject.NULL else v

    /** Gefühlte Temperatur: Windchill bei Kälte, Humidex bei Wärme */
    fun apparent(temp: Double, windKmh: Double, dew: Double): Double {
        if (temp.isNaN()) return Double.NaN
        if (temp <= 10.0 && !windKmh.isNaN() && windKmh > 4.8) {
            val v = windKmh.pow(0.16)
            return 13.12 + 0.6215 * temp - 11.37 * v + 0.3965 * temp * v
        }
        if (temp >= 20.0 && !dew.isNaN()) {
            val e = 6.11 * exp(5417.7530 * (1.0 / 273.16 - 1.0 / (273.15 + dew)))
            return temp + 0.5555 * (e - 10.0)
        }
        return temp
    }

    /** Taupunkt nach Magnus-Formel */
    fun dewPoint(temp: Double, humidity: Double): Double {
        if (temp.isNaN() || humidity.isNaN() || humidity <= 0) return Double.NaN
        val a = 17.62
        val b = 243.12
        val g = ln(humidity / 100.0) + a * temp / (b + temp)
        return b * g / (a - g)
    }
}

internal fun c4(v: Double) = String.format(Locale.US, "%.4f", v)

internal fun JSONObject.dbl(key: String): Double = if (isNull(key)) Double.NaN else optDouble(key)

internal fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key)

// ====================================================================== MET Norway

object MetNo {

    fun fetch(lat: Double, lon: Double): JSONObject {
        val url = "https://api.met.no/weatherapi/locationforecast/2.0/complete?lat=${c4(lat)}&lon=${c4(lon)}"
        val series = JSONObject(Http.get(url)).getJSONObject("properties").getJSONArray("timeseries")
        val now = System.currentTimeMillis() / 1000
        val hours = ArrayList<HourPoint>()
        var current: CurrentPoint? = null

        for (i in 0 until series.length()) {
            val entry = series.getJSONObject(i)
            val time = Instant.parse(entry.getString("time")).epochSecond
            val data = entry.getJSONObject("data")
            val inst = data.getJSONObject("instant").getJSONObject("details")
            val n1 = data.optJSONObject("next_1_hours")
            val n6 = data.optJSONObject("next_6_hours")
            val block = n1 ?: n6
            val symbol = block?.optJSONObject("summary")?.str("symbol_code").orEmpty()
            val pop = block?.optJSONObject("details")?.dbl("probability_of_precipitation")
                ?.let { if (it.isNaN()) -1 else it.roundToInt() } ?: -1
            val code = symbolToWmo(symbol)
            val six = if (n1 == null) n6?.optJSONObject("details") else null
            val temp = inst.dbl("air_temperature")
            hours += HourPoint(time, temp, code, pop, six?.dbl("air_temperature_max") ?: Double.NaN,
                six?.dbl("air_temperature_min") ?: Double.NaN)

            if (current == null && time + 3600 > now) {
                val wind = inst.dbl("wind_speed") * 3.6
                val dew = inst.dbl("dew_point_temperature")
                current = CurrentPoint(
                    time = time,
                    temp = temp,
                    apparent = Normalizer.apparent(temp, wind, dew),
                    humidity = inst.dbl("relative_humidity"),
                    dew = dew,
                    code = code,
                    isDay = when {
                        symbol.endsWith("_day") -> true
                        symbol.endsWith("_night") -> false
                        else -> null
                    },
                    pressure = inst.dbl("air_pressure_at_sea_level"),
                    windKmh = wind,
                    windDir = inst.dbl("wind_from_direction"),
                    visibility = Double.NaN,
                    uv = inst.dbl("ultraviolet_index_clear_sky"),
                    cloud = inst.dbl("cloud_area_fraction")
                )
            }
        }
        val cur = current ?: throw java.io.IOException("Keine aktuellen Daten von MET Norway")
        return Normalizer.build(lat, lon, TimeZone.getDefault(), cur, hours)
    }

    /** Met.no-Symbolnamen → WMO-Code. Enthält auch die historischen Schreibfehler wie „lightssleet…“. */
    fun symbolToWmo(symbol: String): Int {
        val s = symbol.substringBefore('_').lowercase(Locale.ROOT)
        val light = s.startsWith("light")
        val heavy = s.startsWith("heavy")
        return when {
            s.isEmpty() -> 3
            "thunder" in s -> 95
            s == "clearsky" -> 0
            s == "fair" -> 1
            s == "partlycloudy" -> 2
            s == "cloudy" -> 3
            s == "fog" -> 45
            "sleet" in s -> 68
            "snowshowers" in s -> if (light) 85 else 86
            "snow" in s -> if (light) 71 else if (heavy) 75 else 73
            "rainshowers" in s -> if (light) 80 else if (heavy) 82 else 81
            "rain" in s -> if (light) 61 else if (heavy) 65 else 63
            else -> 3
        }
    }
}

// ====================================================================== DWD über Bright Sky

object BrightSky {

    fun fetch(lat: Double, lon: Double): JSONObject {
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val url = "https://api.brightsky.dev/weather?lat=${c4(lat)}&lon=${c4(lon)}" +
            "&date=$today&last_date=${today.plusDays(8)}" +
            "&tz=" + URLEncoder.encode(zone.id, "UTF-8") + "&units=dwd"
        val records = JSONObject(Http.get(url)).getJSONArray("weather")
        val now = System.currentTimeMillis() / 1000
        val hours = ArrayList<HourPoint>()
        var current: JSONObject? = null
        var currentTime = Long.MIN_VALUE

        for (i in 0 until records.length()) {
            val r = records.getJSONObject(i)
            val time = OffsetDateTime.parse(r.getString("timestamp")).toEpochSecond()
            val pop = r.dbl("precipitation_probability").let { if (it.isNaN()) -1 else it.roundToInt() }
            hours += HourPoint(time, r.dbl("temperature"), code(r), pop)
            if (time <= now && time > currentTime) {
                current = r
                currentTime = time
            }
        }
        val r = current ?: (if (records.length() > 0) records.getJSONObject(0) else null)
            ?: throw java.io.IOException("Keine Daten vom DWD für diesen Ort")
        if (currentTime == Long.MIN_VALUE) currentTime = OffsetDateTime.parse(r.getString("timestamp")).toEpochSecond()

        val temp = r.dbl("temperature")
        val wind = r.dbl("wind_speed")
        val dew = r.dbl("dew_point")
        val icon = r.str("icon")
        val cur = CurrentPoint(
            time = currentTime,
            temp = temp,
            apparent = Normalizer.apparent(temp, wind, dew),
            humidity = r.dbl("relative_humidity"),
            dew = dew,
            code = code(r),
            isDay = when {
                icon.endsWith("-day") -> true
                icon.endsWith("-night") -> false
                else -> null
            },
            pressure = r.dbl("pressure_msl"),
            windKmh = wind,
            windDir = r.dbl("wind_direction"),
            visibility = r.dbl("visibility"),
            uv = Double.NaN,
            cloud = r.dbl("cloud_cover")
        )
        return Normalizer.build(lat, lon, TimeZone.getTimeZone(zone.id), cur, hours)
    }

    private fun code(r: JSONObject): Int {
        val precip = r.dbl("precipitation")
        val rain = when {
            precip.isNaN() || precip < 0.5 -> 61
            precip > 4.0 -> 65
            else -> 63
        }
        return when (r.str("icon")) {
            "clear-day", "clear-night" -> 0
            "partly-cloudy-day", "partly-cloudy-night" -> 2
            "cloudy", "wind" -> 3
            "fog" -> 45
            "rain" -> rain
            "sleet" -> 68
            "snow" -> 73
            "hail" -> 96
            "thunderstorm" -> 95
            else -> when (r.str("condition")) {
                "rain" -> rain
                "snow" -> 73
                "sleet" -> 68
                "hail" -> 96
                "thunderstorm" -> 95
                "fog" -> 45
                else -> {
                    val cloud = r.dbl("cloud_cover")
                    when {
                        cloud.isNaN() -> 3
                        cloud < 25 -> 0
                        cloud < 70 -> 2
                        else -> 3
                    }
                }
            }
        }
    }
}

// ====================================================================== OpenWeatherMap

object OpenWeather {

    fun fetch(lat: Double, lon: Double, key: String): JSONObject {
        if (key.isBlank()) throw MissingKeyException()
        val query = "lat=${c4(lat)}&lon=${c4(lon)}&units=metric&appid=" + URLEncoder.encode(key.trim(), "UTF-8")
        val now = JSONObject(Http.get("https://api.openweathermap.org/data/2.5/weather?$query"))
        val forecast = JSONObject(Http.get("https://api.openweathermap.org/data/2.5/forecast?$query"))

        val hours = ArrayList<HourPoint>()
        val list = forecast.optJSONArray("list") ?: JSONArray()
        for (i in 0 until list.length()) {
            val e = list.getJSONObject(i)
            val main = e.getJSONObject("main")
            val pop = e.dbl("pop").let { if (it.isNaN()) -1 else (it * 100).roundToInt() }
            hours += HourPoint(e.getLong("dt"), main.dbl("temp"), idToWmo(weatherId(e)), pop)
        }

        val main = now.getJSONObject("main")
        val wind = now.optJSONObject("wind") ?: JSONObject()
        val temp = main.dbl("temp")
        val humidity = main.dbl("humidity")
        val pressure = main.dbl("sea_level").let { if (it.isNaN()) main.dbl("pressure") else it }
        val icon = now.optJSONArray("weather")?.optJSONObject(0)?.str("icon").orEmpty()
        val cur = CurrentPoint(
            time = now.getLong("dt"),
            temp = temp,
            apparent = main.dbl("feels_like"),
            humidity = humidity,
            dew = Normalizer.dewPoint(temp, humidity),
            code = idToWmo(weatherId(now)),
            isDay = when {
                icon.endsWith("d") -> true
                icon.endsWith("n") -> false
                else -> null
            },
            pressure = pressure,
            windKmh = wind.dbl("speed") * 3.6,
            windDir = wind.dbl("deg"),
            visibility = now.dbl("visibility"),
            uv = Double.NaN,
            cloud = now.optJSONObject("clouds")?.dbl("all") ?: Double.NaN
        )
        return Normalizer.build(lat, lon, TimeZone.getDefault(), cur, hours)
    }

    private fun weatherId(o: JSONObject): Int = o.optJSONArray("weather")?.optJSONObject(0)?.optInt("id", 803) ?: 803

    /** OpenWeather-Zustands-IDs → WMO-Code */
    fun idToWmo(id: Int): Int = when (id) {
        in 200..299 -> 95
        in 300..399 -> 53
        500 -> 61
        501 -> 63
        502, 503, 504 -> 65
        511 -> 66
        520 -> 80
        521 -> 81
        522, 531 -> 82
        600 -> 71
        601 -> 73
        602 -> 75
        in 611..616 -> 68
        620 -> 85
        621, 622 -> 86
        701, 741 -> 45
        in 700..799 -> 3
        800 -> 0
        801 -> 1
        802 -> 2
        else -> 3
    }
}
