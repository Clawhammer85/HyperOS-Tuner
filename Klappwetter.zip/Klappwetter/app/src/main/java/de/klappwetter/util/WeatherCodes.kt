package de.klappwetter.util

import androidx.annotation.DrawableRes
import de.klappwetter.R

/** Vereinfachte Wetterlage – Grundlage für Symbole und animierte Hintergründe */
enum class Sky { CLEAR, PARTLY, CLOUDY, FOG, RAIN, SNOW, THUNDER }

/** Reihenfolge der Symbole in jedem Set */
enum class Cond { SUN, MOON, PARTLY_DAY, PARTLY_NIGHT, CLOUD, FOG, RAIN, SNOW, THUNDER }

class IconSet(val key: String, val title: String, val tileColor: Int, private val icons: IntArray) {
    @DrawableRes
    fun icon(cond: Cond): Int = icons[cond.ordinal]
}

object IconSets {

    val all: List<IconSet> = listOf(
        IconSet(
            "glanz", "Glanz", 0xFF22324F.toInt(), intArrayOf(
                R.drawable.ic_w_sun, R.drawable.ic_w_moon, R.drawable.ic_w_partly_day,
                R.drawable.ic_w_partly_night, R.drawable.ic_w_cloud, R.drawable.ic_w_fog,
                R.drawable.ic_w_rain, R.drawable.ic_w_snow, R.drawable.ic_w_thunder
            )
        ),
        IconSet(
            "flach", "Flach", 0xFF2D5089.toInt(), intArrayOf(
                R.drawable.ic_flat_sun, R.drawable.ic_flat_moon, R.drawable.ic_flat_partly_day,
                R.drawable.ic_flat_partly_night, R.drawable.ic_flat_cloud, R.drawable.ic_flat_fog,
                R.drawable.ic_flat_rain, R.drawable.ic_flat_snow, R.drawable.ic_flat_thunder
            )
        ),
        IconSet(
            "zweiton", "Zweiton", 0xFF6E466E.toInt(), intArrayOf(
                R.drawable.ic_duo_sun, R.drawable.ic_duo_moon, R.drawable.ic_duo_partly_day,
                R.drawable.ic_duo_partly_night, R.drawable.ic_duo_cloud, R.drawable.ic_duo_fog,
                R.drawable.ic_duo_rain, R.drawable.ic_duo_snow, R.drawable.ic_duo_thunder
            )
        ),
        IconSet(
            "papier", "Papier", 0xFF3C7873.toInt(), intArrayOf(
                R.drawable.ic_paper_sun, R.drawable.ic_paper_moon, R.drawable.ic_paper_partly_day,
                R.drawable.ic_paper_partly_night, R.drawable.ic_paper_cloud, R.drawable.ic_paper_fog,
                R.drawable.ic_paper_rain, R.drawable.ic_paper_snow, R.drawable.ic_paper_thunder
            )
        ),
        IconSet(
            "linie", "Linie", 0xFF1E2846.toInt(), intArrayOf(
                R.drawable.ic_line_sun, R.drawable.ic_line_moon, R.drawable.ic_line_partly_day,
                R.drawable.ic_line_partly_night, R.drawable.ic_line_cloud, R.drawable.ic_line_fog,
                R.drawable.ic_line_rain, R.drawable.ic_line_snow, R.drawable.ic_line_thunder
            )
        )
    )

    fun get(key: String): IconSet = all.firstOrNull { it.key == key } ?: all[0]
}

/** WMO-Wettercodes von Open-Meteo → deutscher Text, Wetterlage und Symbol */
object WeatherCodes {

    fun text(code: Int): String = when (code) {
        0 -> "Klar"
        1 -> "Überwiegend klar"
        2 -> "Teilweise bewölkt"
        3 -> "Bedeckt"
        45 -> "Nebel"
        48 -> "Reifnebel"
        51 -> "Leichter Nieselregen"
        53 -> "Nieselregen"
        55 -> "Starker Nieselregen"
        56, 57 -> "Gefrierender Niesel"
        61 -> "Leichter Regen"
        63 -> "Regen"
        65 -> "Starker Regen"
        66, 67 -> "Gefrierender Regen"
        68, 69 -> "Schneeregen"
        71 -> "Leichter Schneefall"
        73 -> "Schneefall"
        75 -> "Starker Schneefall"
        77 -> "Schneegriesel"
        80 -> "Leichte Schauer"
        81 -> "Regenschauer"
        82 -> "Heftige Schauer"
        85 -> "Leichte Schneeschauer"
        86 -> "Schneeschauer"
        95 -> "Gewitter"
        96, 99 -> "Gewitter mit Hagel"
        else -> "–"
    }

    fun sky(code: Int): Sky = when (code) {
        0 -> Sky.CLEAR
        1, 2 -> Sky.PARTLY
        45, 48 -> Sky.FOG
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> Sky.RAIN
        68, 69, 71, 73, 75, 77, 85, 86 -> Sky.SNOW
        95, 96, 99 -> Sky.THUNDER
        else -> Sky.CLOUDY
    }

    fun cond(code: Int, isDay: Boolean): Cond = when (sky(code)) {
        Sky.CLEAR -> if (isDay) Cond.SUN else Cond.MOON
        Sky.PARTLY -> if (isDay) Cond.PARTLY_DAY else Cond.PARTLY_NIGHT
        Sky.CLOUDY -> Cond.CLOUD
        Sky.FOG -> Cond.FOG
        Sky.RAIN -> Cond.RAIN
        Sky.SNOW -> Cond.SNOW
        Sky.THUNDER -> Cond.THUNDER
    }

    @DrawableRes
    fun icon(code: Int, isDay: Boolean, set: String): Int = IconSets.get(set).icon(cond(code, isDay))
}
