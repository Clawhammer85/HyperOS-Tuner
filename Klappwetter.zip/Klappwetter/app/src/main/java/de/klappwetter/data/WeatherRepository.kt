package de.klappwetter.data

import android.content.Context
import android.location.Location
import de.klappwetter.util.LocationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException

class NoLocationException : Exception("Kein Ort festgelegt")

class WeatherRepository(context: Context) {

    private val app = context.applicationContext
    private val settings = AppSettings(app)

    fun cached(): WeatherSnapshot? {
        val json = settings.cacheJson ?: return null
        return try {
            WeatherParser.parse(JSONObject(json))
        } catch (e: Exception) {
            null
        }
    }

    fun isStale(maxAgeMinutes: Int): Boolean {
        val snap = cached() ?: return true
        return System.currentTimeMillis() - snap.fetchedAt > maxAgeMinutes * 60_000L
    }

    /**
     * Lädt neue Wetterdaten.
     * @param interactive true, wenn die App im Vordergrund ist – dann darf eine
     *                    frische Standortabfrage gestartet werden.
     */
    suspend fun refresh(interactive: Boolean): Result<WeatherSnapshot> = withContext(Dispatchers.IO) {
        try {
            var loc = settings.location
            if (settings.useGps) {
                val fix = if (interactive) LocationHelper.current(app) else LocationHelper.lastKnown(app)
                if (fix != null) loc = resolveGpsLocation(fix, loc)
            }
            if (loc == null) return@withContext Result.failure(NoLocationException())

            val provider = settings.provider
            val raw = Providers.fetch(provider, loc.lat, loc.lon, settings.owmKey)
            val cache = JSONObject()
                .put("name", loc.name)
                .put("provider", provider)
                .put("fetchedAt", System.currentTimeMillis())
                .put("raw", raw)
            val snapshot = WeatherParser.parse(cache)
                ?: return@withContext Result.failure(IOException("Antwort des Wetterdienstes unlesbar"))
            settings.cacheJson = cache.toString()
            Result.success(snapshot)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Ortsname nur neu ermitteln, wenn man sich merklich bewegt hat. */
    private fun resolveGpsLocation(fix: Location, previous: SavedLocation?): SavedLocation {
        val distance = FloatArray(1)
        val moved = previous == null || run {
            Location.distanceBetween(previous.lat, previous.lon, fix.latitude, fix.longitude, distance)
            distance[0] > 1500f
        }
        val name = if (!moved && !previous?.name.isNullOrBlank()) {
            previous!!.name
        } else {
            LocationHelper.placeName(app, fix.latitude, fix.longitude) ?: "Mein Standort"
        }
        val resolved = SavedLocation(name, fix.latitude, fix.longitude)
        settings.location = resolved
        return resolved
    }
}
