package de.klappwetter.ui

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import de.klappwetter.R
import de.klappwetter.data.AppSettings
import de.klappwetter.util.Cond
import de.klappwetter.util.IconSets
import de.klappwetter.widget.WidgetRenderer

/** Auswahl für Wetterhintergrund oder Icon-Set – jeweils als Kacheln mit Live-Vorschau. */
class StylePickerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_ICONS = "icons"
        const val MODE_BACKGROUNDS = "backgrounds"
    }

    private lateinit var settings: AppSettings
    private val tiles = ArrayList<Pair<String, View>>()
    private var mode = MODE_BACKGROUNDS

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        settings = AppSettings(this)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_BACKGROUNDS
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<TextView>(R.id.list_title).setText(
            if (mode == MODE_ICONS) R.string.pick_icons else R.string.pick_background
        )

        val keys = if (mode == MODE_ICONS) IconSets.all.map { it.key } else WeatherSceneView.THEMES
        val container = findViewById<LinearLayout>(R.id.list_container)
        val gap = resources.getDimensionPixelSize(R.dimen.card_gap) * 2
        for (pair in keys.chunked(2)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in pair) {
                val tile = tile(row, key)
                row.addView(tile, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(gap / 2, gap, gap / 2, 0)
                })
                tiles += key to tile
            }
            if (pair.size == 1) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f).apply { setMargins(gap / 2, gap, gap / 2, 0) })
            }
            container.addView(row)
        }
        updateChecks()
    }

    private fun tile(parent: ViewGroup, key: String): View {
        val v = layoutInflater.inflate(R.layout.item_tile, parent, false)
        val content = v.findViewById<FrameLayout>(R.id.tile_content)
        val label = v.findViewById<TextView>(R.id.tile_label)
        if (mode == MODE_ICONS) {
            val set = IconSets.get(key)
            label.text = set.title
            content.setBackgroundColor(set.tileColor)
            val grid = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
            }
            for (rowConds in listOf(listOf(Cond.SUN, Cond.PARTLY_DAY), listOf(Cond.RAIN, Cond.THUNDER))) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (cond in rowConds) {
                    val icon = ImageView(this).apply {
                        setImageResource(set.icon(cond))
                        scaleType = ImageView.ScaleType.FIT_CENTER
                    }
                    row.addView(icon, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                }
                grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
            content.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            label.text = WeatherSceneView.title(key)
            val scene = WeatherSceneView(this)
            val (sky, isDay, _) = WeatherSceneView.sample(key)
            scene.show(key, sky, isDay)
            content.addView(scene, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        v.clipToOutline = true
        v.setOnClickListener { select(key) }
        return v
    }

    private fun select(key: String) {
        if (mode == MODE_ICONS) settings.iconSet = key else settings.background = key
        updateChecks()
        if (mode == MODE_ICONS) WidgetRenderer.updateAll(this)
    }

    private fun updateChecks() {
        val current = if (mode == MODE_ICONS) settings.iconSet else settings.background
        for ((key, view) in tiles) {
            val selected = key == current
            view.findViewById<View>(R.id.tile_check).visibility = if (selected) View.VISIBLE else View.GONE
            view.setBackgroundResource(if (selected) R.drawable.panel_selected else R.drawable.panel)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
