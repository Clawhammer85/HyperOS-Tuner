package de.klappwetter.data

import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToLong
import kotlin.math.sin

/** Sonnenauf- und -untergang nach der NOAA-Näherung (Genauigkeit etwa ±1 Minute). */
object SunCalc {

    class Times(val rise: Long, val set: Long)

    private const val DAY = 86_400_000L

    fun times(dayStart: Long, lat: Double, lon: Double): Times {
        var n = (julian(dayStart + DAY / 2) - 2451545.0 + 0.0008).roundToLong().toDouble()
        var transit = 0.0
        var cosW = 0.0
        for (attempt in 0 until 3) {
            val jStar = n - lon / 360.0
            val m = norm(357.5291 + 0.98560028 * jStar)
            val mr = Math.toRadians(m)
            val c = 1.9148 * sin(mr) + 0.02 * sin(2 * mr) + 0.0003 * sin(3 * mr)
            val lr = Math.toRadians(norm(m + c + 180.0 + 102.9372))
            transit = 2451545.0 + jStar + 0.0053 * sin(mr) - 0.0069 * sin(2 * lr)
            val sinD = sin(lr) * sin(Math.toRadians(23.4397))
            val cosD = cos(asin(sinD))
            val phi = Math.toRadians(lat)
            cosW = (sin(Math.toRadians(-0.833)) - sin(phi) * sinD) / (cos(phi) * cosD)
            val t = fromJulian(transit)
            n += when {
                t < dayStart -> 1.0
                t >= dayStart + DAY -> -1.0
                else -> break
            }
        }
        if (cosW > 1.0) return Times(dayStart + DAY / 2, dayStart + DAY / 2) // Polarnacht
        if (cosW < -1.0) return Times(dayStart, dayStart + DAY) // Mitternachtssonne
        val w = Math.toDegrees(acos(cosW))
        return Times(fromJulian(transit - w / 360.0), fromJulian(transit + w / 360.0))
    }

    private fun norm(deg: Double): Double = ((deg % 360.0) + 360.0) % 360.0
    private fun julian(ms: Long): Double = ms / 86_400_000.0 + 2440587.5
    private fun fromJulian(j: Double): Long = ((j - 2440587.5) * 86_400_000.0).toLong()
}
