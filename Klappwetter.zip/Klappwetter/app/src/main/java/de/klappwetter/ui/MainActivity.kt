package de.klappwetter.ui

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import de.klappwetter.R
import de.klappwetter.data.AppSettings
import de.klappwetter.data.HttpException
import de.klappwetter.data.MissingKeyException
import de.klappwetter.data.NoLocationException
import de.klappwetter.data.Providers
import de.klappwetter.data.WeatherRepository
import de.klappwetter.data.WeatherSnapshot
import de.klappwetter.util.LocationHelper
import de.klappwetter.util.Sky
import de.klappwetter.util.Units
import de.klappwetter.util.WeatherCodes
import de.klappwetter.widget.WidgetRenderer
import de.klappwetter.work.RefreshWorker
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var settings: AppSettings
    private lateinit var repo: WeatherRepository

    private lateinit var tvLocation: TextView
    private lateinit var btnRefresh: ImageButton
    private lateinit var tvUpdated: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvCondition: TextView
    private lateinit var tvRange: TextView
    private lateinit var ivIcon: ImageView
    private lateinit var tvStatus: TextView
    private lateinit var details: LinearLayout
    private lateinit var hourly: LinearLayout
    private lateinit var daily: LinearLayout
    private lateinit var forecastBlock: View
    private lateinit var scene: WeatherSceneView
    private lateinit var tvAttribution: TextView

    private var refreshJob: Job? = null
    private var askedForLocation = false

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                refresh()
            } else {
                settings.useGps = false
                Toast.makeText(this, R.string.gps_denied, Toast.LENGTH_LONG).show()
                if (settings.location == null) openLocationSearch() else refresh()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.content)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        settings = AppSettings(this)
        repo = WeatherRepository(this)

        tvLocation = findViewById(R.id.location_title)
        btnRefresh = findViewById(R.id.btn_refresh)
        tvUpdated = findViewById(R.id.updated)
        tvTemp = findViewById(R.id.big_temp)
        tvCondition = findViewById(R.id.big_condition)
        tvRange = findViewById(R.id.big_range)
        ivIcon = findViewById(R.id.big_icon)
        tvStatus = findViewById(R.id.status)
        details = findViewById(R.id.details)
        hourly = findViewById(R.id.hourly)
        daily = findViewById(R.id.daily)
        forecastBlock = findViewById(R.id.forecast_block)
        scene = findViewById(R.id.scene)
        scene.scrim = true
        tvAttribution = findViewById(R.id.attribution)
        findViewById<ImageButton>(R.id.btn_radar).setOnClickListener {
            startActivity(Intent(this, RadarActivity::class.java))
        }

        tvLocation.setOnClickListener { openLocationSearch() }
        btnRefresh.setOnClickListener { refresh() }
        findViewById<ImageButton>(R.id.btn_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        RefreshWorker.schedule(this)
    }

    override fun onResume() {
        super.onResume()
        val cached = repo.cached()
        render(cached)
        when {
            !settings.useGps && settings.location == null -> {
                showStatus(getString(R.string.no_location))
                if (!askedForLocation) openLocationSearch()
            }
            settings.needsRefresh || cached == null || repo.isStale(15) -> refresh()
        }
    }

    private fun openLocationSearch() {
        askedForLocation = true
        startActivity(Intent(this, LocationSearchActivity::class.java))
    }

    private fun refresh() {
        if (refreshJob?.isActive == true) return
        if (settings.useGps && !LocationHelper.hasPermission(this)) {
            locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            return
        }
        if (!settings.useGps && settings.location == null) {
            openLocationSearch()
            return
        }
        tvUpdated.text = getString(R.string.loading)
        btnRefresh.animate().rotationBy(360f).setDuration(700).start()
        refreshJob = lifecycleScope.launch {
            val result = repo.refresh(interactive = true)
            settings.needsRefresh = false
            result.onSuccess {
                hideStatus()
                render(it)
                WidgetRenderer.updateAll(this@MainActivity)
            }.onFailure {
                render(repo.cached())
                showStatus(errorText(it))
            }
        }
    }

    private fun errorText(e: Throwable): String = when (e) {
        is NoLocationException -> getString(R.string.error_no_location)
        is MissingKeyException -> getString(R.string.error_owm_key_missing)
        is HttpException -> when (e.code) {
            401 -> getString(R.string.error_owm_key_invalid)
            403 -> getString(R.string.error_forbidden, Providers.name(settings.provider))
            429 -> getString(R.string.error_rate_limit)
            else -> getString(R.string.error_http, Providers.name(settings.provider), e.code)
        }
        is IOException -> getString(R.string.error_network, Providers.name(settings.provider))
        else -> getString(R.string.error_generic, e.message ?: e.javaClass.simpleName)
    }

    private fun showStatus(text: String) {
        tvStatus.text = text
        tvStatus.visibility = View.VISIBLE
    }

    private fun hideStatus() {
        tvStatus.visibility = View.GONE
    }

    // ------------------------------------------------------------------ Darstellung

    private fun render(snap: WeatherSnapshot?) {
        tvLocation.text = snap?.locationName?.takeIf { it.isNotBlank() }
            ?: settings.location?.name?.takeIf { it.isNotBlank() }
            ?: getString(R.string.pick_location)

        if (snap == null) {
            scene.show(settings.background, Sky.PARTLY, true)
            tvAttribution.text = Providers.attribution(settings.provider)
            tvTemp.text = "–°"
            tvCondition.text = ""
            tvRange.text = ""
            tvUpdated.text = ""
            ivIcon.setImageResource(WeatherCodes.icon(2, true, settings.iconSet))
            details.removeAllViews()
            forecastBlock.visibility = View.GONE
            return
        }

        val unit = settings.tempUnit
        val now = System.currentTimeMillis()
        val c = snap.current
        val today = snap.today(now)
        val clock = SimpleDateFormat("HH:mm", Locale.GERMANY)

        tvUpdated.text = getString(R.string.updated_at, clock.format(Date(snap.fetchedAt)))
        tvTemp.text = Units.temp(c.temperature, unit)
        tvCondition.text = WeatherCodes.text(c.weatherCode)
        tvRange.text = today?.let {
            getString(R.string.max_min, Units.temp(it.max, unit), Units.temp(it.min, unit))
        } ?: ""
        val isDay = snap.isDayAt(now)
        ivIcon.setImageResource(WeatherCodes.icon(c.weatherCode, isDay, settings.iconSet))
        scene.show(settings.background, WeatherCodes.sky(c.weatherCode), isDay)
        tvAttribution.text = Providers.attribution(snap.provider)

        renderDetails(snap, now)
        renderHourly(snap, now)
        renderDaily(snap, now)
        forecastBlock.visibility = View.VISIBLE
    }

    private fun renderDetails(snap: WeatherSnapshot, now: Long) {
        val unit = settings.tempUnit
        val c = snap.current
        val today = snap.today(now)
        val local = SimpleDateFormat("HH:mm", Locale.GERMANY).apply { timeZone = snap.tz }
        val items = listOf(
            getString(R.string.d_feels) to Units.temp(c.apparent, unit),
            getString(R.string.d_dew) to Units.temp(c.dewPoint, unit),
            getString(R.string.d_precip) to (snap.precipProbNow(now)?.let { "$it %" } ?: "–"),
            getString(R.string.d_wind) to Units.windText(c.windSpeed, c.windDirection, settings.windUnit),
            getString(R.string.d_visibility) to Units.visibility(c.visibility),
            getString(R.string.d_pressure) to Units.pressure(c.pressure),
            getString(R.string.d_humidity) to (if (c.humidity >= 0) "${c.humidity} %" else "–"),
            getString(R.string.d_uv) to Units.uv(if (c.uvIndex.isNaN()) today?.uvMax ?: Double.NaN else c.uvIndex),
            getString(R.string.d_clouds) to (if (c.cloudCover >= 0) "${c.cloudCover} %" else "–"),
            getString(R.string.d_daylight) to (today?.takeIf { it.sunrise > 0 && it.sunset > 0 }
                ?.let { "${local.format(Date(it.sunrise))} – ${local.format(Date(it.sunset))}" } ?: "–")
        )

        details.removeAllViews()
        val gap = resources.getDimensionPixelSize(R.dimen.card_gap)
        for (pair in items.chunked(2)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((label, value) in pair) {
                val card = layoutInflater.inflate(R.layout.item_detail, row, false)
                card.findViewById<TextView>(R.id.detail_label).text = label
                card.findViewById<TextView>(R.id.detail_value).text = value
                row.addView(card, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(gap, gap, gap, gap)
                })
            }
            details.addView(row)
        }
    }

    private fun renderHourly(snap: WeatherSnapshot, now: Long) {
        val unit = settings.tempUnit
        val hourFormat = SimpleDateFormat("HH:mm", Locale.GERMANY).apply { timeZone = snap.tz }
        hourly.removeAllViews()
        snap.nextHours(now, 25).forEachIndexed { index, h ->
            val item = layoutInflater.inflate(R.layout.item_hour, hourly, false)
            item.findViewById<TextView>(R.id.hour_time).text =
                if (index == 0) getString(R.string.now) else hourFormat.format(Date(h.time))
            item.findViewById<ImageView>(R.id.hour_icon)
                .setImageResource(WeatherCodes.icon(h.weatherCode, h.isDay, settings.iconSet))
            item.findViewById<TextView>(R.id.hour_temp).text = Units.temp(h.temperature, unit)
            item.findViewById<TextView>(R.id.hour_precip).text = if (h.precipProb > 0) "${h.precipProb} %" else ""
            hourly.addView(item)
        }
    }

    private fun renderDaily(snap: WeatherSnapshot, now: Long) {
        val unit = settings.tempUnit
        val dayFormat = SimpleDateFormat("EEEE", Locale.GERMANY).apply { timeZone = snap.tz }
        val days = snap.forecastDays(now, 7)
        val lows = days.map { it.min }.filter { !it.isNaN() }
        val highs = days.map { it.max }.filter { !it.isNaN() }
        val weekMin = lows.minOrNull() ?: 0.0
        val weekMax = highs.maxOrNull() ?: 1.0
        val range = max(weekMax - weekMin, 1.0)
        val trackWidth = resources.displayMetrics.density * 72f
        val minBar = resources.displayMetrics.density * 8f
        daily.removeAllViews()
        days.forEachIndexed { index, d ->
            val item = layoutInflater.inflate(R.layout.item_day, daily, false)
            item.findViewById<TextView>(R.id.day_name).text = when (index) {
                0 -> getString(R.string.today)
                1 -> getString(R.string.tomorrow)
                else -> dayFormat.format(Date(d.time))
            }
            item.findViewById<ImageView>(R.id.day_icon)
                .setImageResource(WeatherCodes.icon(d.weatherCode, true, settings.iconSet))
            item.findViewById<TextView>(R.id.day_precip).text = if (d.precipProb > 0) "${d.precipProb} %" else ""
            item.findViewById<TextView>(R.id.day_max).text = Units.temp(d.max, unit)
            item.findViewById<TextView>(R.id.day_min).text = Units.temp(d.min, unit)
            val bar = item.findViewById<View>(R.id.day_bar)
            if (d.min.isNaN() || d.max.isNaN()) {
                bar.visibility = View.INVISIBLE
            } else {
                val start = ((d.min - weekMin) / range * trackWidth).toFloat()
                val width = max(((d.max - d.min) / range * trackWidth).toFloat(), minBar)
                bar.layoutParams = (bar.layoutParams as ViewGroup.MarginLayoutParams).apply {
                    this.width = width.toInt()
                    marginStart = start.coerceAtMost(trackWidth - width).toInt().coerceAtLeast(0)
                }
            }
            daily.addView(item)
        }
    }
}
