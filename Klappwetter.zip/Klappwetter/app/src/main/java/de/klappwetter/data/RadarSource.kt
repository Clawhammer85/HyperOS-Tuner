package de.klappwetter.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.time.Duration
import java.time.Instant
import java.util.Date
import java.util.Locale
import kotlin.math.min

/**
 * Stellt die Radarbilder für die Kartenseite zusammen.
 * Deutschland und Nachbarländer: DWD-Radar (frei, 1 km, mit 2-h-Vorhersage wenn verfügbar).
 * Sonst: RainViewer (frei für private Nutzung, nur vergangene Bilder, gröber).
 */
object RadarSource {

    private const val DWD_WMS = "https://maps.dwd.de/geoserver/dwd/wms"
    private const val DWD_FORECAST = "Radar_wn-product_1x1km_ger"
    private const val DWD_RAIN = "Niederschlagsradar"

    fun build(lat: Double, lon: Double): JSONObject {
        val inDwdArea = lat in 46.0..56.5 && lon in 2.0..20.0
        if (inDwdArea) {
            val forecast = runCatching { dwdTimes(DWD_FORECAST) }.getOrDefault(emptyList())
            val now = System.currentTimeMillis()
            if (forecast.count { it <= now } >= 4) return dwd(lat, lon, DWD_FORECAST, forecast)
            val rain = runCatching { dwdTimes(DWD_RAIN) }.getOrDefault(emptyList())
            if (rain.isNotEmpty()) return dwd(lat, lon, DWD_RAIN, rain)
        }
        runCatching { return rainViewer(lat, lon) }
        if (inDwdArea) return dwd(lat, lon, DWD_RAIN, fallbackTimes())
        throw IOException("Radar nicht erreichbar")
    }

    // ------------------------------------------------------------------ DWD

    private fun dwdTimes(layer: String): List<Long> {
        val xml = Http.get("https://maps.dwd.de/geoserver/dwd/$layer/ows?service=WMS&version=1.3.0&request=GetCapabilities")
        val dim = Regex("""<Dimension[^>]*name="time"[^>]*>([^<]+)</Dimension>""").find(xml)?.groupValues?.get(1)
            ?: return emptyList()
        return thin(expand(dim))
    }

    /** Zeitangaben der WMS-Dimension: Liste und/oder Bereiche "start/ende/PT5M" */
    private fun expand(dim: String): List<Long> {
        val now = System.currentTimeMillis()
        val from = now - 90 * 60_000L
        val to = now + 120 * 60_000L
        val out = sortedSetOf<Long>()
        for (part in dim.split(',')) {
            val p = part.trim()
            if (p.isEmpty()) continue
            if ('/' in p) {
                val seg = p.split('/')
                val start = Instant.parse(seg[0].trim()).toEpochMilli()
                val end = Instant.parse(seg[1].trim()).toEpochMilli()
                val step = if (seg.size > 2) Duration.parse(seg[2].trim()).toMillis() else 300_000L
                if (step <= 0) continue
                var t = if (from > start) start + ((from - start + step - 1) / step) * step else start
                while (t <= min(end, to)) {
                    out += t
                    t += step
                }
            } else {
                val t = Instant.parse(p).toEpochMilli()
                if (t in from..to) out += t
            }
        }
        return out.toList()
    }

    /** Höchstens 10 Bilder Vergangenheit und 8 Bilder Vorhersage – gleichmäßig verteilt */
    private fun thin(times: List<Long>): List<Long> {
        val now = System.currentTimeMillis()
        val past = times.filter { it <= now }
        val future = times.filter { it > now }
        return pick(past, 10, fromEnd = true) + pick(future, 8, fromEnd = false)
    }

    private fun pick(list: List<Long>, max: Int, fromEnd: Boolean): List<Long> {
        if (list.size <= max) return list
        val step = (list.size + max - 1) / max
        return if (fromEnd) {
            list.indices.reversed().filter { (list.size - 1 - it) % step == 0 }.map { list[it] }.reversed()
        } else {
            list.indices.filter { it % step == step - 1 }.map { list[it] }
        }
    }

    private fun fallbackTimes(): List<Long> {
        val step = 10 * 60_000L
        val latest = (System.currentTimeMillis() - 10 * 60_000L) / step * step
        return (9 downTo 0).map { latest - it * step }
    }

    private fun dwd(lat: Double, lon: Double, layer: String, times: List<Long>): JSONObject {
        val frames = JSONArray()
        for (t in times) frames.put(frame(t).put("iso", Instant.ofEpochMilli(t).toString()))
        return base(lat, lon, 8, times)
            .put("source", "dwd")
            .put("wmsUrl", DWD_WMS)
            .put("layer", "dwd:$layer")
            .put("frames", frames)
            .put("credit", "Deutscher Wetterdienst")
            .put("legendUrl", "https://maps.dwd.de/geoserver/dwd/ows?service=WMS&request=GetLegendGraphic&format=image/png&layer=dwd:$layer")
    }

    // ------------------------------------------------------------------ RainViewer

    private fun rainViewer(lat: Double, lon: Double): JSONObject {
        val json = JSONObject(Http.get("https://api.rainviewer.com/public/weather-maps.json"))
        val host = json.getString("host")
        val past = json.getJSONObject("radar").getJSONArray("past")
        if (past.length() == 0) throw IOException("Keine Radarbilder")
        val frames = JSONArray()
        val times = ArrayList<Long>()
        for (i in 0 until past.length()) {
            val p = past.getJSONObject(i)
            val t = p.getLong("time") * 1000L
            times += t
            frames.put(frame(t).put("path", p.getString("path")))
        }
        return base(lat, lon, 7, times)
            .put("source", "rv")
            .put("host", host)
            .put("frames", frames)
            .put("credit", "RainViewer")
            .put("note", "Außerhalb Deutschlands: gröbere Auflösung, keine Vorhersage")
    }

    // ------------------------------------------------------------------ Gemeinsam

    private fun frame(t: Long): JSONObject = JSONObject()
        .put("t", t)
        .put("label", SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(t)))
        .put("day", SimpleDateFormat("EE", Locale.GERMANY).format(Date(t)))

    private fun base(lat: Double, lon: Double, zoom: Int, times: List<Long>): JSONObject {
        val now = System.currentTimeMillis()
        val nowIndex = times.indexOfLast { it <= now }.coerceAtLeast(0)
        return JSONObject()
            .put("lat", lat)
            .put("lon", lon)
            .put("zoom", zoom)
            .put("nowIndex", nowIndex)
    }
}
