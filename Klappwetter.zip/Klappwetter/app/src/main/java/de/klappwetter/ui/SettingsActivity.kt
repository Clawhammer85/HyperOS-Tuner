package de.klappwetter.ui

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.EditTextPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import de.klappwetter.R
import de.klappwetter.data.AppSettings
import de.klappwetter.util.IconSets
import de.klappwetter.util.LocationHelper
import de.klappwetter.widget.WidgetRenderer
import de.klappwetter.work.RefreshWorker

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }
}

class SettingsFragment : PreferenceFragmentCompat(), SharedPreferences.OnSharedPreferenceChangeListener {

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val ctx = context ?: return@registerForActivityResult
            if (granted) {
                AppSettings(ctx).needsRefresh = true
                RefreshWorker.refreshNow(ctx)
            } else {
                findPreference<SwitchPreferenceCompat>(AppSettings.KEY_USE_GPS)?.isChecked = false
                Toast.makeText(ctx, R.string.gps_denied, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        findPreference<Preference>("pick_location")?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), LocationSearchActivity::class.java))
            true
        }

        findPreference<SwitchPreferenceCompat>(AppSettings.KEY_USE_GPS)?.setOnPreferenceChangeListener { _, newValue ->
            val ctx = requireContext()
            AppSettings(ctx).needsRefresh = true
            if (newValue == true && !LocationHelper.hasPermission(ctx)) {
                locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            } else {
                RefreshWorker.refreshNow(ctx)
            }
            true
        }

        findPreference<Preference>("pick_background")?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), StylePickerActivity::class.java)
                .putExtra(StylePickerActivity.EXTRA_MODE, StylePickerActivity.MODE_BACKGROUNDS))
            true
        }
        findPreference<Preference>("pick_icons")?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), StylePickerActivity::class.java)
                .putExtra(StylePickerActivity.EXTRA_MODE, StylePickerActivity.MODE_ICONS))
            true
        }
        findPreference<Preference>("widget_gallery")?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), WidgetGalleryActivity::class.java))
            true
        }
        findPreference<Preference>("owm_signup")?.setOnPreferenceClickListener {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://home.openweathermap.org/users/sign_up")))
            }
            true
        }
        findPreference<EditTextPreference>(AppSettings.KEY_OWM_KEY)?.summaryProvider =
            Preference.SummaryProvider<EditTextPreference> { pref ->
                val key = pref.text.orEmpty().trim()
                if (key.isEmpty()) getString(R.string.owm_key_none) else getString(R.string.owm_key_set, key.takeLast(4))
            }

        findPreference<Preference>("battery")?.setOnPreferenceClickListener {
            val ctx = requireContext()
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.fromParts("package", ctx.packageName, null))
            runCatching { startActivity(intent) }
            true
        }
    }

    override fun onResume() {
        super.onResume()
        preferenceManager.sharedPreferences?.registerOnSharedPreferenceChangeListener(this)
        val settings = AppSettings(requireContext())
        val name = settings.location?.name
        findPreference<Preference>("pick_location")?.summary =
            if (name.isNullOrBlank()) getString(R.string.no_location_short) else name
        findPreference<Preference>("pick_background")?.summary = WeatherSceneView.title(settings.background)
        findPreference<Preference>("pick_icons")?.summary = IconSets.get(settings.iconSet).title
    }

    override fun onPause() {
        preferenceManager.sharedPreferences?.unregisterOnSharedPreferenceChangeListener(this)
        super.onPause()
    }

    override fun onSharedPreferenceChanged(prefs: SharedPreferences?, key: String?) {
        val ctx = context ?: return
        if (key == AppSettings.KEY_INTERVAL || key == AppSettings.KEY_WIFI_ONLY) {
            RefreshWorker.schedule(ctx, replace = true)
        }
        if (key == AppSettings.KEY_PROVIDER || key == AppSettings.KEY_OWM_KEY) {
            AppSettings(ctx).needsRefresh = true
            RefreshWorker.refreshNow(ctx)
        }
        WidgetRenderer.updateAll(ctx)
    }
}
