package de.klappwetter.data

import org.json.JSONObject
import java.net.URLEncoder

data class Place(val name: String, val detail: String, val lat: Double, val lon: Double)

/** Ortssuche über die Geocoding-API von Open-Meteo (frei, ohne Schlüssel). */
object WeatherApi {

    fun searchPlaces(query: String): List<Place> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(query, "UTF-8") +
            "&count=15&language=de&format=json"
        val results = JSONObject(Http.get(url)).optJSONArray("results") ?: return emptyList()
        val list = mutableListOf<Place>()
        for (i in 0 until results.length()) {
            val r = results.optJSONObject(i) ?: continue
            val name = r.optString("name")
            val detail = listOf("admin3", "admin2", "admin1", "country")
                .map { r.optString(it) }
                .filter { it.isNotBlank() && it != name }
                .distinct()
                .take(3)
                .joinToString(", ")
            list += Place(name, detail, r.optDouble("latitude"), r.optDouble("longitude"))
        }
        return list.filter { !it.lat.isNaN() && !it.lon.isNaN() }
    }
}
