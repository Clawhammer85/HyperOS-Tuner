package de.klappwetter.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import de.klappwetter.data.AppSettings
import de.klappwetter.data.WeatherRepository
import de.klappwetter.widget.WidgetRenderer
import java.util.concurrent.TimeUnit

class RefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val result = WeatherRepository(applicationContext).refresh(interactive = false)
        WidgetRenderer.updateAll(applicationContext)
        return when {
            result.isSuccess -> Result.success()
            runAttemptCount < 3 -> Result.retry()
            else -> Result.failure()
        }
    }

    companion object {
        private const val PERIODIC = "klappwetter_periodic"
        private const val ONCE = "klappwetter_once"

        /** Regelmäßige Aktualisierung einplanen; replace = true übernimmt geänderte Einstellungen. */
        fun schedule(context: Context, replace: Boolean = false) {
            val settings = AppSettings(context)
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (settings.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<RefreshWorker>(
                settings.intervalMinutes.toLong().coerceAtLeast(15L), TimeUnit.MINUTES
            ).setConstraints(constraints).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                PERIODIC,
                if (replace) ExistingPeriodicWorkPolicy.UPDATE else ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        /**
         * Einmalige Aktualisierung. Ohne force höchstens alle 10 Minuten –
         * verhindert Schleifen, wenn das System Widgets mehrfach anstößt.
         */
        fun refreshNow(context: Context, force: Boolean = true) {
            val settings = AppSettings(context)
            val now = System.currentTimeMillis()
            if (!force && now - settings.lastRefreshRequest < 10 * 60_000L) return
            settings.lastRefreshRequest = now
            val request = OneTimeWorkRequestBuilder<RefreshWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(ONCE, ExistingWorkPolicy.REPLACE, request)
        }

        fun cancelPeriodic(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(PERIODIC)
        }
    }
}
