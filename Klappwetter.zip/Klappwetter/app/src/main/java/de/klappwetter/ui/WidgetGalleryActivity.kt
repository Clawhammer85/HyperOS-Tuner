package de.klappwetter.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import de.klappwetter.R
import de.klappwetter.data.AppSettings
import de.klappwetter.data.WeatherRepository
import de.klappwetter.util.Sky
import de.klappwetter.util.WeatherCodes
import de.klappwetter.widget.WidgetRenderer
import de.klappwetter.widget.WidgetRenderer.Kind

/** Übersicht aller Widgets mit echter Vorschau und „Hinzufügen“. */
class WidgetGalleryActivity : AppCompatActivity() {

    private class Entry(val kind: Kind, val title: Int, val desc: Int, val heightDp: Int, val widthParts: Float)

    private val entries = listOf(
        Entry(Kind.LARGE, R.string.widget_large_label, R.string.widget_large_size, 170, 4f),
        Entry(Kind.FORECAST_CLOCK, R.string.widget_forecast_clock_label, R.string.widget_forecast_clock_size, 260, 4f),
        Entry(Kind.MEDIUM, R.string.widget_medium_label, R.string.widget_medium_size, 170, 3f),
        Entry(Kind.COMPACT, R.string.widget_compact_label, R.string.widget_compact_size, 84, 4f),
        Entry(Kind.FORECAST, R.string.widget_forecast_label, R.string.widget_forecast_size, 90, 4f)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        findViewById<TextView>(R.id.list_title).setText(R.string.widgets)

        val container = findViewById<LinearLayout>(R.id.list_container)
        val settings = AppSettings(this)
        val snap = WeatherRepository(this).cached()
        val now = System.currentTimeMillis()
        val sky = snap?.let { WeatherCodes.sky(it.current.weatherCode) } ?: Sky.PARTLY
        val isDay = snap?.isDayAt(now) ?: true
        val theme = if (settings.background == "plain") "animated" else settings.background

        for (e in entries) {
            val item = layoutInflater.inflate(R.layout.item_widget, container, false)
            item.findViewById<TextView>(R.id.widget_title).setText(e.title)
            item.findViewById<TextView>(R.id.widget_desc).setText(e.desc)
            val preview = item.findViewById<FrameLayout>(R.id.widget_preview)
            preview.layoutParams = preview.layoutParams.apply { height = dp(e.heightDp + 20) }

            // Hintergrund wie ein Startbildschirm
            val scene = WeatherSceneView(this).apply { live = false }
            scene.show(theme, sky, isDay)
            preview.addView(scene, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 4f
                setPadding(dp(8), dp(10), dp(8), dp(10))
            }
            runCatching {
                val widget = WidgetRenderer.build(this, e.kind).apply(this, holder)
                holder.addView(widget, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, e.widthParts))
            }
            preview.addView(holder, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            // Tippen in der Vorschau soll nichts auslösen
            preview.addView(View(this).apply { isClickable = true },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            item.clipToOutline = true

            item.findViewById<Button>(R.id.widget_add).setOnClickListener { pin(e.kind) }
            container.addView(item)
        }
    }

    private fun pin(kind: Kind) {
        val manager = AppWidgetManager.getInstance(this)
        val ok = manager.isRequestPinAppWidgetSupported &&
            manager.requestPinAppWidget(ComponentName(this, WidgetRenderer.providerClass(kind)), null, null)
        if (!ok) Toast.makeText(this, R.string.widget_add_manual, Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
