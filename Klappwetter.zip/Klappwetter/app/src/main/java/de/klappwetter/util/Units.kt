package de.klappwetter.util

import java.util.Locale
import kotlin.math.roundToInt

/** Umrechnung und Formatierung. Intern wird immer in °C, km/h, hPa und Metern gerechnet. */
object Units {

    fun tempValue(celsius: Double, unit: String): Int? {
        if (celsius.isNaN()) return null
        val v = if (unit == "f") celsius * 9.0 / 5.0 + 32.0 else celsius
        return v.roundToInt()
    }

    fun temp(celsius: Double, unit: String): String = tempValue(celsius, unit)?.let { "$it°" } ?: "–°"

    fun tempUnitLabel(unit: String) = if (unit == "f") "°F" else "°C"

    fun wind(kmh: Double, unit: String): String {
        if (kmh.isNaN()) return "–"
        return when (unit) {
            "ms" -> String.format(Locale.GERMANY, "%.1f m/s", kmh / 3.6)
            "mph" -> "${(kmh / 1.609344).roundToInt()} mph"
            "kn" -> "${(kmh / 1.852).roundToInt()} kn"
            "bft" -> "${beaufort(kmh)} Bft"
            else -> "${kmh.roundToInt()} km/h"
        }
    }

    fun windText(kmh: Double, degrees: Int, unit: String): String =
        if (!kmh.isNaN() && kmh < 1.0) "Windstill" else "${wind(kmh, unit)} aus ${direction(degrees)}"

    fun beaufort(kmh: Double): Int {
        val ms = kmh / 3.6
        val limits = doubleArrayOf(0.3, 1.6, 3.4, 5.5, 8.0, 10.8, 13.9, 17.2, 20.8, 24.5, 28.5, 32.7)
        return limits.count { ms >= it }
    }

    fun direction(degrees: Int): String {
        val names = arrayOf("N", "NO", "O", "SO", "S", "SW", "W", "NW")
        val d = ((degrees % 360) + 360) % 360
        return names[((d + 22) / 45) % 8]
    }

    fun visibility(meters: Double): String = when {
        meters.isNaN() -> "–"
        meters >= 1000 -> "${(meters / 1000).roundToInt()} km"
        else -> "${meters.roundToInt()} m"
    }

    fun uv(index: Double): String {
        if (index.isNaN()) return "–"
        val level = when {
            index < 3 -> "niedrig"
            index < 6 -> "mäßig"
            index < 8 -> "hoch"
            index < 11 -> "sehr hoch"
            else -> "extrem"
        }
        return String.format(Locale.GERMANY, "%.1f %s", index, level)
    }

    fun pressure(hpa: Double): String = if (hpa.isNaN()) "–" else "${hpa.roundToInt()} hPa"
}
