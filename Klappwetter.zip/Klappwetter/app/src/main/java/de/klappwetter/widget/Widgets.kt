package de.klappwetter.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle
import de.klappwetter.data.AppSettings
import de.klappwetter.data.WeatherRepository
import de.klappwetter.work.RefreshWorker

abstract class BaseWidget(private val kind: WidgetRenderer.Kind) : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetRenderer.update(context, manager, ids, kind)
        RefreshWorker.schedule(context)
        val maxAge = AppSettings(context).intervalMinutes + 15
        if (WeatherRepository(context).isStale(maxAge)) RefreshWorker.refreshNow(context, force = false)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        manager: AppWidgetManager,
        id: Int,
        newOptions: Bundle
    ) {
        WidgetRenderer.update(context, manager, intArrayOf(id), kind)
    }

    override fun onEnabled(context: Context) {
        RefreshWorker.schedule(context)
    }

    override fun onDisabled(context: Context) {
        if (!WidgetRenderer.hasAnyWidget(context)) RefreshWorker.cancelPeriodic(context)
    }
}

/** Große Klappuhr mit Wetterleiste (4×2) */
class FlipWeatherWidget : BaseWidget(WidgetRenderer.Kind.LARGE)

/** Mittlere Klappuhr mit Wetterleiste (3×2) */
class FlipMediumWidget : BaseWidget(WidgetRenderer.Kind.MEDIUM)

/** Klappuhr mit 5-Tage-Vorhersage (4×3) */
class FlipForecastWidget : BaseWidget(WidgetRenderer.Kind.FORECAST_CLOCK)

/** Kompakte Klappuhr mit Temperatur (4×1) */
class FlipCompactWidget : BaseWidget(WidgetRenderer.Kind.COMPACT)

/** 5-Tage-Vorhersage (4×1) */
class ForecastWidget : BaseWidget(WidgetRenderer.Kind.FORECAST)
