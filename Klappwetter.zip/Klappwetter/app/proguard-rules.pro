# Klappwetter – R8-Regeln
# Bibliotheken (WorkManager, Preference, Fragment) bringen eigene Regeln mit.
-keep class de.klappwetter.ui.SettingsFragment { public <init>(); }
