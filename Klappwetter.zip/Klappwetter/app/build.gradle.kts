plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Signatur: kommt im GitHub-Build aus den Secrets (siehe README).
// Ohne Secrets wird mit dem Debug-Schlüssel signiert – dann lässt sich
// ein Update nur nach Deinstallation der alten Version einspielen.
val signingKeystorePath: String? = System.getenv("SIGNING_KEYSTORE_PATH")
val signingPassword: String? = System.getenv("SIGNING_PASSWORD")

// Kontaktadresse für die Anfragen an MET Norway (deren Nutzungsbedingungen verlangen eine).
// Der GitHub-Build setzt hier automatisch die Adresse des Repositorys ein.
val contactUrl: String = (project.findProperty("contactUrl") as String?)?.takeIf { it.isNotBlank() }
    ?: "https://github.com"

android {
    namespace = "de.klappwetter"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.klappwetter"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0"
        buildConfigField("String", "CONTACT_URL", "\"$contactUrl\"")
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        if (!signingKeystorePath.isNullOrBlank() && !signingPassword.isNullOrBlank()) {
            create("release") {
                storeFile = file(signingKeystorePath!!)
                storePassword = signingPassword
                keyAlias = "klappwetter"
                keyPassword = signingPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
